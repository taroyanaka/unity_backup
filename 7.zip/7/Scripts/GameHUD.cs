using UnityEngine;
using TMPro;

public class GameHUD : MonoBehaviour
{
    public TextMeshProUGUI abcdef;
    private int score = 0;
    private int playerHP = 10;
    private int maxHP = 10;
    private bool showClear = false;
    private bool showGameOver = false;

    void Start()
    {
    Debug.Log("GameHUD Start");
    UpdateScore(0);
    UpdateHP(maxHP);
    }

    public int UpdateScore(int add)
    {
        Debug.Log("Updating score");
        score += add;
        UpdateHUD();
        return score;
    }

    public void UpdateHP(int hp)
    {
        playerHP = Mathf.Clamp(hp, 0, maxHP);
        UpdateHUD();
        if (playerHP <= 0)
        {
            ShowGameOver();
        }
    }

    public void DamagePlayer(int dmg)
    {
        UpdateHP(playerHP - dmg);
    }

    private void UpdateHUD()
    {
        if (showClear)
        {
            abcdef.text = "GAME CLEAR";
        }
        else if (showGameOver)
        {
            abcdef.text = "GAME OVER";
        }
        else
        {
            abcdef.text = $"Score: {score}\nHP: {playerHP}/{maxHP}";
        }
    }

    public void ShowGameClear()
    {
        showClear = true;
        showGameOver = false;
        UpdateHUD();
    }

    public void ShowGameOver()
    {
        showGameOver = true;
        showClear = false;
        UpdateHUD();
    }

    public void ResetScore()
    {
    score = 0;
    playerHP = maxHP;
    showClear = false;
    showGameOver = false;
    UpdateHUD();
    }

    void OnGUI()
    {
        // if (showClear)
        // {
        //     float width = 200, height = 60;
        //     float x = (Screen.width - width) / 2;
        //     float y = (Screen.height) / 2;
        //     if (GUI.Button(new Rect(x, y, width, height), "リトライ"))
        //     {
        //         showClear = false;
        //         if (GameManager.Instance != null)
        //         {
        //             GameManager.Instance.RetryGame();
        //         }
        //     }
        // }
        // if (showGameOver)
        // {
        //     float width = 200, height = 60;
        //     float x = (Screen.width - width) / 2;
        //     float y = (Screen.height) / 2 + 80;
        //     if (GUI.Button(new Rect(x, y, width, height), "リトライ"))
        //     {
        //         showGameOver = false;
        //         if (GameManager.Instance != null)
        //         {
        //             GameManager.Instance.RetryGame();
        //         }
        //     }
        // }
    }
}