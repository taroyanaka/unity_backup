using UnityEngine;

[ExecuteInEditMode]
public class Collectible : MonoBehaviour
{
    void Awake()
    {
        // ColliderがあればIs Triggerを有効化
        var col = GetComponent<Collider>();
        if (col != null && !col.isTrigger)
        {
            col.isTrigger = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // This script now only handles collision with the Player.
        // Bullet collision is handled by the BulletController script itself.
        if (other.CompareTag("Player"))
        {
            //log
            Debug.Log("a");
            // GameManagerに通知
            if (GameManager.Instance != null)
            {
                //log
                Debug.Log("b");
                GameManager.Instance.OnCollectibleCollected(gameObject);
            }
            Destroy(gameObject);
        }
        // ここにBulletとの衝突処理を追加
        if (other.CompareTag("Bullet"))
        {
            //log
            Debug.Log("0Collectible hit by bullet!");
            if (GameManager.Instance != null)
            {
                //log
                Debug.Log("Collectible hit by bullet!");
                GameManager.Instance.OnCollectibleCollected(gameObject);
            }
            Destroy(gameObject);
        }
    }
}