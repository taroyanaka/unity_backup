using UnityEngine;

public class CapsulePowerUp : MonoBehaviour
{
    // 効果時間や増加倍率を必要に応じてpublicで調整可能
    public float fireRateMultiplier = 2f; // 発射間隔が2倍速くなる

    // 外部からも効果を発動できるようにする
    public void Activate()
    {
        ApplyEffect();
    }

    // 効果適用処理を共通化
    private void ApplyEffect()
    {
        Debug.Log("100 CapsulePowerUp activated");
        if (GameManager.Instance != null)
        {
            Debug.Log("110 CapsulePowerUp applying effect via GameManager");
            GameManager.Instance.SetFireRateMultiplier(fireRateMultiplier);
        }
        Debug.Log("120 CapsulePowerUp collected and destroyed");
        Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") || other.CompareTag("Bullet"))
        {
            Activate();
        }
    }
}
