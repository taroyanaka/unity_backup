#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;

public class UISetup
{
    [MenuItem("Tools/Setup Game HUD")]
    public static void SetupGameHUD()
    {
        // UI用のGameObjectを探すか、なければ作成する
        GameObject uiObject = GameObject.Find("GameHUD");
        if (uiObject == null)
        {
            uiObject = new GameObject("GameHUD");
        }

        // UIDocumentコンポーネントを追加
        UIDocument uiDocument = uiObject.GetComponent<UIDocument>();
        if (uiDocument == null)
        {
            uiDocument = uiObject.AddComponent<UIDocument>();
        }

        // GameHUD.uxmlアセットを読み込んで設定
        VisualTreeAsset uiAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/UI/GameHUD.uxml");
        if (uiAsset != null)
        {
            uiDocument.visualTreeAsset = uiAsset;
            Debug.Log("GameHUD.uxmlをUIDocumentに設定しました。");
        }
        else
        {
            Debug.LogError("Assets/UI/GameHUD.uxml が見つかりませんでした。");
            return;
        }


        Debug.Log("HUDのセットアップが完了しました。");
    }
}
#endif
