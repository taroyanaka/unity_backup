#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;
using UnityEngine.EventSystems;

public class CompleteSceneSetup
{
    [MenuItem("Tools/TEST: Setup HUD and Camera")]
    public static void SetupScene()
    {
        // Clean up existing objects to prevent duplicates
        DestroyIfExists("GameHUD");
        DestroyIfExists("EventSystem");
        DestroyIfExists("Main Camera"); // Also remove old camera

        // Setup a basic camera
        SetupCamera();

        // Setup UI
        SetupUI();

        Debug.Log("HUD and Camera Test Setup finished!");
    }

    private static void SetupCamera()
    {
        GameObject camObj = new GameObject("Main Camera");
        Camera cam = camObj.AddComponent<Camera>();
        cam.tag = "MainCamera";
        cam.transform.position = new Vector3(0, 1, -10);
        // Add an Audio Listener, as cameras often have them
        camObj.AddComponent<AudioListener>();
    }

    private static void SetupUI()
    {
        // Event System
        GameObject eventSystemObj = new GameObject("EventSystem");
        eventSystemObj.AddComponent<EventSystem>();
        eventSystemObj.AddComponent<StandaloneInputModule>();

        // UI GameObject
        GameObject uiObject = new GameObject("GameHUD");
        UIDocument uiDocument = uiObject.AddComponent<UIDocument>();
        VisualTreeAsset uiAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/UI/GameHUD.uxml");
        if (uiAsset != null)
        {
            uiDocument.visualTreeAsset = uiAsset;
        }
        else
        {
            Debug.LogError("Assets/UI/GameHUD.uxml could not be found.");
        }
    }

    private static void DestroyIfExists(string name)
    {
        GameObject obj = GameObject.Find(name);
        if (obj != null)
        {
            GameObject.DestroyImmediate(obj);
        }
    }
}
#endif
