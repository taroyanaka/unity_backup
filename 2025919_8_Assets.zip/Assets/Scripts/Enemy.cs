using UnityEngine;

public class Enemy : MonoBehaviour
{
    private Renderer rend;
    private Color originalColor = Color.yellow;
    private Coroutine flashCoroutine;
        public int maxHP = 3;
    private int currentHP;
    public float moveSpeed = 2f;
    private Transform player;
    void Awake()
    {
        //Debug.Log($"Enemy Spawned at {transform.position}");
        gameObject.tag = "Enemy";
        rend = GetComponentInChildren<Renderer>();
        if (rend != null)
        {
            originalColor = Color.yellow;
            rend.material.color = originalColor;
        }
    }


    void Start()
    {
    currentHP = maxHP;
    player = GameObject.FindWithTag("Player")?.transform;
    //Debug.Log($"Enemy Start: HP={currentHP}");
    }

    void Update()
    {
        // fキーで一時停止/再開
        if (UnityEngine.InputSystem.Keyboard.current != null && UnityEngine.InputSystem.Keyboard.current.fKey.wasPressedThisFrame)
        {
            if (Time.timeScale > 0f)
                Time.timeScale = 0f;
            else
                Time.timeScale = 1f;
        }

        if (player != null)
        {
            Vector3 dir = (player.position - transform.position).normalized;
            transform.position += dir * moveSpeed * Time.deltaTime;
            transform.LookAt(player.position + Vector3.up * 1.0f);
            //playerを追跡する

            //Debug.Log($"Enemy moving towards player. Pos={transform.position}");
        }
    }

    public void TakeDamage(int dmg)
    {
        currentHP -= dmg;
        Debug.Log("1ていくダメージ");
        if (rend != null)
        {
            Debug.Log("2ていくダメージ");
            if (flashCoroutine != null) StopCoroutine(flashCoroutine);
            flashCoroutine = StartCoroutine(FlashRed());
            //対象のエネミーのHPを減らす処理
            currentHP -= dmg;
            //減少後のHPをログ出力
            Debug.Log($"えねみーのHP={currentHP}");
        }
        if (currentHP <= 0)
        {
            Debug.Log("3ていくダメージ");
            //Debug.Log("Enemy destroyed!");
            Destroy(gameObject);
        }
    }

    System.Collections.IEnumerator FlashRed()
    {
        float duration = 1f;
        float elapsed = 0f;
        bool isRed = true;
        while (elapsed < duration)
        {
            if (rend != null)
                rend.material.color = isRed ? Color.red : originalColor;
            isRed = !isRed;
            yield return new WaitForSeconds(0.1f);
            elapsed += 0.1f;
        }
        if (rend != null)
            rend.material.color = originalColor;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Bullet"))
        {
            //Debug.Log("Enemy hit by bullet!");
            TakeDamage(1);
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.CompareTag("Player"))
        {
            //Debug.Log("Enemy collided with player!");
            GameHUD hud = FindFirstObjectByType<GameHUD>();
            if (hud != null)
            {
                hud.DamagePlayer(1);
            }
            Destroy(gameObject);
        }
    }
}
