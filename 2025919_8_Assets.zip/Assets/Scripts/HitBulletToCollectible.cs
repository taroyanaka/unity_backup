using UnityEngine;

public class Bullet : MonoBehaviour
{


    private void OnTriggerEnter(Collider other)
    {
        //log
        Debug.Log("1");
        if (other.gameObject.CompareTag("Collectible"))
        {
            //log
            Debug.Log("2Bullet hit collectible (trigger)!");
            // コレクタブルに触れた時の処理
            Destroy(gameObject); // バレットを消滅
        }
    }
}