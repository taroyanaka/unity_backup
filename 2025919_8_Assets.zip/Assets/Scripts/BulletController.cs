
using UnityEngine;


public class BulletController : MonoBehaviour
{
    // GameManager経由でプレイヤー操作や効果を管理するため、ownerPlayerは不要
    // 必要に応じてBulletの挙動をここに記述
    void Start()
    {
        // 例: 5秒後に自動で消える
        Destroy(gameObject, 5f);
    }
}
