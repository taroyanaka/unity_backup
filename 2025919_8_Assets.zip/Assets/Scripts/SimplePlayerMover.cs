using UnityEngine;
using UnityEngine.InputSystem;

public class SimplePlayerMover : MonoBehaviour
{
    private bool showUpgradeMenu = false;
    private GameHUD hud;
    private int cachedScore = 0;
    private float prevMoveSpeed;
    private float prevFireInterval;

    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    public float rotationSpeed = 120f; // Inspectorで調整可
    private Rigidbody rb;
    private bool isGrounded = true;

    private Vector3 inputMove = Vector3.zero;

    private GameObject bulletPrefab; // 通常弾
    public GameObject straightBulletPrefab; // 直進弾
    public GameObject explosiveBulletPrefab; // 爆発弾
    public Transform bulletSpawnPoint;

    // 発射間隔制御用
    public float fireInterval = 0.2f;
    private float fireTimer = 0f;

    void Awake()
    {
        // 直進弾プレハブ（テンプレートとして生成）
        straightBulletPrefab = new GameObject("StraightBulletTemplate");
        straightBulletPrefab.AddComponent<StraightBullet>();
        var straightSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        straightSphere.transform.SetParent(straightBulletPrefab.transform);
        straightSphere.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
        var renderer = straightSphere.GetComponent<Renderer>();
        if (renderer != null) renderer.material.color = Color.cyan;
        straightBulletPrefab.SetActive(false);

        // 爆発弾プレハブはResourcesからロード
        explosiveBulletPrefab = Resources.Load<GameObject>("ExplosiveBullet");
    }

    void Start()
    {
        hud = FindFirstObjectByType<GameHUD>();
        prevMoveSpeed = moveSpeed;
        prevFireInterval = fireInterval;
        rb = GetComponent<Rigidbody>();

        // Find the bullet spawn point
        Transform found = transform.Find("BulletSpawnPoint");
        if (found != null)
        {
            bulletSpawnPoint = found;
        }
        else
        {
            // If not found, create one further in front of the player
            GameObject spawnPointObject = new GameObject("BulletSpawnPoint");
            spawnPointObject.transform.SetParent(transform);
            spawnPointObject.transform.localPosition = new Vector3(0, 0.5f, 2.0f);
            bulletSpawnPoint = spawnPointObject.transform;
        }

        // プレイヤーの上方に光源を生成
        GameObject lightObj = new GameObject("PlayerLight");
        lightObj.transform.position = transform.position + new Vector3(0, 10, 0);
        Light lightComp = lightObj.AddComponent<Light>();
        lightComp.type = LightType.Directional;
        lightComp.intensity = 2.5f;
        lightComp.color = Color.white;
    }

    void Update()
    {
        // fキーでアップグレードメニュー表示切替
        if (Keyboard.current != null && Keyboard.current.fKey.wasPressedThisFrame)
        {
            showUpgradeMenu = !showUpgradeMenu;
        }

        // スコアのキャッシュ更新
        if (hud != null)
        {
            cachedScore = hud.UpdateScore(0); // 現在スコア取得
        }

        // 値が変化したらデバッグログ
        if (prevMoveSpeed != moveSpeed || prevFireInterval != fireInterval)
        {
            Debug.Log($"moveSpeed={moveSpeed}, fireInterval={fireInterval}");
            prevMoveSpeed = moveSpeed;
            prevFireInterval = fireInterval;
        }

        // 毎フレームタイマー更新
        fireTimer += Time.deltaTime;

        // 入力処理（Input System）
        float moveZ = 0f;
        float rotate = 0f;
        if (Keyboard.current != null)
        {
            if (Keyboard.current.wKey.isPressed) moveZ += 1f;
            if (Keyboard.current.sKey.isPressed) moveZ -= 1f;
            if (Keyboard.current.aKey.isPressed) rotate -= 1f;
            if (Keyboard.current.dKey.isPressed) rotate += 1f;
        }

        // 前後移動のみ（wで前進、sで後退）
        inputMove = transform.forward * moveZ;
        if (inputMove.sqrMagnitude > 1f) inputMove = inputMove.normalized;

        // 回転
        if (rotate != 0f)
        {
            transform.Rotate(Vector3.up, rotate * rotationSpeed * Time.deltaTime);
        }

        // ジャンプ
        if (Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
        {
            if (rb != null) rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }

        // 左クリック押しっぱなしで3種同時発射（クールダウン付き）
        if (Mouse.current != null && Mouse.current.leftButton.isPressed)
        {
            if (fireTimer >= fireInterval)
            {
                ShootAllBullets();
                fireTimer = 0f;
            }
        }

        // カメラ追従
        if (Camera.main != null)
        {
            Vector3 cameraOffset = new Vector3(0, 2, -5);
            Camera.main.transform.position = transform.position + cameraOffset;
            Camera.main.transform.LookAt(transform.position + Vector3.up * 1.0f);
        }
    }

    void OnGUI()
    {
        if (!showUpgradeMenu) return;
        int btnWidth = 220, btnHeight = 50;
        int x = 20, y = 20;
        GUIStyle style = new GUIStyle(GUI.skin.button) { fontSize = 18 };

        // 射撃速度上昇ボタン
        if (cachedScore >= 5)
        {
            if (GUI.Button(new Rect(x, y, btnWidth, btnHeight), "射撃速度上昇 (スコア-5)"))
            {
                fireInterval *= 0.8f;
                if (hud != null) hud.UpdateScore(-5);
                Debug.Log("射撃速度が増えました");
            }
            y += btnHeight + 10;
        }

        // 移動速度上昇ボタン
        if (cachedScore >= 5)
        {
            if (GUI.Button(new Rect(x, y, btnWidth, btnHeight), "移動速度上昇 (スコア-5)"))
            {
                moveSpeed += 1f;
                if (hud != null) hud.UpdateScore(-5);
                Debug.Log("移動速度が増えました");
            }
            y += btnHeight + 10;
        }

        // どちらのボタンも押せない場合のメッセージ
        if (cachedScore < 5)
        {
            GUI.Label(new Rect(x, y, btnWidth, btnHeight), "スコアが足りない", style);
        }
    }

    void Shoot()
    {
        bulletPrefab = Resources.Load<GameObject>("Bullet");
        if (bulletPrefab == null || bulletSpawnPoint == null) return;

        GameObject bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        bullet.tag = "Bullet"; // 追加
        // Rigidbodyがあれば前方に力を加える
        Rigidbody brb = bullet.GetComponent<Rigidbody>();
        if (brb != null)
        {
            brb.AddForce(bulletSpawnPoint.forward * 20f, ForceMode.Impulse);
        }
        Destroy(bullet, 3f);
    }

    void ShootAllBullets()
    {
        // 通常弾
        Shoot();

        // 直進弾（コメント解除して使う場合）
        // if (straightBulletPrefab != null && bulletSpawnPoint != null)
        // {
        //     GameObject straight = Instantiate(straightBulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        //     straight.layer = gameObject.layer;
        //     straight.SetActive(true);
        //     var sb = straight.GetComponent<StraightBullet>();
        //     if (sb != null)
        //     {
        //         sb.Fire(bulletSpawnPoint.forward);
        //     }
        // }

        // 爆発弾
        if (explosiveBulletPrefab != null && bulletSpawnPoint != null)
        {
            GameObject explosive = Instantiate(explosiveBulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);

            Debug.Log("1はっしゃ");
            var explosiveCol = explosive.GetComponent<Collider>();
            var playerCol = GetComponent<Collider>();
            if (explosiveCol != null && playerCol != null)
            {
                Debug.Log("2はっしゃ");
                Physics.IgnoreCollision(explosiveCol, playerCol);
            }
            Debug.Log(explosive);
            var eb = explosive.GetComponent<ExplosiveBullet>();
            if (eb != null)
            {
                Debug.Log("3はっしゃ");
                eb.Fire(bulletSpawnPoint.forward + bulletSpawnPoint.up * 0.2f);
            }
        }
    }

    void FixedUpdate()
    {
        // 物理演算に合わせて移動
        if (rb == null) return;
        Vector3 velocity = rb.velocity;
        Vector3 move = inputMove * moveSpeed;
        rb.velocity = new Vector3(move.x, velocity.y, move.z);
    }

    void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }
}
