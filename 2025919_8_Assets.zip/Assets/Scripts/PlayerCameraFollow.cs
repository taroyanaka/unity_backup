using UnityEngine;

public class PlayerCameraFollow : MonoBehaviour
{
    public Transform target; // プレイヤー
    public Vector3 offset = new Vector3(0, 3f, -5f); // 上方後ろ側
    public float smoothSpeed = 5f;

    // groundの中心座標と高さ
    public Vector3 groundCenter = Vector3.zero;
    public float groundHeight = 10f;

    void LateUpdate()
    {
        if (target != null)
        {
            Vector3 desiredPosition = target.position + target.TransformDirection(offset);
            transform.position = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);
            transform.LookAt(target.position + Vector3.up * 1.0f);
        }
        else
        {
            // targetが未設定ならgroundの上方に固定し真下を向く
            transform.position = groundCenter + Vector3.up * groundHeight;
            transform.rotation = Quaternion.Euler(90, 0, 0);
        }
    }
}
