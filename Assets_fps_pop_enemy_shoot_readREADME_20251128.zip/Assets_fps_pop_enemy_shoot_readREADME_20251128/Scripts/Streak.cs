using UnityEngine;
using TMPro;

// キルストリークに応じてスコア加算値を変動させる管理。
// StreakRewardTable のインデックス(0始まり)はストリーク数-1に対応。
// 例: [1,1,1,2] -> 1〜3キル目 1点, 4キル目以降 2点 (テーブル長を超えた場合は最後の値を使用)
public class Streak : MonoBehaviour
{
    public static Streak Instance { get; private set; }

    [Header("Config")]
    [SerializeField, Tooltip("次のキルまでに許容されるストリーク継続時間(秒)")] private float streakWindow = 5f;
    [SerializeField, Tooltip("ストリークごとのスコア(インデックス=ストリーク数-1)。終端を超えたら最後を使用")] private int[] streakRewardTable = new int[] { 1, 1, 1, 2 };
    [SerializeField, Tooltip("テーブルが存在しても敵側のbaseScoreを加算するか")] private bool addBaseScore = false;

    [Header("Runtime State")]
    [SerializeField, Tooltip("現在の連続キル数")] private int currentStreak = 0;
    [SerializeField, Tooltip("最後のキル発生時刻")] private float lastKillTime = -999f;
    [Header("UI")]
    [SerializeField, Tooltip("HUD直下の Streak TextMeshPro 参照 (未設定なら自動検出)")] private TMP_Text streakText;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        AutoFindStreakText();
        UpdateStreakUI(force:true);
    }

    // 敵撃破時に呼び出す。baseScoreは Enemy 側の scoreValue。
    public void RegisterKill(int baseScore)
    {
        if (ScoreManager.Instance == null)
        {
            Debug.LogWarning("Streak: ScoreManager.Instance が存在しないため直接加算不可", this);
            return;
        }

        float now = Time.time;
        if (now - lastKillTime <= streakWindow)
        {
            currentStreak++;
        }
        else
        {
            currentStreak = 1; // リセット後最初のキル
        }
        lastKillTime = now;

        int reward = CalculateReward(baseScore, currentStreak);
        ScoreManager.Instance.AddScore(reward);

        UpdateStreakUI(force:true);
    }

    private int CalculateReward(int baseScore, int streakCount)
    {
        if (streakRewardTable == null || streakRewardTable.Length == 0)
        {
            return baseScore; // フォールバック: テーブル未設定
        }
        int idx = Mathf.Max(0, streakCount - 1);
        if (idx >= streakRewardTable.Length) idx = streakRewardTable.Length - 1;
        int tableVal = streakRewardTable[idx];
        return addBaseScore ? (baseScore + tableVal) : tableVal;
    }

    // 外部からストリーク状態を参照できる簡易API
    public int GetCurrentStreak() => currentStreak;
    public float GetRemainingWindow() => Mathf.Max(0f, streakWindow - (Time.time - lastKillTime));

    private void Update()
    {
        // ウィンドウ経過でストリークリセット
        if (currentStreak > 0 && (Time.time - lastKillTime) > streakWindow)
        {
            currentStreak = 0;
            UpdateStreakUI(force:true);
        }
    }

    // ゲーム再初期化時用
    public void ResetStreak()
    {
        currentStreak = 0;
        lastKillTime = -999f;
        UpdateStreakUI(force:true);
    }

    private void AutoFindStreakText()
    {
        if (streakText != null) return;
        // 名前 "Streak" の TMP_Text を探索（非アクティブ含む）
        var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
        foreach (var t in texts)
        {
            if (t != null && t.name == "Streak") { streakText = t; break; }
        }
    }

    private void UpdateStreakUI(bool force = false)
    {
        if (streakText == null) return;
        streakText.text = currentStreak.ToString();
    }
}
