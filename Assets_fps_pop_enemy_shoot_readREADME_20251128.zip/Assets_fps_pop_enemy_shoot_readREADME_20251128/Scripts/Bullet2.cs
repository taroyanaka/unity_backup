using UnityEngine;

// Bullet2: Bullet と同等の挙動。指定方向へ移動し寿命で消滅。
public class Bullet2 : MonoBehaviour
{
	private Vector3 moveDir = Vector3.forward;
	private float speed = 1f;
	private float life;
	private float spawnTime;
	[SerializeField] private float defaultLifetime = 1f; // Prefabごとの既定寿命
	[SerializeField] private float fireRate = 8f; // この弾種の発射レート(発/秒)
	[SerializeField, Tooltip("この弾をアンロックする消費スコア")] private int price = 3;
	public float BaseSpeed => speed;
	public float DefaultLifetime => defaultLifetime;
	public float FireRate => fireRate;
	public int Price => price;

	// Player から生成時に設定される想定
	public void Init(Vector3 direction, float speed, float lifeTime)
	{
		this.moveDir = direction.normalized;
		this.speed = Mathf.Max(0f, speed);
		this.life = Mathf.Max(0.01f, lifeTime);
		this.spawnTime = Time.time;
	}

	private void Update()
	{
		transform.position += moveDir * speed * Time.deltaTime;

		if (Time.time - spawnTime >= life)
		{
			Destroy(gameObject);
		}
	}
}
