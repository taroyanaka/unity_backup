using UnityEngine;
using TMPro;

public class PlayTimeManager : MonoBehaviour
{
    [Header("Refs")] 
    [SerializeField, Tooltip("HUD直下のPlayTimeのTextMeshPro (未設定なら名前で探索)")] private TMP_Text playTimeText;

    private float elapsedSeconds; // 経過時間(秒)
    private bool paused; // 手動一時停止（Boss出現時など）

    public int ElapsedSeconds => Mathf.FloorToInt(elapsedSeconds);

    private void Awake()
    {
        if (playTimeText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "PlayTime") { playTimeText = t; break; }
            }
        }
        elapsedSeconds = 0f;
        paused = false;
        UpdateText(0);
    }

    private void Update()
    {
        // PowerUp中は timeScale=0 で deltaTime=0。Boss時は手動 paused フラグで停止。
        if (!paused)
        {
            elapsedSeconds += Time.deltaTime; // timeScale に従う（必要なら unscaledDeltaTime へ変更可能）
            UpdateText(ElapsedSeconds);
        }
    }

    private void UpdateText(int totalSeconds)
    {
        if (playTimeText == null) return;
        int mm = totalSeconds / 60;
        int ss = totalSeconds % 60;
        playTimeText.text = $"{mm:00}:{ss:00}";
    }

    public void ResetTimer()
    {
        elapsedSeconds = 0f;
        paused = false; // リセット時に一時停止も解除
        UpdateText(0);
    }

    public void PauseTimer()
    {
        paused = true;
    }

    public void ResumeTimer()
    {
        paused = false;
    }
}
