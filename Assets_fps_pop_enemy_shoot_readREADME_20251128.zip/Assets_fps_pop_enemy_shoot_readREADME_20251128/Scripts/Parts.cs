using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// パーツの定義データ（ID、表示名、価格、ボーナス）
/// </summary>
[Serializable]
public class PartDefinition
{
    [Tooltip("一意のID (例: HpUp)")] 
    public string id = "";
    
    [Tooltip("表示名")] 
    public string displayName = "";
    
    [Tooltip("購入価格(Gold)")] 
    public int goldPrice = 1;
    
    [Header("Bonuses (加算)")]
    [Tooltip("初期HPへの加算値")] 
    public float hpAdd = 0f;
    
    [Tooltip("移動速度への加算値 (m/s)")] 
    public float speedAdd = 0f;
}

/// <summary>
/// パーツ管理 - パーツ定義データのみを保持
/// 購入処理は BuyMenuManager で行う
/// </summary>
public class PartsManager : MonoBehaviour
{
    public static PartsManager Instance { get; private set; }

    [Header("Available Parts")]
    [SerializeField, Tooltip("購入可能なパーツ一覧")] 
    private List<PartDefinition> availableParts = new List<PartDefinition>
    {
        new PartDefinition
        {
            id = "HpUp",
            displayName = "Hp Up",
            goldPrice = 5,
            hpAdd = 3f,
            speedAdd = 0f
        },
        new PartDefinition
        {
            id = "SpeedUp",
            displayName = "Speed Up",
            goldPrice = 7,
            hpAdd = 0f,
            speedAdd = 1.5f
        },
        new PartDefinition
        {
            id = "HeavyHp",
            displayName = "Heavy Hp",
            goldPrice = 15,
            hpAdd = 8f,
            speedAdd = -0.8f
        },
        new PartDefinition
        {
            id = "TurboSpeed",
            displayName = "Turbo Speed",
            goldPrice = 12,
            hpAdd = -2f,
            speedAdd = 3.2f
        }
    };

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    /// <summary>
    /// すべてのパーツ定義を取得
    /// </summary>
    public IReadOnlyList<PartDefinition> GetAllParts()
    {
        return availableParts;
    }

    /// <summary>
    /// ID からパーツ定義を検索
    /// </summary>
    public PartDefinition GetDefinition(string id)
    {
        if (string.IsNullOrEmpty(id)) return null;
        if (availableParts == null) return null;
        
        foreach (var part in availableParts)
        {
            if (part != null && part.id == id)
            {
                return part;
            }
        }
        return null;
    }

    /// <summary>
    /// 購入済みパーツの合計ボーナスを計算
    /// </summary>
    public static (float hpAdd, float speedAdd) GetTotalBonuses()
    {
        float hp = 0f;
        float spd = 0f;
        
        if (Instance == null) return (0f, 0f);
        
        var purchasedList = Global.purchasedPartIds;
        if (purchasedList == null || purchasedList.Count == 0) 
        {
            return (0f, 0f);
        }

        for (int i = 0; i < purchasedList.Count; i++)
        {
            var id = purchasedList[i];
            var def = Instance.GetDefinition(id);
            if (def == null) continue;
            
            hp += Mathf.Max(0f, def.hpAdd);
            spd += def.speedAdd;
        }
        
        return (hp, spd);
    }
}
