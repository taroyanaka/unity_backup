using UnityEngine;
using System.Collections.Generic;
using System;

public class Global : MonoBehaviour
{
    // =====================================================================
    // ゲームバランス設定（初期値/調整用定数）
    // =====================================================================
    public const int INIT_GOLD = 10;  // 初期ゴールド（リセット時もこの値を使用）
    
    // グローバル設定（static）
    public static float player_hp = 1f;
    public static float bullet_atk = 5f;
    public static float enemy_hp = 10f;
    public static float enemy_atk = 1f;
    public static float enemy_spd = 1f;
    public static int clear_score = 10;
    public static int gold = INIT_GOLD; // 所持ゴールド（取得/消費で増減）
    
    // 購入済みパーツ（IDのリスト）
    public static List<string> purchasedPartIds = new List<string>();
    
    // 購入済みパワーアップアイテム（IDのリスト）
    public static List<string> purchasedPowerUpItemIds = new List<string>();
    
    // Enemy2 用
    public static float enemy2_hp = 3f;          // 要望: 初期HP=3
    public static float enemy2_bullet_atk = 1f;  // 要望: 弾のATK=1

    // Player 複数弾スロット上限
    public static int player_max_bullet_slots = 3; // 装備できる弾種の最大数
 
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // ============ Save/Load (single slot, auto-save helpers) ============
    private const string KeyGold = "save_gold";
    private const string KeyParts = "save_parts"; // CSV by ','
    private const string KeyPowerUpItems = "save_powerup_items"; // CSV by ','

    public static void SaveProgress()
    {
        try
        {
            Debug.Log($"[Global] SaveProgress called: gold = {gold}, purchasedPartIds.Count = {purchasedPartIds.Count}, purchasedPowerUpItemIds.Count = {purchasedPowerUpItemIds.Count}");
            
            PlayerPrefs.SetInt(KeyGold, Mathf.Max(0, gold));
            Debug.Log($"[Global] Saved gold: {Mathf.Max(0, gold)} to PlayerPrefs with key '{KeyGold}'");
            
            string csv = string.Join(',', purchasedPartIds ?? new List<string>());
            PlayerPrefs.SetString(KeyParts, csv);
            Debug.Log($"[Global] Saved parts CSV: '{csv}' to PlayerPrefs with key '{KeyParts}'");
            
            string csvPowerUp = string.Join(',', purchasedPowerUpItemIds ?? new List<string>());
            PlayerPrefs.SetString(KeyPowerUpItems, csvPowerUp);
            Debug.Log($"[Global] Saved power-up items CSV: '{csvPowerUp}' to PlayerPrefs with key '{KeyPowerUpItems}'");
            
            PlayerPrefs.Save();
            Debug.Log("[Global] PlayerPrefs.Save() completed");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.SaveProgress: failed: {e.Message}");
        }
    }

    public static void LoadProgress()
    {
        try
        {
            Debug.Log($"[Global] LoadProgress: Before - gold = {gold}, purchasedPartIds.Count = {purchasedPartIds.Count}, purchasedPowerUpItemIds.Count = {purchasedPowerUpItemIds.Count}");
            
            if (PlayerPrefs.HasKey(KeyGold)) 
            {
                gold = Mathf.Max(0, PlayerPrefs.GetInt(KeyGold, INIT_GOLD));
                Debug.Log($"[Global] Loaded gold from PlayerPrefs: {gold}");
            }
            else
            {
                gold = INIT_GOLD;
                Debug.Log($"[Global] No KeyGold in PlayerPrefs, reset gold to INIT_GOLD: {gold}");
            }
            
            if (PlayerPrefs.HasKey(KeyParts))
            {
                string csv = PlayerPrefs.GetString(KeyParts, string.Empty);
                purchasedPartIds.Clear();
                if (!string.IsNullOrEmpty(csv))
                {
                    var items = csv.Split(',');
                    for (int i = 0; i < items.Length; i++)
                    {
                        var id = items[i]?.Trim();
                        if (!string.IsNullOrEmpty(id)) purchasedPartIds.Add(id);
                    }
                }
                Debug.Log($"[Global] Loaded {purchasedPartIds.Count} purchased parts from PlayerPrefs");
            }
            else
            {
                Debug.Log($"[Global] No KeyParts in PlayerPrefs, keeping default parts");
            }
            
            if (PlayerPrefs.HasKey(KeyPowerUpItems))
            {
                string csv = PlayerPrefs.GetString(KeyPowerUpItems, string.Empty);
                purchasedPowerUpItemIds.Clear();
                if (!string.IsNullOrEmpty(csv))
                {
                    var items = csv.Split(',');
                    for (int i = 0; i < items.Length; i++)
                    {
                        var id = items[i]?.Trim();
                        if (!string.IsNullOrEmpty(id)) purchasedPowerUpItemIds.Add(id);
                    }
                }
                Debug.Log($"[Global] Loaded {purchasedPowerUpItemIds.Count} purchased power-up items from PlayerPrefs");
            }
            else
            {
                Debug.Log($"[Global] No KeyPowerUpItems in PlayerPrefs, keeping default");
            }
            
            Debug.Log($"[Global] LoadProgress complete: gold = {gold}, purchasedPartIds.Count = {purchasedPartIds.Count}, purchasedPowerUpItemIds.Count = {purchasedPowerUpItemIds.Count}");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.LoadProgress: failed: {e.Message}");
        }
    }

    public static void DeleteSave()
    {
        try
        {
            Debug.Log("[Global] DeleteSave called - Deleting all save data");
            Debug.Log($"[Global] Before delete: gold = {gold}");
            
            PlayerPrefs.DeleteKey(KeyGold);
            Debug.Log($"[Global] Deleted key '{KeyGold}'");
            
            PlayerPrefs.DeleteKey(KeyParts);
            Debug.Log($"[Global] Deleted key '{KeyParts}'");
            
            PlayerPrefs.DeleteKey(KeyPowerUpItems);
            Debug.Log($"[Global] Deleted key '{KeyPowerUpItems}'");
            
            PlayerPrefs.Save();
            Debug.Log("[Global] PlayerPrefs.Save() completed after delete");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.DeleteSave: failed: {e.Message}");
        }
    }
}
