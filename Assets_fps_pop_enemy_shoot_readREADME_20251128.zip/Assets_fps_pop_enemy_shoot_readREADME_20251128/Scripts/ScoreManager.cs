using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    [Header("UI")]
    [SerializeField, Tooltip("スコア表示に使う TextMeshPro (UI)")]
    private TMP_Text scoreText;

    [SerializeField, Tooltip("表示フォーマット。{0} にスコアが入ります")]
    private string displayFormat = "Score: {0}";

    [SerializeField, Tooltip("プレイヤーHP表示に使う TextMeshPro (UI)")]
    private TMP_Text playerHpText;

    [SerializeField, Tooltip("HP表示フォーマット。{0} にHP(整数)が入ります")]
    private string hpDisplayFormat = "HP: {0}";

    [Header("PowerUp Config")]
    [SerializeField, Tooltip("何点ごとにPower_Upを提示するか（0で無効）")] private int scoreInterval = 0;
    [SerializeField, Tooltip("提示する候補（BulletまたはBullet2のプレハブ）")] private GameObject[] bulletCandidates;
    [SerializeField, Tooltip("パワーアップ提示用のTMP_Text（自動探索）")] private TMP_Text offerText;
    [SerializeField, Tooltip("プレイヤー参照（未設定ならタグ'Player'で探索）")] private Player player;

    [Header("State")]
    [SerializeField, Tooltip("現在のスコア（開始値）")] private int score = 0;
    private bool gameStopped;
    private int lastProcessedScore = -1;
    private bool isDisplaying = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        // スコア表示の自動検出（未割り当ての場合のみ）
        if (scoreText == null)
        {
            var go = GameObject.Find("Score");
            if (go != null)
            {
                scoreText = go.GetComponent<TMP_Text>();
            }
            if (scoreText == null)
            {
                // シーン内から名前で探す（非アクティブも含む）
                var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
                foreach (var t in texts)
                {
                    if (t != null && t.name == "Score") { scoreText = t; break; }
                }
            }
        }

        // プレイヤーHP表示の自動検出（未割り当ての場合のみ）
        if (playerHpText == null)
        {
            var go = GameObject.Find("Player_Hp");
            if (go != null)
            {
                playerHpText = go.GetComponent<TMP_Text>();
            }
            if (playerHpText == null)
            {
                var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
                foreach (var t in texts)
                {
                    if (t != null && t.name == "Player_Hp") { playerHpText = t; break; }
                }
            }
        }

        // Player 参照を確保
        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null)
            {
                player = pObj.GetComponent<Player>();
            }
        }

        // TMP_Text 参照を確保（Power_Upパネルのテキストを探す）
        if (offerText == null)
        {
            var go = GameObject.Find("Power_Up");
            if (go != null)
            {
                var texts = go.GetComponentsInChildren<TMP_Text>();
                if (texts != null && texts.Length > 0)
                {
                    offerText = texts[0];
                }
            }
        }

        UpdateUI();
        UpdateHpUI(force:true);
        CheckClearAndStop();
        lastProcessedScore = -1;
    }

    public void AddScore(int delta)
    {
        if (delta == 0) return;
        score += delta;
        if (score < 0) score = 0;
        UpdateUI();
        CheckClearAndStop();
    }

    public void RemoveScore(int delta)
    {
        if (delta == 0) return;
        score -= delta;
        if (score < 0) score = 0;
        UpdateUI();
        CheckClearAndStop();
    }

    public void SetScore(int value)
    {
        score = Mathf.Max(0, value);
        UpdateUI();
        CheckClearAndStop();
    }

    public int GetScore() => score;

    private void UpdateUI()
    {
        if (scoreText != null)
        {
            scoreText.text = string.Format(displayFormat, score);
        }
    }

    private int _cachedHpInt = int.MinValue;
    private void Update()
    {
        // HPの差分更新（毎フレームだが変更時のみ反映）
        UpdateHpUI();
        
        // PowerUp表示中の入力処理
        if (isDisplaying)
        {
            HandlePowerUpInput();
        }
    }

    private void LateUpdate()
    {
        // スコア更新後のPower_Upパネル表示判定（LateUpdateで後処理）
        if (!isDisplaying && scoreInterval > 0)
        {
            int currentScore = score;
            if (currentScore > lastProcessedScore)
            {
                if (currentScore % scoreInterval == 0)
                {
                    ShowPowerUpOffer(currentScore);
                    lastProcessedScore = currentScore;
                }
                else
                {
                    lastProcessedScore = currentScore;
                }
            }
        }
    }

    private void UpdateHpUI(bool force = false)
    {
        if (playerHpText == null) return;
        int hpInt = Mathf.Max(0, Mathf.CeilToInt(Global.player_hp));
        if (!force && hpInt == _cachedHpInt) return;
        _cachedHpInt = hpInt;
        playerHpText.text = string.Format(hpDisplayFormat, hpInt);
    }

    private void CheckClearAndStop()
    {
        if (gameStopped) return;
        // クリアスコアが未設定の場合はスキップ
        int target = Mathf.Max(0, Global.clear_score);
        if (score >= target && target > 0)
        {
            gameStopped = true;
            Time.timeScale = 0f;
            // Removed verbose game clear log
        }
    }

    // GameOver後など再スタート用
    public void ResetGameState()
    {
        gameStopped = false;
        score = 0;
        lastProcessedScore = -1;
        isDisplaying = false;
        UpdateUI();
        UpdateHpUI(force:true);
    }

    /// <summary>
    /// Power_Upパネルを表示してオファーを表示
    /// </summary>
    private void ShowPowerUpOffer(int currentScore)
    {
        isDisplaying = true;
        
        // ゲームを一時停止
        Time.timeScale = 0f;
        
        // HUDVisibilityManagerでPower_Upパネルを表示
        HUDVisibilityManager.ShowPowerUpOffer();
        
        // オファーメッセージを表示
        UpdateOfferText(currentScore);
    }

    /// <summary>
    /// Power_Upパネルを非表示にしてゲームを再開
    /// </summary>
    private void HidePowerUpOffer()
    {
        isDisplaying = false;
        
        // ゲーム再開
        Time.timeScale = 1f;
        
        // HUDVisibilityManagerでゲームプレイ画面に戻す
        HUDVisibilityManager.ShowGameplay();
        
        // テキストをクリア
        if (offerText != null)
        {
            offerText.text = "";
        }
    }

    /// <summary>
    /// Power_Up表示中の入力を処理（買うかスキップか）
    /// </summary>
    private void HandlePowerUpInput()
    {
        var mouse = Mouse.current;
        var keyboard = Keyboard.current;

        // 左クリック = 購入
        bool buyInput = mouse != null && mouse.leftButton.wasPressedThisFrame;
        
        // 右クリック or ESC = スキップ
        bool skipInput = (mouse != null && mouse.rightButton.wasPressedThisFrame) ||
                         (keyboard != null && keyboard.escapeKey.wasPressedThisFrame);

        if (buyInput)
        {
            TryPurchaseBullet();
        }
        else if (skipInput)
        {
            HidePowerUpOffer();
        }
    }

    /// <summary>
    /// オファーテキストを更新
    /// </summary>
    private void UpdateOfferText(int currentScore)
    {
        if (offerText == null)
        {
            return;
        }

        var candidate = GetNextBulletCandidate();
        if (candidate == null)
        {
            offerText.text = "No PowerUp Available";
            return;
        }

        int price = GetBulletPrice(candidate);
        string name = candidate.name;
        
        string message = $"<b>Power-Up Offer</b>\n\n" +
                        $"<size=80%>{name}</size>\n" +
                        $"<size=80%>Price: {price} points</size>\n\n" +
                        $"<size=70%>[Left Click] Buy  [Right/ESC] Skip</size>";
        
        offerText.text = message;
    }

    /// <summary>
    /// 弾種購入を試みる
    /// </summary>
    private void TryPurchaseBullet()
    {
        var candidate = GetNextBulletCandidate();

        if (candidate == null)
        {
            HidePowerUpOffer();
            return;
        }

        int price = GetBulletPrice(candidate);
        string bulletName = candidate.name;

        // スコアが十分か確認
        if (score < price)
        {
            if (offerText != null)
            {
                offerText.text = $"Not enough points!\nRequired: {price}\nCurrent: {score}";
            }
            return;
        }

        // プレイヤーに弾を追加できるか確認
        if (player == null)
        {
            HidePowerUpOffer();
            return;
        }

        if (!player.TryAddBulletPrefab(candidate))
        {
            if (offerText != null)
            {
                offerText.text = $"Cannot add {bulletName}\n(Slots full or duplicate)";
            }
            return;
        }

        // スコアを消費
        int newScore = score - price;
        SetScore(newScore);

        // 購入完了メッセージ
        if (offerText != null)
        {
            offerText.text = $"<color=lime>Unlocked: {bulletName}</color>";
        }

        // パネルを非表示
        HidePowerUpOffer();
    }

    /// <summary>
    /// 次の弾種候補を取得
    /// </summary>
    private GameObject GetNextBulletCandidate()
    {
        if (bulletCandidates == null || bulletCandidates.Length == 0)
        {
            return null;
        }

        for (int i = 0; i < bulletCandidates.Length; i++)
        {
            if (bulletCandidates[i] != null)
            {
                return bulletCandidates[i];
            }
        }

        return null;
    }

    /// <summary>
    /// 弾プレハブの価格を取得
    /// </summary>
    private int GetBulletPrice(GameObject prefab)
    {
        if (prefab == null)
        {
            return int.MaxValue;
        }

        // Bullet コンポーネントをチェック
        var bullet = prefab.GetComponent<Bullet>();
        if (bullet != null)
        {
            return Mathf.Max(0, bullet.Price);
        }

        // Bullet2 コンポーネントをチェック
        var bullet2 = prefab.GetComponent<Bullet2>();
        if (bullet2 != null)
        {
            return Mathf.Max(0, bullet2.Price);
        }

        // Bullet3 コンポーネントをチェック
        var bullet3 = prefab.GetComponent<Bullet3>();
        if (bullet3 != null)
        {
            return Mathf.Max(0, bullet3.Price);
        }

        // デフォルト価格
        return 5;
    }
}
