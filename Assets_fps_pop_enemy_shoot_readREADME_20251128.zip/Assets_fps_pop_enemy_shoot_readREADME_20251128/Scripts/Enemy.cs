using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField, Tooltip("この敵の現在HP（AwakeでGlobalから初期化）")]
    private float enemy_hp;

    [SerializeField, Tooltip("この敵の攻撃力（AwakeでGlobalから初期化）")]
    private float enemy_atk;

    [SerializeField, Tooltip("この敵を倒した際に取得するスコア値" )]
    private int scoreValue = 1;

    // enemyのspeedを定義
    private float enemy_speed;

    private bool isDead;

    [Header("Coin Drop")]
    [SerializeField, Tooltip("ドロップするCoinプレハブ")]
    private GameObject coinPrefab;
    [SerializeField, Tooltip("撃破時に落とすコイン数")] private int coinDropCount = 1;
    [SerializeField, Tooltip("コイン寿命(秒)")] private float coinLifeSeconds = 5f;
    [SerializeField, Tooltip("1コインのゴールド価値")] private int coinGoldValue = 1;

    private enum Behavior
    {
        ChasePlayer,
        Roam
    }

    private Behavior behavior;
    private Transform player;

    [SerializeField, Tooltip("ローム移動で方向を切り替える間隔（秒）")]
    private float roamChangeInterval = 2f;

    private float roamTimer;
    private Vector3 roamDirection;

    //enemyがplayerに向かって移動する関数
    private void FixedUpdate()
    {
        if (isDead) return;

        switch (behavior)
        {
            case Behavior.ChasePlayer:
                UpdateChase();
                break;
            case Behavior.Roam:
                UpdateRoam();
                break;
        }
    }

    void Awake()
    {
        // Global から代入（オブジェクトの実体に設定）
        enemy_hp = Global.enemy_hp;
        enemy_atk = Global.enemy_atk;
        enemy_speed = Global.enemy_spd;

        // 1/2 の確率で行動モードを決定（スポーン時）
        behavior = (Random.value < 0.5f) ? Behavior.ChasePlayer : Behavior.Roam;

        // 追跡モードの場合は一度だけキャッシュ試行（見つからなければ追跡中に再検索）
        var pObj = GameObject.FindWithTag("Player");
        if (pObj != null) player = pObj.transform;

        // ロームの初期方向
        if (behavior == Behavior.Roam)
        {
            ChooseNewRoamDirection();
        }
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void UpdateChase()
    {
        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null) player = pObj.transform;
            if (player == null) return; // プレイヤー不在
        }

        Vector3 playerPosition = player.position;
        Vector3 enemyPosition = transform.position;
        Vector3 direction = playerPosition - enemyPosition;
        direction.y = 0f;
        if (direction.sqrMagnitude <= 0.0001f) return;
        direction.Normalize();

        transform.position += direction * enemy_speed * Time.fixedDeltaTime;
        Quaternion lookRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.fixedDeltaTime * 5f);
    }

    private void UpdateRoam()
    {
        roamTimer -= Time.fixedDeltaTime;
        if (roamTimer <= 0f || roamDirection == Vector3.zero)
        {
            ChooseNewRoamDirection();
        }

        transform.position += roamDirection * enemy_speed * Time.fixedDeltaTime;
        if (roamDirection != Vector3.zero)
        {
            Quaternion lookRotation = Quaternion.LookRotation(roamDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.fixedDeltaTime * 5f);
        }
    }

    private void ChooseNewRoamDirection()
    {
        roamTimer = roamChangeInterval;
        int pick = Random.Range(0, 4);
        switch (pick)
        {
            case 0:
                roamDirection = Vector3.forward;
                break;
            case 1:
                roamDirection = Vector3.back;
                break;
            case 2:
                roamDirection = Vector3.left;
                break;
            case 3:
                roamDirection = Vector3.right;
                break;
        }
    }

    // Bullet 側の Trigger ヒットから呼ばれる想定
    public void TakeDamage(float damage)
    {
        if (isDead) return;
        // Removed verbose damage log
        enemy_hp -= damage;
        if (enemy_hp <= 0f)
        {
            isDead = true;
            // Removed verbose death log
            // スコア加算（存在すれば）
            // キルストリーク管理があればそちら経由、なければ直接加算
            if (global::Streak.Instance != null)
            {
                global::Streak.Instance.RegisterKill(scoreValue);
            }
            else if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.AddScore(scoreValue);
            }
            // コインドロップ
            DropCoins();
            Destroy(gameObject);
        }
    }

    // bulletのonTriggerがtrue、bulletタグがenemyタグに当たったとき
    private void OnTriggerEnter(Collider collision)
    {
        var other = collision.gameObject;

        // bullet タグに当たったらダメージ
        if (other != null && other.CompareTag("bullet"))
        {
            // Removed verbose bullet hit log
            TakeDamage(Global.bullet_atk);
        }

        // Playerタグのついたオブジェクトに当たったらダメージを与える
        if (other != null && other.CompareTag("Player"))
        {
            // プレイヤーに接触したら一撃分ダメージを与え、敵は消滅
            HandleTouchPlayer();
        }   
    }

    // Trigger ではなく通常のコリジョン接触にも対応
    private void OnCollisionEnter(Collision collision)
    {
        var other = collision.gameObject;
        if (other != null && other.CompareTag("Player"))
        {
            HandleTouchPlayer();
        }
    }

    private void HandleTouchPlayer()
    {
        if (isDead) return;
        // player にダメージを与えた上で自身を消去
        Global.player_hp -= enemy_atk;
        isDead = true;
        Destroy(gameObject);
    }

    private void DropCoins()
    {
        if (coinPrefab == null || coinDropCount <= 0) return;
        Coin.SpawnBurst(coinPrefab, transform.position, coinDropCount, coinLifeSeconds, coinGoldValue);
    }

}