// =============================================
// README.cs (仕様概要: Scripts配下クラス一覧)
// 本ファイルは参照用のコメントのみを含み、ゲームロジックは持ちません。
// 各 .cs ファイルの目的を 1 行で記述しています。
// =============================================
// Unity バージョン: 6000.2.7f2
// 最終更新: 2025年11月28日
// =============================================
// ■ ゲームロジック系
// =============================================
// Enemy.cs            : 基本的な敵キャラ。プレイヤーへ接近・被弾処理・スコア加算を担当。
// Enemy2.cs           : 徘徊しながら一定間隔で弾を発射する敵の派生。Global の enemy2 設定を参照。
// Enemy3.cs           : 追加バリエーション敵（詳細挙動はクラス内部参照）。
// EnemySpawner.cs     : 敵のスポーン管理。一定条件/間隔で Enemy 系を生成する制御。
// Boss.cs             : Enemy2 ベースの強化版ボス。高HP/高スコア、弾射撃とうろつき行動。
// BossSpawner.cs      : PlayTime 経過に応じて Boss を最大出現数まで生成し、出現時にタイマーを停止可能。
// Coin.cs             : 一定時間で自動消滅し、消滅時に Global.gold を加算するコイン。敵撃破時のドロップ用。
// Player.cs           : プレイヤー操作・HP・弾スロット管理などコア挙動を担当。
// Bullet.cs           : 基本弾挙動。初期化パラメータに応じて移動し寿命で破棄。
// Bullet2.cs          : 追加弾種その1（威力や特性差異はクラス内実装を参照）。
// Bullet3.cs          : 追加弾種その2（さらなる特性差異を持つ弾）。
// Enemy2Bullet.cs     : Enemy2/Boss 生成弾のダメージ処理・プレイヤー当たり判定。
// PowerUpManager.cs   : スコア到達でゲームを一時停止し、弾種パワーアップ購入/スキップを提示。
// PlayTimeManager.cs  : ゲームプレイ時間(mm:ss)を計測。PowerUpやBoss出現時の一時停止に対応。
// PauseMenuManager.cs : ESCキーでポーズメニュー開閉。Time.timeScaleとPlayTimeManagerで一時停止/再開を制御。
// ScoreManager.cs     : スコアの取得・加算・消費管理。Singleton で全体参照を提供。RemoveScore() でスコア消費に対応。
// Streak.cs           : 連続撃破（キルストリーク）管理。連続数によるボーナス等の登録処理。
// GameOverManager.cs  : HP<=0検知しGame_Over表示。最終スコア/ゲーム時間表示とMenuボタンでゲーム再開制御。
//
// ■ UI・メニュー系（マネージャー）
// =============================================
// Global.cs             : ゲーム全体の永続状態と設定。static変数でgold, purchasedPartIds, purchasedPowerUpItemIds,
//                         ゲームバランス調整値を管理。
//                         SaveProgress() / LoadProgress() で PlayerPrefs に金、購入部品、購入パワーアップを保存/復元。
//                         DeleteSave() で保存データを削除。
//
// StartMenuManager.cs   : スタートメニュー画面の制御。Start/Buy/DeleteSaveボタンをリッスン。
//                         Startクリック→ゲーム開始、Buyクリック→BuyMenuManager.ShowBuyMenu()呼び出し、
//                         DeleteSaveクリック→Global.DeleteSave()と購入履歴をリセット。
//
// BuyMenuManager.cs     : パーツ購入メニューの表示・購入処理。PartsManager.GetAllParts()から部品リストを取得。
//                         Global.gold を UI に表示し、購入ボタン（1-9キーまたはマウスクリック）で部品購入を実行。
//                         購入時に gold をデダクト、purchasedPartIds に追加、Global.SaveProgress() で永続化。
//                         キー操作: 1-9で該当部品購入、ESC/Backで Buy_Menu を非表示。
//
// PowerUpMenuManager.cs : スコア到達時に表示するパワーアップアイテム購入メニュー。PowerUpItemsManager.GetAllItems()
//                         からアイテムリストを取得。scoreText/ownedItemsText/availableItemsText で 3セクション表示。
//                         キーボード（1-9）またはボタンクリックでアイテム購入。ScoreManager.RemoveScore()で消費。
//                         購入済みアイテムを purchasedPowerUpItemIds に追加、Global.SaveProgress() で永続化。
//                         キー操作: 1-9でアイテム購入、ESC/BackボタンでGameplayに戻る。
//
// HUDVisibilityManager.cs : HUD要素全体の表示/非表示を一元管理。Singleton パターンで全マネージャから参照可能。
//                           HudState enum で状態管理。ShowGameplay/ShowBuyMenu/ShowPowerUpOffer等のメソッドで画面遷移。
//                           各画面で必要なキャンバスのみ表示し、不要なものは隠す。
//
// Parts.cs            : パーツシステム。PartDefinition クラスでパーツの定義（ID/名前/価格/HP・速度ボーナス）を持つ。
//                       PartsManager クラスで全部品リストを管理し、GetAllParts() / GetDefinition(id) で取得。
//                       GetTotalBonuses() で購入部品から合計ボーナスを計算。
//                       データのみを持ち、購入ロジックは BuyMenuManager で実装。
//
// PowerUpItems.cs     : パワーアップアイテムシステム。PowerUpItemDefinition クラスでアイテムの定義
//                       （ID/名前/スコア価格/ATKボーナス）を持つ。
//                       PowerUpItemsManager クラスで全アイテムリストを管理し、GetAllItems() / GetDefinition(id) で取得。
//                       GetTotalBonuses() で購入済みアイテムから合計ATKボーナスを計算。
//                       データのみを持ち、購入ロジックは PowerUpMenuManager で実装。
//
// =============================================
// メンテナンス指針:
// - 新規スクリプト追加時は同様に説明をここへ追記し、カテゴリを明記。
// - 詳細仕様変更で目的が変わった場合は行の更新を行う。
// - 実行時依存は持たないためビルドへの影響なし。
// =============================================

// =============================================
// 推奨シーン構成（オブジェクト/命名規約）
// - 自動検出に用いているオブジェクト名を中心に記載。
// - 可能な限り以下の命名に合わせるとスクリプトの参照設定が省略可能。
// =============================================
// Root
// - Main Camera
// - Directional Light
// - Spawners/
//     - EnemySpawner (複数可)
//     - BossSpawner  (任意)
// - Systems/
//     - ScoreManager
//     - PlayTimeManager
//     - Streak
//     - PowerUpItemsManager (自動生成)
//     - PauseMenuManager
//     - StartMenuManager
//     - BuyMenuManager
//     - PowerUpMenuManager
//     - GameOverManager
//     - HUDVisibilityManager (Singleton)
// - PlayerSpawnPoint (任意: Start時に Player をここへ生成)
// - HUD (Canvas)
//     - Score              [TMP_Text]
//     - Player_Hp          [TMP_Text]
//     - PlayTime           [TMP_Text]
//     - Streak             [TMP_Text]
//     - Score_Text         [TMP_Text] ← パワーアップメニュー用スコア表示
//     - Power_Up           [GameObject] ← パワーアップメニュー画面パネル（PowerUpMenuManager が制御）
//         - Owned_Items_Text    [TMP_Text]      ← 購入済みアイテム表示（自動生成）
//         - Available_Items_Text [TMP_Text]     ← 購入可能なアイテム表示（自動生成）
//         - PowerUp_Back_Button  [Button]       ← パワーアップメニューから戻るボタン
//         - Items_Container      [Transform]    ← アイテムボタンの配置先（オプション）
//     - Menu               [GameObject/TMP等]  ← ポーズメニューの表示用
//         - Resume_Button  [Button]
//     - Game_Over          [GameObject]        ← ゲームオーバー画面パネル
//         - GameOver_Menu_Button [Button]     ← Menu に戻るボタン
//     - Start_Menu         [GameObject]        ← スタートメニュー画面パネル
//         - Start_Button       [Button]        ← ゲーム開始
//         - Buy_Button         [Button]        ← パーツ購入メニューへ
//         - Delete_Save_Button [Button]        ← セーブ削除
//     - Buy_Menu           [GameObject]        ← パーツ購入メニュー画面パネル（BuyMenuManager が制御）
//         - Gold_Display    [TMP_Text]         ← 現在の金を表示（BuyMenuManagerが自動生成）
//         - Parts_Scroll_View [ScrollView]     ← パーツリスト用スクロールビュー（オプション）
//         - Back_Button     [Button]           ← Start_Menuに戻るボタン
//
// =============================================
// マネージャーの動作チェーン
// =============================================
// 1. ゲーム起動
//    → HUDVisibilityManager.Awake() : Singleton初期化
//    → Global.LoadProgress() : PlayerPrefsからgold、購入部品、購入パワーアップを復元
//    → StartMenuManager.ShowStartMenu() : スタートメニュー表示
//
// 2. Startボタン クリック
//    → StartMenuManager.OnStartClicked()
//    → HUDVisibilityManager.ShowGameplay()
//    → Player生成、ゲーム開始
//    → Player.Start()でパーツボーナス＋パワーアップアイテムボーナスをGlobal値に反映
//
// 3. Buyボタン クリック（スタートメニューから）
//    → StartMenuManager.OnBuyClicked()
//    → BuyMenuManager.ShowBuyMenu()
//    → PartsManager.GetAllParts()でパーツリスト取得
//    → RebuildBuyUI()でUI生成、パーツボタン表示
//    → Global.goldを goldText に表示
//
// 4. 部品購入（BuyMenuで）
//    → BuyMenuManager.OnPartButtonClicked(partId)
//    → 金が十分か確認 → gold -= price
//    → purchasedPartIds.Add(partId)
//    → Global.SaveProgress() : PlayerPrefsに保存
//    → RebuildBuyUI() : UI更新
//
// 5. BackまたはESC キー（BuyMenuから）
//    → BuyMenuManager.HideBuyMenu()
//    → HUDVisibilityManager.ShowStartMenu()
//    → スタートメニューに戻る
//
// 6. ゲーム進行中 - スコア=2到達
//    → HUDVisibilityManager.Update()でスコア監視
//    → ScoreManager.GetScore() == 2
//    → HUDVisibilityManager.ShowPowerUpOffer()
//    → Power_Up パネルを表示、PowerUpMenuManager.ShowPowerUpMenu()を呼び出し
//    → PowerUpItemsManager.GetAllItems()でアイテムリスト取得
//    → RebuildPowerUpUI()でUI生成（3セクション表示）
//    → ScoreManagerの現在スコアを表示
//    → 購入済みアイテムと購入可能なアイテムを分離表示
//
// 7. パワーアップアイテム購入（Power_Upメニューで）
//    → PowerUpMenuManager.OnItemButtonClicked(itemId) or キーボード1-9
//    → スコアが十分か確認 → ScoreManager.RemoveScore(price)
//    → purchasedPowerUpItemIds.Add(itemId)
//    → Global.SaveProgress() : PlayerPrefsに保存
//    → RebuildPowerUpUI() : UI更新
//
// 8. BackまたはESC キー（Power_Upメニューから）
//    → PowerUpMenuManager.HidePowerUpMenu()
//    → HUDVisibilityManager.ShowGameplay()
//    → ゲーム再開
//
// 9. ゲーム進行中（Pauseなど）
//    → ESCキー → PauseMenuManager : ポーズメニュー表示
//    → Resumeボタン or ESC再押下 : ゲーム再開
//
// 10. GameOver
//    → GameOverManager.ShowGameOver()
//    → 最終スコア・ゲーム時間表示
//    → Menu ボタンクリック
//    → Reset.ExecuteGameOverReset() : ゲーム状態リセット
//    → purchasedPowerUpItemIds.Clear() : ゲーム内購入のパワーアップをクリア
//    → HUDVisibilityManager.ShowStartMenu()
//    → スタートメニューに戻る（ゲームリセット）
//
// 11. セーブ削除（Delete_Save ボタン）
//    → StartMenuManager.OnDeleteSaveClickedInternal()
//    → Global.DeleteSave() : PlayerPrefs から金、部品、パワーアップを削除
//    → purchasedPartIds.Clear()
//    → purchasedPowerUpItemIds.Clear()
//    → Global.SaveProgress() : 空の状態を保存
//    → 次回起動時: Global.gold = 10 （初期値）
//
// =============================================
// パーツ購入システムのデータフロー
// =============================================
// PartsManager.GetAllParts()
//   ↓ PartDefinition[] (ID, 名前, 価格, HP/速度ボーナス)
// BuyMenuManager.RebuildBuyUI()
//   ↓ UI生成 (パーツボタン、金表示)
// ユーザー入力（ボタンクリックまたはキー1-9）
//   ↓
// BuyMenuManager.OnPartButtonClicked(partId) / TryPurchaseIndex(idx)
//   ↓ 購入可能か確認 (Global.gold >= price && 未購入)
//   ↓
// Global.gold -= price
// Global.purchasedPartIds.Add(partId)
// Global.SaveProgress()
//   ↓ PlayerPrefs['save_gold'] = gold
//   ↓ PlayerPrefs['save_parts'] = "id1,id2,id3,..."
// RebuildBuyUI() : 購入済み部品の表示を更新
//
// =============================================
// パワーアップアイテム購入システムのデータフロー
// =============================================
// PowerUpItemsManager.GetAllItems()
//   ↓ PowerUpItemDefinition[] (ID, 名前, スコア価格, ATKボーナス)
// PowerUpMenuManager.RebuildPowerUpUI()
//   ↓ UI生成 (3セクション表示: スコア, 購入済み, 購入可能)
// ユーザー入力（ボタンクリックまたはキー1-9）
//   ↓
// PowerUpMenuManager.TryPurchaseIndex(idx)
//   ↓ 購入可能か確認 (ScoreManager.GetScore() >= price)
//   ↓
// ScoreManager.RemoveScore(price)
// Global.purchasedPowerUpItemIds.Add(itemId)
// Global.SaveProgress()
//   ↓ PlayerPrefs['save_powerup_items'] = "id1,id2,id3,..."
// RebuildPowerUpUI() : 購入済みアイテムの表示を更新
//   ↓
// ゲーム再開時（Player.Start()）:
// PowerUpItemsManager.GetTotalBonuses()で合計ATKを計算
// Global.bullet_atkにボーナスを加算
//
// =============================================
// 補足（自動検出に使う主な名前）:
// - ScoreManager:    "Score", "Player_Hp"
// - PlayTimeManager: "PlayTime"
// - Streak:          "Streak"
// - PowerUpItemsManager: 自動生成
// - PowerUpMenuManager:  "Power_Up", "Score_Text", "Owned_Items_Text", "Available_Items_Text", "PowerUp_Back_Button"
// - PauseMenuManager: menuPanelに "Menu"
// - StartMenuManager: "Start_Menu", "Start_Button", "Buy_Button", "Delete_Save_Button"
// - BuyMenuManager: "Buy_Menu"（"Gold_Display"と"Back_Button"を探索）
// - GameOverManager: "Game_Over", "GameOver_Menu_Button"
// - HUDVisibilityManager: Singleton（DontDestroyOnLoad）
//
// =============================================
// デバッグ出力（Debug.Log）
// =============================================
// Global.cs
//   [Global] LoadProgress complete: gold = X, purchasedPartIds.Count = Y, purchasedPowerUpItemIds.Count = Z
//   [Global] SaveProgress: Saving gold = X, parts = "...", powerup_items = "..."
//   [Global] DeleteSave called - Deleting all save data
//
// StartMenuManager.cs
//   [StartMenuManager] OnBuyClicked called - Global.gold = X
//   [StartMenuManager] OnDeleteSaveClickedInternal - Deleting save and resetting game state
//
// BuyMenuManager.cs
//   [BuyMenuManager] ShowBuyMenu called - Global.gold = X
//   [BuyMenuManager] RebuildBuyUI called - Global.gold = X
//   [BuyMenuManager] Updated goldText with Global.gold = X
//   [BuyMenuManager] Purchase successful: partId = X, new gold = Y
//   [BuyMenuManager] Cannot afford part: required = X, current gold = Y
//
// PowerUpMenuManager.cs
//   [PowerUpMenuManager] ShowPowerUpMenu called - ScoreManager.Instance.GetScore() = X
//   [PowerUpMenuManager] RebuildPowerUpUI called - Current Score = X
//   [PowerUpMenuManager] Updated scoreText with current score = X
//   [PowerUpMenuManager] Updated ownedItemsText with X items
//   [PowerUpMenuManager] Updated availableItemsText
//   [PowerUpMenuManager] Purchase complete: AtkUp1
//
// HUDVisibilityManager.cs
//   [HUDVisibilityManager] ShowGameplay()
//   [HUDVisibilityManager] ShowStartMenu()
//   [HUDVisibilityManager] ShowBuyMenu()
//   [HUDVisibilityManager] ShowPauseMenu()
//   [HUDVisibilityManager] ShowGameOver()
//   [HUDVisibilityManager] ShowPowerUpOffer()
//
// Player.cs
//   [Player] Applied PowerUp bonus: ATK+X, Global.bullet_atk = Y
//
// =============================================


