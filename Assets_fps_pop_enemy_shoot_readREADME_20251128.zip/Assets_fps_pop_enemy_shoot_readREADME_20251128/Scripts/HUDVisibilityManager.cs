using UnityEngine;
using UnityEngine.InputSystem; // 新Input System利用（旧式のみなら削除可）
using UnityEngine.UI; // UIボタン取得用

// HUDの表示切替と簡易入力（Start/Resume）を司るマネージャ
public class HUDVisibilityManager : MonoBehaviour
{
    public static HUDVisibilityManager Instance { get; private set; }

    [Header("GameOver Conditions")]
    [SerializeField, Tooltip("この値以下になったらHPでゲームオーバー")] private float hpThreshold = 0f;
    [SerializeField, Tooltip("この秒数以上になったらプレイタイムでゲームオーバー")] private int playTimeLimitSeconds = 10;
    [SerializeField, Tooltip("PlayTimeManager参照 (未設定なら自動探索)")] private PlayTimeManager playTimeManager;
    private bool gameOverShown = false;

    private enum HudState { None, StartMenu, BuyMenu, Gameplay, Pause, GameOver, PowerUp }

    [Header("Panels")]
    [SerializeField] private GameObject startMenuPanel; // Start_Menu
    [SerializeField] private GameObject buyMenuPanel;   // Buy_Menu
    [SerializeField] private GameObject pauseMenuPanel; // Game_Menu
    [SerializeField] private GameObject gameOverPanel;  // Game_Over
    [SerializeField] private GameObject powerUpPanel;   // Power_Up

    [Header("HUD Texts (任意)")]
    [SerializeField] private GameObject scoreText;      // Score
    [SerializeField] private GameObject playerHpText;   // Player_Hp
    [SerializeField] private GameObject streakText;     // Streak
    [SerializeField] private GameObject playTimeText;   // PlayTime

    [Header("Buttons (任意)")]
    [SerializeField] private Button resumeButton;       // Resume_Button (Game_Menu)
    [SerializeField] private Button startButton;        // Start_Button (Start_Menu)
    [SerializeField] private Button buyButton;          // Buy_Button (Start_Menu)
    [SerializeField] private Button deleteSaveButton;   // Delete_Save_Button (Start_Menu)
    [SerializeField] private Button backButton;         // Back_Button (Buy_Menu)

    [Header("Options")]
    [SerializeField] private bool autoDiscoverOnAwake = true;
    [SerializeField] private bool enableEnterStart = true;
    [SerializeField] private bool pauseTimeInMenus = true;
    [SerializeField] private bool lockCursorInGameplay = true;

    private HudState current = HudState.None;
    private bool startedGameplay;

        // Public APIs
    public static void ShowStartMenu() { Ensure().SetState(HudState.StartMenu); }
    public static void ShowBuyMenu() { Ensure().SetState(HudState.BuyMenu); }
    public static void ShowGameplay() { Ensure().SetState(HudState.Gameplay); }
    public static void ShowPauseMenu() { Ensure().SetState(HudState.Pause); }
    public static void ShowGameOver() { Ensure().SetState(HudState.GameOver); }
    public static void ShowPowerUpOffer() { Ensure().SetState(HudState.PowerUp); }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        if (transform.parent != null) transform.SetParent(null);
        DontDestroyOnLoad(gameObject);
        if (autoDiscoverOnAwake) DiscoverAll();
        
        // StartMenuManagerが見つからない場合は自動生成
        var smm = FindFirstObjectByType<StartMenuManager>();
        if (smm == null)
        {
            Debug.Log("[HUDVisibilityManager] StartMenuManager not found, creating automatically...");
            var startMenuGO = new GameObject("StartMenuManager");
            smm = startMenuGO.AddComponent<StartMenuManager>();
            Debug.Log("[HUDVisibilityManager] StartMenuManager created successfully");
        }
    }

    private void Start()
    {
        ShowStartMenu();
    }

    private void OnDestroy()
    {
        UnhookResume();
        UnhookStartMenuButtons();
    }

    private void Update()
    {
//scoreが2になったときにPower_Upパネルを表示する処理
        if (ScoreManager.Instance != null && ScoreManager.Instance.GetScore() == 2)
        {
            ShowPowerUpOffer();
        }

        var keyboard = Keyboard.current;
        if (enableEnterStart && current == HudState.StartMenu && !startedGameplay)
        {
            bool startEnter = keyboard != null && ((keyboard.enterKey != null && keyboard.enterKey.wasPressedThisFrame) || (keyboard.numpadEnterKey != null && keyboard.numpadEnterKey.wasPressedThisFrame));
            bool startLegacy = Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            if (startEnter || startLegacy) ShowGameplay();
        }
        else if (current == HudState.Gameplay)
        {
            bool esc = (keyboard != null && keyboard.escapeKey != null && keyboard.escapeKey.wasPressedThisFrame) || Input.GetKeyDown(KeyCode.Escape);
            if (esc) ShowPauseMenu();

            // ゲームオーバー判定
            CheckGameOver();
        }
        else if (current == HudState.Pause)
        {
            bool resumeEnter = keyboard != null && ((keyboard.enterKey != null && keyboard.enterKey.wasPressedThisFrame) || (keyboard.numpadEnterKey != null && keyboard.numpadEnterKey.wasPressedThisFrame));
            bool resumeLegacyEnter = Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            bool resumeEsc = (keyboard != null && keyboard.escapeKey != null && keyboard.escapeKey.wasPressedThisFrame) || Input.GetKeyDown(KeyCode.Escape);
            if (resumeEnter || resumeLegacyEnter || resumeEsc) ShowGameplay();
        }
        else if (current == HudState.BuyMenu)
        {
            bool backEsc = (keyboard != null && keyboard.escapeKey != null && keyboard.escapeKey.wasPressedThisFrame) || Input.GetKeyDown(KeyCode.Escape);
            if (backEsc) ShowStartMenu();
        }
        else if (current == HudState.GameOver)
        {
            bool enterPressed = keyboard != null && ((keyboard.enterKey != null && keyboard.enterKey.wasPressedThisFrame) || (keyboard.numpadEnterKey != null && keyboard.numpadEnterKey.wasPressedThisFrame));
            bool escPressed = (keyboard != null && keyboard.escapeKey != null && keyboard.escapeKey.wasPressedThisFrame) || Input.GetKeyDown(KeyCode.Escape);
            bool legacyEnter = Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            if (enterPressed || escPressed || legacyEnter)
            {
                // リセット処理を実行
                Reset.ExecuteGameOverReset();
                gameOverShown = false;
                ShowStartMenu();
            }
        }
    }



    private void SetState(HudState s)
    {
        if (current == s && s != HudState.StartMenu) return;
        current = s;
        ApplyState();
    }

    private void ApplyState()
    {
        if (autoDiscoverOnAwake) DiscoverAll();
        // hide all
        SetActive(startMenuPanel, false);
        SetActive(buyMenuPanel, false);
        SetActive(pauseMenuPanel, false);
        SetActive(gameOverPanel, false);
        SetActive(powerUpPanel, false);
        SetActive(scoreText, false);
        SetActive(playerHpText, false);
        SetActive(streakText, false);
        SetActive(playTimeText, false);

        bool menuState = current == HudState.StartMenu || current == HudState.BuyMenu || current == HudState.Pause || current == HudState.GameOver || current == HudState.PowerUp;
        if (pauseTimeInMenus) Time.timeScale = menuState ? 0f : 1f;

        switch (current)
        {
            case HudState.StartMenu:
                startedGameplay = false;
                SetActive(startMenuPanel, true);
                HookStartMenuButtons();
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                break;
            case HudState.BuyMenu:
                SetActive(buyMenuPanel, true);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                HookBackButton();
                break;
            case HudState.Pause:
                ShowGameplayElements();
                SetActive(pauseMenuPanel, true);
                HookResume();
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                break;
            case HudState.GameOver:
                SetActive(gameOverPanel, true);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                break;
            case HudState.PowerUp:
                SetActive(powerUpPanel, true);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                // PowerUpMenuManager があればShowPowerUpMenu()を呼ぶ
                if (powerUpPanel != null)
                {
                    var powerUpMgr = powerUpPanel.GetComponent<PowerUpMenuManager>();
                    if (powerUpMgr != null)
                    {
                        powerUpMgr.ShowPowerUpMenu();
                    }
                    else
                    {
                        // 自動生成を試みる
                        powerUpMgr = powerUpPanel.AddComponent<PowerUpMenuManager>();
                        powerUpMgr.ShowPowerUpMenu();
                    }
                }
                break;
            case HudState.Gameplay:
                startedGameplay = true;
                ShowGameplayElements();
                UnhookStartMenuButtons();
                if (lockCursorInGameplay) { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
                break;
        }
    }

    private void ShowGameplayElements()
    {
        SetActive(scoreText, true);
        SetActive(playerHpText, true);
        SetActive(streakText, true);
        SetActive(playTimeText, true);
    }

    private void DiscoverAll()
    {
        var all = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (var go in all)
        {
            if (go == null) continue;
            if (!go.scene.IsValid()) continue;
            if (go.hideFlags != HideFlags.None) continue;
            switch (go.name)
            {
                case "Start_Menu": if (!startMenuPanel) startMenuPanel = go; break;
                case "Buy_Menu": if (!buyMenuPanel) buyMenuPanel = go; break;
                case "Game_Menu": if (!pauseMenuPanel) pauseMenuPanel = go; break;
                case "Game_Over": if (!gameOverPanel) gameOverPanel = go; break;
                case "Power_Up": if (!powerUpPanel) powerUpPanel = go; break;
                case "Score": if (!scoreText) scoreText = go; break;
                case "Player_Hp": if (!playerHpText) playerHpText = go; break;
                case "Streak": if (!streakText) streakText = go; break;
                case "PlayTime": if (!playTimeText) playTimeText = go; break;
            }
            if (!startButton && go.name == "Start_Button") { var b = go.GetComponent<Button>(); if (b) startButton = b; }
            else if (!buyButton && go.name == "Buy_Button") { var b = go.GetComponent<Button>(); if (b) buyButton = b; }
            else if (!deleteSaveButton && go.name == "Delete_Save_Button") { var b = go.GetComponent<Button>(); if (b) deleteSaveButton = b; }
            else if (!resumeButton && go.name == "Resume_Button") { var b = go.GetComponent<Button>(); if (b) resumeButton = b; }
            else if (!backButton && go.name == "Back_Button") { var b = go.GetComponent<Button>(); if (b) backButton = b; }
        }
    }

    private void HookStartMenuButtons()
    {
        var smm = FindFirstObjectByType<StartMenuManager>();
        if (smm != null) return; // 既存マネージャに委譲
        if (!startButton || !buyButton || !deleteSaveButton) DiscoverAll();
        if (startButton) { startButton.onClick.RemoveListener(OnStartClickedInternal); startButton.onClick.AddListener(OnStartClickedInternal); }
        if (buyButton) { buyButton.onClick.RemoveListener(OnBuyClickedInternal); buyButton.onClick.AddListener(OnBuyClickedInternal); }
        if (deleteSaveButton) { deleteSaveButton.onClick.RemoveListener(OnDeleteSaveClickedInternal); deleteSaveButton.onClick.AddListener(OnDeleteSaveClickedInternal); }
    }

    private void UnhookStartMenuButtons()
    {
        if (startButton) startButton.onClick.RemoveListener(OnStartClickedInternal);
        if (buyButton) buyButton.onClick.RemoveListener(OnBuyClickedInternal);
        if (deleteSaveButton) deleteSaveButton.onClick.RemoveListener(OnDeleteSaveClickedInternal);
    }

    private void OnStartClickedInternal() { ShowGameplay(); }
    private void OnBuyClickedInternal() { ShowBuyMenu(); }
    private void OnDeleteSaveClickedInternal()
    {
        Debug.Log("[HUDVisibilityManager] OnDeleteSaveClickedInternal - Deleting save and resetting game state");
        Global.DeleteSave();
        
        // ゲーム状態をリセット
        Global.gold = Global.INIT_GOLD;  // 金を初期値にリセット（INIT_GOLD定数を使用）
        Global.purchasedPartIds.Clear();  // 購入済みパーツをクリア
        Global.purchasedPowerUpItemIds.Clear();  // 購入済みパワーアップアイテムをクリア
        
        Debug.Log($"[HUDVisibilityManager] After DeleteSave: gold = {Global.gold}, purchasedPartIds.Count = {Global.purchasedPartIds.Count}, purchasedPowerUpItemIds.Count = {Global.purchasedPowerUpItemIds.Count}");
        
        // リセット状態を保存
        Global.SaveProgress();
        Debug.Log("[HUDVisibilityManager] OnDeleteSaveClickedInternal completed - State saved");
    }

    private void HookResume()
    {
        if (!resumeButton) DiscoverAll();
        if (resumeButton)
        {
            resumeButton.onClick.RemoveListener(OnResumeClicked);
            resumeButton.onClick.AddListener(OnResumeClicked);
        }
    }

    private void UnhookResume()
    {
        if (resumeButton) resumeButton.onClick.RemoveListener(OnResumeClicked);
    }

    private void OnResumeClicked() { ShowGameplay(); }

    private void SetActive(GameObject go, bool active)
    {
        if (!go) return;
        if (go.activeSelf != active) go.SetActive(active);
    }

    private void HookBackButton()
    {
        if (!backButton) DiscoverAll();
        if (backButton)
        {
            backButton.onClick.RemoveListener(OnBackClicked);
            backButton.onClick.AddListener(OnBackClicked);
        }
    }

    private void UnhookBackButton()
    {
        if (backButton) backButton.onClick.RemoveListener(OnBackClicked);
    }

    private void OnBackClicked()
    {
        ShowStartMenu();
    }


    private static HUDVisibilityManager Ensure()
    {
        if (Instance == null)
        {
            var autoGO = new GameObject("HUDVisibilityManager");
            Instance = autoGO.AddComponent<HUDVisibilityManager>();
        }
        return Instance;
    }

    /// <summary>
    /// HPまたはプレイタイムのしきい値でゲームオーバー判定し、発動時はGameOverパネルを表示・停止する
    /// </summary>
    private void CheckGameOver()
    {
        if (gameOverShown) return;
        if (playTimeManager == null) playTimeManager = FindFirstObjectByType<PlayTimeManager>() ?? FindAnyObjectByType<PlayTimeManager>();
        bool hpDead = Global.player_hp <= hpThreshold;
        bool timeUp = (playTimeManager != null) && (playTimeManager.ElapsedSeconds >= playTimeLimitSeconds);
        if (hpDead || timeUp)
        {
            ShowGameOver();
            gameOverShown = true;
            Time.timeScale = 0f;
        }
    }
}

