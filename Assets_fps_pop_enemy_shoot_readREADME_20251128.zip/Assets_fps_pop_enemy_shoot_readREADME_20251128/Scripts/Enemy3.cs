using UnityEngine;

// Enemy3: 一定時間後に自動消滅し、プレイヤーが近づくと逃げるだけの敵。
// ・攻撃/射撃手段なし
// ・スポーン時に寿命を [minLifetime, maxLifetime] の範囲でランダム決定
// ・プレイヤーが fleeTriggerDistance 以内に入ると、プレイヤーから離れる方向へ moveSpeed で移動
// ・プレイヤーがいない/遠い場合はその場に留まる（必要なら後で徘徊を追加可能）
public partial class Enemy3 : MonoBehaviour
{
    [Header("Lifetime")]
    [SerializeField, Tooltip("最短寿命(秒)")] private float minLifetime = 5f;
    [SerializeField, Tooltip("最長寿命(秒)")] private float maxLifetime = 12f;

    [Header("Flee Settings")]
    [SerializeField, Tooltip("プレイヤーがこの距離内に入ると逃走を開始(平面距離)")] private float fleeTriggerDistance = 8f;
    [SerializeField, Tooltip("逃走時の移動速度 (m/s)")] private float moveSpeed = 3f;
    [SerializeField, Tooltip("逃走方向回頭の補間速度")] private float turnSpeed = 6f;

    [Header("Optional Scoring (未使用なら0)")] 
    [SerializeField, Tooltip("消滅時に付与するスコア。0なら加算なし")] private int scoreValueOnExpire = 0;

    [Header("Debug")] 
    [SerializeField, Tooltip("Gizmosでトリガー距離を表示")] private bool drawGizmos = true;

    private float chosenLifetime;
    private float spawnTime;
    private Transform player;
    private bool expired;

    [Header("Coin Drop")] 
    [SerializeField, Tooltip("自然消滅(または撃破)時に落とすコイン数")] private int coinDropCount = 1;
    [SerializeField, Tooltip("ドロップするCoinプレハブ")] private GameObject coinPrefab;
    [SerializeField, Tooltip("コイン寿命(秒)")] private float coinLifeSeconds = 5f;
    [SerializeField, Tooltip("1コインのゴールド価値")] private int coinGoldValue = 1;

    private void Awake()
    {
        // プレイヤー取得
        var pObj = GameObject.FindWithTag("Player");
        if (pObj != null) player = pObj.transform;

        // 寿命決定
        float minL = Mathf.Max(0.1f, Mathf.Min(minLifetime, maxLifetime));
        float maxL = Mathf.Max(minL, Mathf.Max(minLifetime, maxLifetime));
        chosenLifetime = Random.Range(minL, maxL);
        spawnTime = Time.time;
        // Removed verbose Enemy3 spawn log
    }

    private void Update()
    {
        if (expired) return;

        // プレイヤー再取得（シーンリロード対策）
        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null) player = pObj.transform;
        }

        // 寿命判定
        float age = Time.time - spawnTime;
        if (age >= chosenLifetime)
        {
            Expire();
            return;
        }

        // 逃走処理
        HandleFlee();
    }

    private void HandleFlee()
    {
        if (player == null) return;
        Vector3 selfPos = transform.position;
        Vector3 playerPos = player.position;
        Vector3 diff = selfPos - playerPos; // プレイヤーから離れる方向
        diff.y = 0f;
        float sqrDist = diff.sqrMagnitude;
        float triggerSqr = fleeTriggerDistance * fleeTriggerDistance;
        if (sqrDist <= triggerSqr && sqrDist > 0.0001f)
        {
            Vector3 dir = diff.normalized;
            transform.position += dir * moveSpeed * Time.deltaTime;
            // 回頭
            Quaternion targetRot = Quaternion.LookRotation(dir, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Time.deltaTime * turnSpeed);
        }
    }

    private void Expire()
    {
        expired = true;
        // Removed verbose Enemy3 expired log
        if (scoreValueOnExpire > 0 && ScoreManager.Instance != null)
        {
            // キルストリーク対象外（自然消滅のため）
            ScoreManager.Instance.AddScore(scoreValueOnExpire);
        }
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawGizmos) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, fleeTriggerDistance);
    }
}

// 追加: 共通ドロップ呼び出し
public partial class Enemy3
{
    private void OnTriggerEnter(Collider other)
    {
        if (expired) return;
        if (other != null && other.CompareTag("bullet"))
        {
            KillByPlayer();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (expired) return;
        var other = collision.gameObject;
        if (other != null && other.CompareTag("bullet"))
        {
            KillByPlayer();
        }
    }

    private void KillByPlayer()
    {
        if (expired) return;
        expired = true;
        DropCoins();
        Destroy(gameObject);
    }

    private void DropCoins()
    {
        if (coinPrefab == null || coinDropCount <= 0) return;
        Coin.SpawnBurst(coinPrefab, transform.position, coinDropCount, coinLifeSeconds, coinGoldValue);
    }
}
