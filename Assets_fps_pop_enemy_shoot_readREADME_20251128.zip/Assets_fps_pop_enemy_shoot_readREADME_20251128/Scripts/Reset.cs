using UnityEngine;

/// <summary>
/// ゲームオーバー時のリセット処理をまとめるクラス
/// </summary>
public static class Reset
{
    /// <summary>
    /// ゲームオーバーからスタートメニューへの切り替え時に実行するリセット処理
    /// </summary>
    public static void ExecuteGameOverReset()
    {
        // Player HPの初期化
        ResetPlayerHP();
        
        // Playerのスポーン位置への移動
        MovePlayerToSpawn();
        
        // Scoreの初期化
        ResetScore();
        
        // 出現中の全Enemyの削除
        DestroyAllEnemies();
        
        // スポーナーの初期化
        ResetSpawners();
    }

    /// <summary>
    /// Player HPを初期値にリセット
    /// </summary>
    private static void ResetPlayerHP()
    {
        Global.player_hp = 10f; // 初期HP値
    }

    /// <summary>
    /// Playerをスポーン位置に移動
    /// </summary>
    private static void MovePlayerToSpawn()
    {
        var player = Object.FindFirstObjectByType<Player>();
        if (player != null)
        {
            // Playerの初期位置に戻す（Player.csのRespawn()を利用）
            var playerComponent = player.GetComponent<Player>();
            if (playerComponent != null)
            {
                // ResetForNewGame()があればそれを使用、なければ削除して再生成
                playerComponent.ResetForNewGame();
            }
        }
        else
        {
            // Playerが存在しない場合は新規生成を他のマネージャーに委譲
            Debug.Log("Player not found for reset. Will be spawned by StartBuyMenuManager.");
        }
    }

    /// <summary>
    /// スコアを初期化
    /// </summary>
    private static void ResetScore()
    {
        var scoreManager = ScoreManager.Instance ?? Object.FindFirstObjectByType<ScoreManager>();
        if (scoreManager != null)
        {
            scoreManager.ResetGameState();
        }
        
        // スコア購入したパワーアップアイテムをリセット
        Global.purchasedPowerUpItemIds.Clear();
        Debug.Log("Reset: Cleared purchased power-up items");
        
        // プレイタイマーもリセット
        var playTimeManager = Object.FindFirstObjectByType<PlayTimeManager>(FindObjectsInactive.Include);
        if (playTimeManager == null)
        {
            // HUD/PlayTime から直接検索
            var hudGO = GameObject.Find("HUD");
            if (hudGO != null)
            {
                var playTimeGO = hudGO.transform.Find("PlayTime");
                if (playTimeGO != null)
                {
                    playTimeManager = playTimeGO.GetComponent<PlayTimeManager>();
                }
            }
        }
        
        if (playTimeManager != null)
        {
            Debug.Log("Reset: Calling PlayTimeManager.ResetTimer()");
            playTimeManager.ResetTimer();
        }
        else
        {
            Debug.LogWarning("Reset: PlayTimeManager not found in HUD/PlayTime!");
        }
        
        // ストリークもリセット
        var streak = Streak.Instance ?? Object.FindFirstObjectByType<Streak>();
        if (streak != null)
        {
            streak.ResetStreak();
        }
    }

    /// <summary>
    /// 出現中の全敵を削除
    /// </summary>
    private static void DestroyAllEnemies()
    {
        // 各種敵タイプを削除
        DestroyAllOfType<Enemy>();
        DestroyAllOfType<Enemy2>();
        DestroyAllOfType<Enemy3>();
        DestroyAllOfType<Boss>();
        
        // 弾とコインも削除
        DestroyAllOfType<Bullet>();
        DestroyAllOfType<Bullet2>();
        DestroyAllOfType<Bullet3>();
        DestroyAllOfType<Enemy2Bullet>();
        DestroyAllOfType<Coin>();
    }

    /// <summary>
    /// スポーナーを初期化
    /// </summary>
    private static void ResetSpawners()
    {
        // 敵スポーナーのリセット
        var enemySpawners = Object.FindObjectsByType<EnemySpawner>(FindObjectsSortMode.None);
        foreach (var spawner in enemySpawners)
        {
            if (spawner != null)
            {
                spawner.ResetSpawner();
            }
        }
        
        // ボススポーナーのリセット
        var bossSpawners = Object.FindObjectsByType<BossSpawner>(FindObjectsSortMode.None);
        foreach (var spawner in bossSpawners)
        {
            if (spawner != null)
            {
                spawner.ResetSpawner();
            }
        }
    }

    /// <summary>
    /// 指定タイプのコンポーネントを持つ全GameObjectを削除
    /// </summary>
    private static void DestroyAllOfType<T>() where T : Component
    {
        var objects = Object.FindObjectsByType<T>(FindObjectsSortMode.None);
        foreach (var obj in objects)
        {
            if (obj != null)
            {
                Object.Destroy(obj.gameObject);
            }
        }
    }
}