using UnityEngine;

// Bullet3: 放物線軌道で飛び、着弾後にサイズを拡大して一定時間滞在する榴弾型。
// Player からは Bullet/Bullet2 と同様に Init(direction, speed, lifetime) を呼び出す想定。
public class Bullet3 : MonoBehaviour
{
    [SerializeField, Tooltip("初期水平速度 (Initで上書き)")] private float baseSpeed = 20f;
    [SerializeField, Tooltip("初期上向き速度 (m/s)")] private float verticalSpeed = 10f;
    [SerializeField, Tooltip("飛翔時の重力加速度 (m/s^2)")] private float gravity = 9.81f;
    [SerializeField, Tooltip("飛翔の最大寿命 (秒) 着弾前に経過すると消滅")] private float defaultLifetime = 3.5f;
    [SerializeField, Tooltip("連射レート(発/秒) : Player側参照用")] private float fireRate = 1.5f;
    [SerializeField, Tooltip("パワーアップメニューでの価格（スコア）")] private int price = 7;
    [SerializeField, Tooltip("着弾後の滞在時間 (秒)")] private float lingerDuration = 2.5f;
    [SerializeField, Tooltip("着弾後にスケールを拡大する値")] private Vector3 impactedScale = new Vector3(2f, 2f, 2f);
    [SerializeField, Tooltip("拡大演出の補間速度") ] private float scaleLerpSpeed = 10f;
    [SerializeField, Tooltip("地面や任意オブジェクトとの衝突で着弾とみなすレイヤー") ] private LayerMask impactMask = ~0;

    private Vector3 velocity;
    private float spawnTime;
    private float flightLife; // Init でセットされる寿命
    private bool impacted;
    private float impactTime;
    private Vector3 originalScale;
    private bool scaleApplied;

    public float BaseSpeed => baseSpeed;
    public float DefaultLifetime => defaultLifetime;
    public float FireRate => fireRate;
    public int Price => price;

    // Player から生成時に設定される想定
    public void Init(Vector3 forwardDir, float speed, float lifeTime)
    {
        forwardDir.y = 0f;
        forwardDir.Normalize();
        baseSpeed = speed;
        flightLife = Mathf.Max(0.01f, lifeTime);
        spawnTime = Time.time;
        originalScale = transform.localScale;
        velocity = forwardDir * baseSpeed + Vector3.up * verticalSpeed;
    }

    private void Awake()
    {
        if (originalScale == Vector3.zero) originalScale = transform.localScale;
    }

    private void Update()
    {
        if (!impacted)
        {
            // 飛翔中
            velocity.y -= gravity * Time.deltaTime;
            transform.position += velocity * Time.deltaTime;

            if (Time.time - spawnTime >= flightLife)
            {
                // 寿命で未着弾なら消滅
                Destroy(gameObject);
                return;
            }
        }
        else
        {
            // 滞在中スケール補間
            if (!scaleApplied)
            {
                transform.localScale = Vector3.Lerp(transform.localScale, impactedScale, Time.deltaTime * scaleLerpSpeed);
                if ((transform.localScale - impactedScale).sqrMagnitude < 0.0001f)
                {
                    transform.localScale = impactedScale;
                    scaleApplied = true;
                }
            }
            if (Time.time - impactTime >= lingerDuration)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (impacted) return;
        if (((1 << collision.gameObject.layer) & impactMask) != 0)
        {
            Impact(collision.contacts.Length > 0 ? collision.contacts[0].point : transform.position);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (impacted) return;
        if (((1 << other.gameObject.layer) & impactMask) != 0)
        {
            Impact(transform.position);
        }
    }

    private void Impact(Vector3 point)
    {
        impacted = true;
        impactTime = Time.time;
        // 位置を着弾地点の高さに固定（やや上に浮かせる）
        transform.position = new Vector3(point.x, point.y + 0.1f, point.z);
        velocity = Vector3.zero;
        // Removed verbose Bullet3 impact log
    }
}
