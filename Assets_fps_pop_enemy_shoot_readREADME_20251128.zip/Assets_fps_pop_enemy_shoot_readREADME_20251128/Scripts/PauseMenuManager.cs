using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.InputSystem; // New Input System

public class PauseMenuManager : MonoBehaviour
{
    [Header("References")]
    [SerializeField, Tooltip("HUD直下のMenuのGameObject (TextMeshProを含むオブジェクト)")] 
    private GameObject menuPanel;
    
    [SerializeField, Tooltip("Resume ボタン")] 
    private Button resumeButton;
    
    [SerializeField, Tooltip("PlayTimeManager参照 (未設定なら自動検索)")] 
    private PlayTimeManager playTimeManager;

    private bool isPaused = false;

    private void Awake()
    {
        // PlayTimeManagerの自動検索
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null)
            {
                playTimeManager = FindAnyObjectByType<PlayTimeManager>();
            }
        }

        // Menuパネルの自動検索（未設定の場合）
        if (menuPanel == null)
        {
            var allTexts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in allTexts)
            {
                if (t != null && t.name == "Menu")
                {
                    menuPanel = t.gameObject;
                    break;
                }
            }
        }

        // Resumeボタンのイベント設定
        if (resumeButton != null)
        {
            resumeButton.onClick.AddListener(ResumeGame);
        }

        // 初期状態：メニューを非表示
        if (menuPanel != null)
        {
            menuPanel.SetActive(false);
        }
    }

    private void Update()
    {
        // 新Input Systemでの ESC 検出
        var keyboard = Keyboard.current;
        if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame)
        {
            if (isPaused) ResumeGame(); else PauseGame();
        }
    }

    private void PauseGame()
    {
        isPaused = true;
        // HUD統合表示（ポーズメニュー）
        HUDVisibilityManager.ShowPauseMenu();
        // ゲームを一時停止
        Time.timeScale = 0f;
        
        // PlayTimeを一時停止
        if (playTimeManager != null)
        {
            playTimeManager.PauseTimer();
        }
        
        // カーソルを表示
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        
        // Removed verbose log (was: Game Paused)
    }

    public void ResumeGame()
    {
        isPaused = false;
        // HUD統合表示（プレイ状態）
        HUDVisibilityManager.ShowGameplay();
        // ゲームを再開
        Time.timeScale = 1f;
        
        // PlayTimeを再開
        if (playTimeManager != null)
        {
            playTimeManager.ResumeTimer();
        }
        
        // カーソルをロック
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        
        // Removed verbose log (was: Game Resumed)
    }

    private void OnDestroy()
    {
        // ボタンイベントのクリーンアップ
        if (resumeButton != null)
        {
            resumeButton.onClick.RemoveListener(ResumeGame);
        }
    }
}
