using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;

public class StartMenuManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("HUD直下の Start_Menu パネル(GameObject)")] private GameObject startMenuPanel;
    [SerializeField, Tooltip("Startボタン")] private Button startButton;
    [SerializeField, Tooltip("Buyボタン")] private Button buyButton;
    [SerializeField, Tooltip("セーブ削除ボタン (Start_Menu用)")] private Button deleteSaveButton;
    [SerializeField, Tooltip("PlayTimeManager (未設定なら自動検出)")] private PlayTimeManager playTimeManager;
    [SerializeField, Tooltip("Playerプレハブ (再スタート時に生成)")] private GameObject playerPrefab;
    [SerializeField, Tooltip("Playerスポーン位置 (未設定なら Start_Menu の位置 or このオブジェクト位置)")] private Transform playerSpawnPoint;

    private BuyMenuManager buyMenuManager;
    private PauseMenuManager pauseMenuManager;
    private InputAction startAction; // Start(Enter等)を拾う専用アクション
    private bool startRequested;
    private System.Action<InputAction.CallbackContext> onStartPerformed;

    private void Awake()
    {
        // 自動参照
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null) playTimeManager = FindAnyObjectByType<PlayTimeManager>();
        }
        if (startMenuPanel == null)
        {
            startMenuPanel = FindInAll("Start_Menu");
        }
        // ボタンは手動アサイン推奨。未設定時は名前で探すフォールバック
        if (startButton == null)
        {
            var btnGo = FindInAll("Start_Button");
            if (btnGo != null) startButton = btnGo.GetComponent<Button>();
        }
        if (buyButton == null)
        {
            var btnGo = FindInAll("Buy_Button");
            if (btnGo != null) buyButton = btnGo.GetComponent<Button>();
        }
        if (deleteSaveButton == null)
        {
            var btnGo = FindInAll("Delete_Save_Button");
            if (btnGo != null) deleteSaveButton = btnGo.GetComponent<Button>();
        }

        if (startButton != null) {
            startButton.onClick.AddListener(OnStartClicked);
            Debug.Log("[StartMenuManager] Start button listener added");
        } else {
            Debug.LogWarning("[StartMenuManager] Start button not found!");
        }
        
        if (buyButton != null) {
            buyButton.onClick.AddListener(OnBuyClicked);
            Debug.Log("[StartMenuManager] Buy button listener added");
        } else {
            Debug.LogWarning("[StartMenuManager] Buy button not found!");
        }
        
        if (deleteSaveButton != null) {
            deleteSaveButton.onClick.AddListener(OnDeleteSaveClicked);
            Debug.Log("[StartMenuManager] Delete save button listener added");
        }

        pauseMenuManager = FindFirstObjectByType<PauseMenuManager>();
        if (pauseMenuManager == null) pauseMenuManager = FindAnyObjectByType<PauseMenuManager>();

        // buyMenuManagerはStart()で遅延検索（Awakeの実行順序による問題を回避）
        
        Debug.Log($"[StartMenuManager] Awake: buyMenuManager will be found in Start()");

        // Enter/テンキーEnter/ゲームパッドStart/決定ボタンを拾うアクション
        startAction = new InputAction(type: InputActionType.Button);
        startAction.AddBinding("<Keyboard>/enter");
        startAction.AddBinding("<Keyboard>/numpadEnter");
        startAction.AddBinding("<Gamepad>/start");
        startAction.AddBinding("<Gamepad>/buttonSouth");
        onStartPerformed = ctx =>
        {
            // 参照が切れていたら再探索（Start_Menuが非アクティブでも見つける）
            if (startMenuPanel == null)
            {
                startMenuPanel = FindInAll("Start_Menu");
            }
            if (startMenuPanel != null && startMenuPanel.activeInHierarchy)
            {
                OnStartClicked();
            }
        };
        startAction.performed += onStartPerformed;

        // セーブ読み込み
        Global.LoadProgress();
        
        Debug.Log("[StartMenuManager] Awake complete");
        Debug.Log($"[StartMenuManager] startMenuPanel: {(startMenuPanel != null ? startMenuPanel.name : "NULL")}");
        Debug.Log($"[StartMenuManager] playTimeManager: {(playTimeManager != null ? playTimeManager.name : "NULL")}");
        Debug.Log($"[StartMenuManager] buyMenuManager: {(buyMenuManager != null ? buyMenuManager.name : "NULL")}");
        Debug.Log($"[StartMenuManager] pauseMenuManager: {(pauseMenuManager != null ? pauseMenuManager.name : "NULL")}");
        
        // 初期状態：スタートメニューを表示、ゲーム停止（表示時に自動セーブ）
        ShowStartMenu();
    }

    private void OnDestroy()
    {
        if (startButton != null) startButton.onClick.RemoveListener(OnStartClicked);
        if (buyButton != null) buyButton.onClick.RemoveListener(OnBuyClicked);
        if (deleteSaveButton != null) deleteSaveButton.onClick.RemoveListener(OnDeleteSaveClicked);
        if (startAction != null)
        {
            if (onStartPerformed != null) startAction.performed -= onStartPerformed;
            startAction.Dispose();
            startAction = null;
            onStartPerformed = null;
        }
    }

    private void Start()
    {
        // buyMenuManagerの遅延検索（Awakeの実行順序の問題を回避）
        if (buyMenuManager == null)
        {
            buyMenuManager = FindFirstObjectByType<BuyMenuManager>();
            if (buyMenuManager == null) buyMenuManager = FindAnyObjectByType<BuyMenuManager>();
        }
        
        Debug.Log($"[StartMenuManager] Start(): buyMenuManager reference set: {(buyMenuManager != null ? "FOUND" : "NULL")}");
        if (buyMenuManager != null)
        {
            Debug.Log($"[StartMenuManager] BuyMenuManager found: {buyMenuManager.name}");
        }
        else
        {
            Debug.LogWarning("[StartMenuManager] BuyMenuManager not found, attempting to create it on Buy_Menu panel...");
            
            // Buy_Menu パネルを探す
            var buyMenuPanel = FindInAll("Buy_Menu");
            if (buyMenuPanel != null)
            {
                Debug.Log("[StartMenuManager] Buy_Menu panel found, attaching BuyMenuManager component");
                buyMenuManager = buyMenuPanel.AddComponent<BuyMenuManager>();
                Debug.Log("[StartMenuManager] BuyMenuManager component added to Buy_Menu panel");
            }
            else
            {
                Debug.LogError("[StartMenuManager] Buy_Menu panel not found! Cannot create BuyMenuManager.");
            }
        }
    }

    private void Update()
    {
        var keyboard = Keyboard.current;
        if (keyboard == null) return;

        // Start_Menu 表示中は Enter で開始
        // 参照が無ければフォールバック再探索
        if (startMenuPanel == null)
        {
            startMenuPanel = FindInAll("Start_Menu");
        }
        if (startMenuPanel != null && startMenuPanel.activeInHierarchy)
        {
            bool newInputEnter = (keyboard.enterKey != null && keyboard.enterKey.wasPressedThisFrame) ||
                                 (keyboard.numpadEnterKey != null && keyboard.numpadEnterKey.wasPressedThisFrame);
            bool legacyEnter = Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            if (newInputEnter || legacyEnter)
            {
                OnStartClicked();
            }
        }
    }

    // 非アクティブ含めシーン上から名前で探索（Prefab等のProject資産は除外）
    private static GameObject FindInAll(string name)
    {
        var all = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (var go in all)
        {
            if (go == null) continue;
            if (go.name != name) continue;
            if (!go.scene.IsValid()) continue; // Project資産を除く
            if (go.hideFlags != HideFlags.None) continue;
            return go;
        }
        return null;
    }

    private void ShowStartMenu()
    {
        // HUD切替集約
        HUDVisibilityManager.ShowStartMenu();
        Time.timeScale = 0f;
        if (playTimeManager != null) playTimeManager.PauseTimer();
        if (pauseMenuManager != null) pauseMenuManager.enabled = false; // ESCポーズは無効化
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        // Startボタンを選択状態にしてEnter/Submitで反応するようにする
        if (EventSystem.current != null && startButton != null)
        {
            EventSystem.current.SetSelectedGameObject(startButton.gameObject);
        }
        if (startAction != null && !startAction.enabled) startAction.Enable();
        startRequested = false;
        // Playerが存在するなら操作を止める（移動・視点回転も停止）
        var existingPlayerForStop = FindFirstObjectByType<Player>();
        if (existingPlayerForStop != null)
        {
            existingPlayerForStop.enabled = false;
            var rb = existingPlayerForStop.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }
        // HP を初期値に戻す（ゲーム開始前の整合）
        Global.player_hp = 10f;
        // Start_Menu表示時に自動セーブ
        Global.SaveProgress();
    }

    private void StartGame()
    {
        HUDVisibilityManager.ShowGameplay();
        // 念のため直接非表示（探索ミスや重複名対策のフォールバック）
        if (startMenuPanel != null && startMenuPanel.activeSelf) startMenuPanel.SetActive(false);
        Time.timeScale = 1f;
        if (playTimeManager != null) playTimeManager.ResumeTimer();
        if (pauseMenuManager != null) pauseMenuManager.enabled = true; // ゲーム開始後はESC有効
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // 既存Playerが居ない場合は生成
        var existingPlayer = FindFirstObjectByType<Player>();
        if (existingPlayer == null && playerPrefab != null)
        {
            Vector3 pos = playerSpawnPoint ? playerSpawnPoint.position : (startMenuPanel ? startMenuPanel.transform.position : transform.position);
            Quaternion rot = playerSpawnPoint ? playerSpawnPoint.rotation : Quaternion.identity;
            var newPlayerGO = Instantiate(playerPrefab, pos, rot);
            var pl = newPlayerGO.GetComponent<Player>();
            if (pl != null && Camera.main != null)
            {
                pl.AttachCamera(Camera.main.transform);
            }
        }
        else if (existingPlayer != null)
        {
            existingPlayer.enabled = true; // Start_Menuで止めたものを再開
        }
        if (startAction != null && startAction.enabled) startAction.Disable();
        startRequested = false;
    }

    private void OnStartClicked()
    {
        if (startRequested) return;
        startRequested = true;
        StartGame();
    }

    private void OnBuyClicked()
    {
        Debug.Log($"[StartMenuManager] OnBuyClicked called - Global.gold = {Global.gold}");
        
        // buyMenuManager が null なら再検索
        if (buyMenuManager == null)
        {
            Debug.LogWarning("[StartMenuManager] buyMenuManager is null, attempting to find it...");
            buyMenuManager = FindFirstObjectByType<BuyMenuManager>();
            if (buyMenuManager == null) buyMenuManager = FindAnyObjectByType<BuyMenuManager>();
        }
        
        Debug.Log($"[StartMenuManager] buyMenuManager: {(buyMenuManager != null ? buyMenuManager.name : "NULL")}");
        
        if (buyMenuManager != null)
        {
            Debug.Log($"[StartMenuManager] Calling buyMenuManager.ShowBuyMenu() with Global.gold = {Global.gold}");
            buyMenuManager.ShowBuyMenu();
            Debug.Log("[StartMenuManager] buyMenuManager.ShowBuyMenu() completed");
        }
        else
        {
            Debug.LogError("[StartMenuManager] buyMenuManager is NULL! Could not find BuyMenuManager in scene.");
        }
    }

    private void OnDeleteSaveClicked()
    {
        Debug.Log("[StartMenuManager] OnDeleteSaveClicked - Deleting save and resetting game state");
        Global.DeleteSave();
        
        // ゲーム状態をリセット
        Global.gold = Global.INIT_GOLD;  // 金を初期値にリセット（INIT_GOLD定数を使用）
        Global.purchasedPartIds.Clear();  // 購入済みパーツをクリア
        
        Debug.Log($"[StartMenuManager] After DeleteSave: gold = {Global.gold}, purchasedPartIds.Count = {Global.purchasedPartIds.Count}");
        
        // BuyMenuManagerを通じてUI更新
        if (buyMenuManager != null)
        {
            buyMenuManager.RebuildBuyUI();
        }
        
        // リセット状態を保存
        Global.SaveProgress();
        Debug.Log("[StartMenuManager] OnDeleteSaveClicked completed - State saved");
    }

    // 外部(GameOver等)からスタートメニューへ戻すための公開API
    public void ResetToStartMenu()
    {
        ShowStartMenu();
        // Playerが残っている場合は削除（再スタート時に再生成）
        var existingPlayer = FindFirstObjectByType<Player>();
        if (existingPlayer != null)
        {
            Destroy(existingPlayer.gameObject);
        }
    }

    // BuyMenuManagerから呼ばれてスタートメニューに戻す
    public void ReturnToStartMenu()
    {
        ShowStartMenu();
    }
}
