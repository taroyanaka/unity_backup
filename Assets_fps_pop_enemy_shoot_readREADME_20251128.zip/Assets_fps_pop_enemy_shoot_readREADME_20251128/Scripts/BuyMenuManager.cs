using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using System.Linq;

public class BuyMenuManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("Buy_Menu の TextMeshPro (UI)")] private TMP_Text buyMenuText;
    [SerializeField, Tooltip("Buyボタン")] private Button buyButton;
    [SerializeField, Tooltip("Backボタン (Buy_Menu用)")] private Button backButton;
    [SerializeField, Tooltip("Buy_Menu パネル")] private GameObject buyMenuPanel;
    [SerializeField, Tooltip("パーツリストのコンテナ")] private Transform partsContainer;
    [SerializeField, Tooltip("購入ボタンのプレハブ")] private GameObject partButtonPrefab;
    [SerializeField, Tooltip("所持Gold表示用テキスト")] private TMP_Text goldText;
    [SerializeField, Tooltip("購入済みパーツ表示用テキスト")] private TMP_Text ownedPartsText;
    [SerializeField, Tooltip("PlayTimeManager (未設定なら自動検出)")] private PlayTimeManager playTimeManager;
    [SerializeField, Tooltip("PartsManager (未設定なら自動検出)")] private PartsManager partsManager;

    private bool inBuyMenu = false;
    private List<string> visibleIds = new List<string>();
    private List<GameObject> partButtons = new List<GameObject>();
    private StartMenuManager startMenuManager;

    private void Awake()
    {
        Debug.Log("[BuyMenuManager] Awake called");
        
        // このスクリプトがアタッチされているGameObjectが Buy_Menu パネルそのもの
        buyMenuPanel = gameObject;
        Debug.Log($"[BuyMenuManager] buyMenuPanel set to: {buyMenuPanel.name}");
        
        // 自動参照
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null) playTimeManager = FindAnyObjectByType<PlayTimeManager>();
        }
        if (partsManager == null)
        {
            partsManager = FindFirstObjectByType<PartsManager>();
            if (partsManager == null) partsManager = FindAnyObjectByType<PartsManager>();
            if (partsManager == null)
            {
                Debug.LogError("[BuyMenuManager] PartsManager not found! Make sure PartsManager component exists in the scene.");
                Debug.LogWarning("[BuyMenuManager] Creating PartsManager automatically...");
                var partsManagerGO = new GameObject("PartsManager");
                partsManager = partsManagerGO.AddComponent<PartsManager>();
                Debug.Log("[BuyMenuManager] PartsManager created successfully");
            }
            else
            {
                Debug.Log($"[BuyMenuManager] Found PartsManager: {partsManager.name}");
                var parts = partsManager.GetAllParts();
                Debug.Log($"[BuyMenuManager] PartsManager has {(parts != null ? parts.Count : 0)} parts available");
            }
        }
        if (buyMenuText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Buy_Menu") { buyMenuText = t; break; }
            }
        }
        if (goldText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Gold_Text") { goldText = t; break; }
            }
        }
        if (ownedPartsText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Owned_Parts_Text") { ownedPartsText = t; break; }
            }
        }
        if (partsContainer == null)
        {
            var containerGO = FindInAll("Parts_Container");
            if (containerGO != null) partsContainer = containerGO.transform;
        }
        if (backButton == null)
        {
            var btnGo = FindInAll("Back_Button");
            if (btnGo != null) backButton = btnGo.GetComponent<Button>();
        }

        if (backButton != null) backButton.onClick.AddListener(OnBackClicked);

        startMenuManager = FindFirstObjectByType<StartMenuManager>();
        if (startMenuManager == null) startMenuManager = FindAnyObjectByType<StartMenuManager>();
        
        Debug.Log("[BuyMenuManager] Awake complete");
        Debug.Log($"[BuyMenuManager] buyMenuPanel: {(buyMenuPanel != null ? buyMenuPanel.name : "NULL")}");
        Debug.Log($"[BuyMenuManager] partsManager: {(partsManager != null ? partsManager.name : "NULL")}");
        Debug.Log($"[BuyMenuManager] startMenuManager: {(startMenuManager != null ? startMenuManager.name : "NULL")}");
    }

    private void OnDestroy()
    {
        if (backButton != null) backButton.onClick.RemoveListener(OnBackClicked);
    }

    private void Update()
    {
        var keyboard = Keyboard.current;
        if (keyboard == null) return;

        if (inBuyMenu)
        {
            // 1〜9キーで購入試行（新Input System）
            var keys = new[] { keyboard.digit1Key, keyboard.digit2Key, keyboard.digit3Key, keyboard.digit4Key,
                               keyboard.digit5Key, keyboard.digit6Key, keyboard.digit7Key, keyboard.digit8Key, keyboard.digit9Key };
            for (int i = 0; i < keys.Length; i++)
            {
                var k = keys[i];
                if (k != null && k.wasPressedThisFrame)
                {
                    TryPurchaseIndex(i);
                    break;
                }
            }
            return;
        }
    }

    // 非アクティブ含めシーン上から名前で探索（Prefab等のProject資産は除外）
    private static GameObject FindInAll(string name)
    {
        var all = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (var go in all)
        {
            if (go == null) continue;
            if (go.name != name) continue;
            if (!go.scene.IsValid()) continue; // Project資産を除く
            if (go.hideFlags != HideFlags.None) continue;
            return go;
        }
        return null;
    }

    public void ShowBuyMenu()
    {
        Debug.Log($"[BuyMenuManager] ShowBuyMenu called - Global.gold = {Global.gold}");
        inBuyMenu = true;
        HUDVisibilityManager.ShowBuyMenu();
        RebuildBuyUI();
        Time.timeScale = 0f;
        if (playTimeManager != null) playTimeManager.PauseTimer();
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void OnBackClicked()
    {
        if (inBuyMenu)
        {
            HideBuyMenu();
        }
    }

    private void HideBuyMenu()
    {
        inBuyMenu = false;
        if (startMenuManager != null)
        {
            startMenuManager.ReturnToStartMenu();
        }
    }

    public void RebuildBuyUI()
    {
        Debug.Log($"[BuyMenuManager] RebuildBuyUI called - Current Global.gold = {Global.gold}");
        
        // PartsManager から全パーツを取得
        List<PartDefinition> parts = null;
        if (partsManager != null)
        {
            var partsResult = partsManager.GetAllParts();
            if (partsResult != null)
            {
                parts = new List<PartDefinition>(partsResult);
            }
        }

        // 所持Gold表示を更新
        if (goldText != null)
        {
            goldText.text = $"Gold: {Global.gold}";
            Debug.Log($"[BuyMenuManager] Updated goldText with Global.gold = {Global.gold}");
        }
        else
        {
            Debug.Log($"[BuyMenuManager] goldText is null, creating it with Global.gold = {Global.gold}");
            CreateGoldDisplayIfNeeded();
        }

        // 購入済みパーツ表示を更新
        UpdateOwnedPartsDisplay();

        // 既존の購入ボタンを削除
        ClearPartButtons();

        // パーツボタンを生成
        if (parts != null && parts.Count > 0)
        {
            CreatePartButtons(parts);
        }

        // 従来のテキスト表示も更新（後方互換）
        if (buyMenuText != null)
        {
            RebuildBuyListText(parts);
        }
        else if (partButtons.Count == 0 && parts != null && parts.Count > 0)
        {
            CreateMinimalBuyMenuDisplay(parts);
        }
    }

    private void CreateGoldDisplayIfNeeded()
    {
        if (buyMenuPanel != null && goldText == null)
        {
            // Gold表示用テキストを動的作成
            var goldTextGO = new GameObject("Gold_Text");
            goldTextGO.transform.SetParent(buyMenuPanel.transform, false);
            
            var rectTransform = goldTextGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0, 1);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.anchoredPosition = new Vector2(0, -30);
            rectTransform.sizeDelta = new Vector2(0, 50);
            
            var text = goldTextGO.AddComponent<TextMeshProUGUI>();
            text.text = $"Gold: {Global.gold}";
            text.fontSize = 36;
            text.color = Color.yellow;
            text.alignment = TextAlignmentOptions.Center;
            text.fontStyle = FontStyles.Bold;
            
            goldText = text;
        }
    }

    private void UpdateOwnedPartsDisplay()
    {
        if (ownedPartsText == null)
        {
            CreateOwnedPartsDisplayIfNeeded();
        }

        if (ownedPartsText == null) return;

        var sb = new StringBuilder();
        sb.AppendLine("Owned Parts:");
        
        var ownedList = Global.purchasedPartIds;
        if (ownedList == null || ownedList.Count == 0)
        {
            sb.AppendLine("(none)");
        }
        else
        {
            foreach (var oid in ownedList)
            {
                if (string.IsNullOrEmpty(oid)) continue;
                string name = oid;
                float hp = 0f, spd = 0f;
                if (partsManager != null)
                {
                    var def = partsManager.GetDefinition(oid);
                    if (def != null)
                    {
                        name = string.IsNullOrEmpty(def.displayName) ? def.id : def.displayName;
                        hp = def.hpAdd; spd = def.speedAdd;
                    }
                }
                sb.Append("• ").Append(name)
                  .Append(" (HP+").Append(hp.ToString("0.##"))
                  .Append(", SPD+").Append(spd.ToString("0.##"))
                  .AppendLine(")");
            }
        }

        // 総合計ボーナス
        var totals = PartsManager.GetTotalBonuses();
        sb.AppendLine();
        sb.AppendLine("Total Bonus:");
        sb.Append("HP+").Append(totals.hpAdd.ToString("0.##"))
          .Append(", SPD+").Append(totals.speedAdd.ToString("0.##"));

        ownedPartsText.text = sb.ToString();
    }

    private void CreateOwnedPartsDisplayIfNeeded()
    {
        if (buyMenuPanel != null && ownedPartsText == null)
        {
            // 購入済みパーツ表示用テキストを動的作成
            var ownedTextGO = new GameObject("Owned_Parts_Text");
            ownedTextGO.transform.SetParent(buyMenuPanel.transform, false);
            
            var rectTransform = ownedTextGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(1, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.anchoredPosition = new Vector2(-150, 0);
            rectTransform.sizeDelta = new Vector2(280, 0);
            
            var text = ownedTextGO.AddComponent<TextMeshProUGUI>();
            text.text = "Owned Parts:\n(none)";
            text.fontSize = 20;
            text.color = Color.cyan;
            text.alignment = TextAlignmentOptions.TopLeft;
            text.overflowMode = TextOverflowModes.Overflow;
            
            ownedPartsText = text;
        }
    }

    private void ClearPartButtons()
    {
        foreach (var btn in partButtons)
        {
            if (btn != null) DestroyImmediate(btn);
        }
        partButtons.Clear();
        visibleIds.Clear();
    }

    private void CreatePartButtons(List<PartDefinition> parts)
    {
        if (parts == null || parts.Count == 0)
        {
            return;
        }
        
        if (partsContainer == null)
        {
            SetupPartsContainer();
        }
        
        if (partsContainer == null) 
        {
            Debug.LogError("[BuyMenuManager] Failed to setup PartsContainer!");
            return;
        }
        
        foreach (var part in parts)
        {
            if (part == null || string.IsNullOrEmpty(part.id)) 
            {
                continue;
            }
            CreatePartButton(part);
        }
    }

    private void SetupPartsContainer()
    {
        if (buyMenuPanel != null)
        {
            // 既存のコンテナを探す
            var existingContainer = buyMenuPanel.transform.Find("Parts_Container");
            if (existingContainer != null)
            {
                partsContainer = existingContainer;
                return;
            }

            // コンテナを動的作成
            var containerGO = new GameObject("Parts_Container");
            containerGO.transform.SetParent(buyMenuPanel.transform, false);
            
            var rectTransform = containerGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.offsetMin = new Vector2(10, 10);
            rectTransform.offsetMax = new Vector2(-10, -100); // 下部にスペース確保

            // VerticalLayoutGroupを追加して縦並びレイアウト
            var layoutGroup = containerGO.AddComponent<UnityEngine.UI.VerticalLayoutGroup>();
            layoutGroup.spacing = 10;
            layoutGroup.childAlignment = TextAnchor.UpperCenter;
            layoutGroup.childControlHeight = false;
            layoutGroup.childControlWidth = false;
            layoutGroup.childForceExpandHeight = false;
            layoutGroup.childForceExpandWidth = true;

            // ContentSizeFitterを追加
            var sizeFitter = containerGO.AddComponent<UnityEngine.UI.ContentSizeFitter>();
            sizeFitter.verticalFit = UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize;

            // ScrollRectを追加してスクロール可能にする（パーツが多い場合）
            var scrollRect = buyMenuPanel.GetComponent<ScrollRect>();
            if (scrollRect == null)
            {
                scrollRect = buyMenuPanel.AddComponent<ScrollRect>();
                scrollRect.content = rectTransform;
                scrollRect.vertical = true;
                scrollRect.horizontal = false;
            }

            partsContainer = containerGO.transform;
        }
        else
        {
            Debug.LogError("[BuyMenuManager] buyMenuPanel is null, cannot setup container!");
        }
    }

    private void CreatePartButton(PartDefinition part)
    {
        bool owned = Global.purchasedPartIds.Contains(part.id);
        bool affordable = Global.gold >= Mathf.Max(0, part.goldPrice);
        
        GameObject buttonGO;
        if (partButtonPrefab != null)
        {
            buttonGO = Instantiate(partButtonPrefab, partsContainer);
        }
        else
        {
            // プレハブが設定されていない場合は動的作成
            buttonGO = CreateDefaultPartButton();
            buttonGO.transform.SetParent(partsContainer, false);
        }

        // ボタンコンポーネントを取得
        var button = buttonGO.GetComponent<Button>();
        if (button == null) button = buttonGO.AddComponent<Button>();

        // テキストコンポーネントを探すか作成
        var textComponent = buttonGO.GetComponentInChildren<TextMeshProUGUI>();
        if (textComponent == null)
        {
            var textGO = new GameObject("Text");
            textGO.transform.SetParent(buttonGO.transform, false);
            
            var textRect = textGO.AddComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;
            
            textComponent = textGO.AddComponent<TextMeshProUGUI>();
        }

        // テキスト設定
        string displayText = $"{part.displayName}\nHP+{part.hpAdd:0.##}, SPD+{part.speedAdd:0.##}\nPrice: {Mathf.Max(0, part.goldPrice)} Gold";
        if (owned)
        {
            displayText = $"{part.displayName}\nHP+{part.hpAdd:0.##}, SPD+{part.speedAdd:0.##}\n(Already Owned)";
        }
        textComponent.text = displayText;
        textComponent.fontSize = 12;
        textComponent.alignment = TextAlignmentOptions.Center;
        
        // 色設定
        if (owned)
        {
            textComponent.color = Color.gray;
            var image = buttonGO.GetComponent<UnityEngine.UI.Image>();
            if (image != null) image.color = new Color(0.3f, 0.3f, 0.3f, 0.5f);
        }
        else if (affordable)
        {
            textComponent.color = Color.white;
            var image = buttonGO.GetComponent<UnityEngine.UI.Image>();
            if (image != null) image.color = new Color(0.2f, 0.5f, 0.3f, 0.8f);
        }
        else
        {
            textComponent.color = Color.red;
            var image = buttonGO.GetComponent<UnityEngine.UI.Image>();
            if (image != null) image.color = new Color(0.5f, 0.2f, 0.2f, 0.8f);
        }

        // ボタンの有効/無効設定
        button.interactable = !owned && affordable;
        
        // Goldが足りない場合はボタンを非表示
        if (!owned && !affordable)
        {
            buttonGO.SetActive(false);
        }

        // クリックイベント設定
        string partId = part.id; // ラムダキャプチャ用のローカル変数
        button.onClick.AddListener(() => OnPartButtonClicked(partId));

        partButtons.Add(buttonGO);
        visibleIds.Add(part.id);
    }

    private GameObject CreateDefaultPartButton()
    {
        var buttonGO = new GameObject("PartButton");
        var rectTransform = buttonGO.AddComponent<RectTransform>();
        rectTransform.sizeDelta = new Vector2(250, 100);
        
        var image = buttonGO.AddComponent<UnityEngine.UI.Image>();
        image.color = new Color(0.2f, 0.3f, 0.5f, 0.8f);
        
        // LayoutElementを追加して自動レイアウトをサポート
        var layoutElement = buttonGO.AddComponent<UnityEngine.UI.LayoutElement>();
        layoutElement.minHeight = 100;
        layoutElement.minWidth = 250;
        
        return buttonGO;
    }

    private void OnPartButtonClicked(string partId)
    {
        // 購入処理（購入済みパーツは Global.cs で管理）
        if (string.IsNullOrEmpty(partId) || partsManager == null) return;
        
        // パーツ定義を取得
        var partDef = partsManager.GetDefinition(partId);
        if (partDef == null) return;
        
        // すでに購入済みか確認
        if (Global.purchasedPartIds.Contains(partId))
        {
            return;
        }
        
        // Gold が十分か確認
        int price = Mathf.Max(0, partDef.goldPrice);
        if (Global.gold < price)
        {
            return;
        }
        
        // 購入処理
        Global.gold -= price;
        Global.purchasedPartIds.Add(partId);
        Global.SaveProgress();
        
        // UI 更新
        RebuildBuyUI();
    }

    private void CreateMinimalBuyMenuDisplay(List<PartDefinition> parts)
    {
        if (buyMenuPanel == null) return;
        
        // 最小限のテキスト表示を作成
        var textGO = new GameObject("MinimalBuyMenuText");
        textGO.transform.SetParent(buyMenuPanel.transform, false);
        
        var rectTransform = textGO.AddComponent<RectTransform>();
        rectTransform.anchorMin = Vector2.zero;
        rectTransform.anchorMax = Vector2.one;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        
        var text = textGO.AddComponent<TextMeshProUGUI>();
        text.fontSize = 20;
        text.color = Color.white;
        text.alignment = TextAlignmentOptions.TopLeft;
        text.margin = new Vector4(20, 20, 20, 20);
        
        // パーツ情報を表示
        var sb = new StringBuilder();
        sb.AppendLine($"=== BUY MENU ===");
        sb.AppendLine($"Gold: {Global.gold}");
        sb.AppendLine();
        
        if (parts != null && parts.Count > 0)
        {
            sb.AppendLine("Available Parts:");
            int index = 1;
            foreach (var part in parts)
            {
                if (part == null || string.IsNullOrEmpty(part.id)) continue;
                bool owned = Global.purchasedPartIds.Contains(part.id);
                bool affordable = Global.gold >= part.goldPrice;
                
                string status = owned ? "(Owned)" : (!affordable ? "(Can't afford)" : "");
                sb.AppendLine($"{index}. {part.displayName} - {part.goldPrice} Gold {status}");
                sb.AppendLine($"   HP+{part.hpAdd}, SPD+{part.speedAdd}");
                index++;
            }
            sb.AppendLine();
            sb.AppendLine("Press 1-9 to purchase, or use buttons if available");
        }
        else
        {
            sb.AppendLine("No parts available");
        }
        
        text.text = sb.ToString();
        buyMenuText = text; // 参照を保存
        
        Debug.Log("[BuyMenuManager] Created minimal buy menu display");
    }

    private void RebuildBuyListText(List<PartDefinition> parts)
    {
        if (buyMenuText == null) return;
        var sb = new StringBuilder();
        sb.AppendLine($"Buy Menu  Gold: {Global.gold}");
        sb.AppendLine("===========================");

        if (parts == null || parts.Count == 0)
        {
            sb.AppendLine("No Parts");
        }
        else
        {
            int idx = 1;
            foreach (var p in parts)
            {
                if (p == null || string.IsNullOrEmpty(p.id)) continue;
                bool owned = Global.purchasedPartIds.Contains(p.id);
                bool affordable = Global.gold >= Mathf.Max(0, p.goldPrice);
                string color = (owned || !affordable) ? "#888888" : "#FFFFFF"; // 灰 or 白
                string ownedTag = owned ? " (Owned)" : "";
                sb.Append("<color=").Append(color).Append(">");
                sb.Append(idx).Append(". ").Append(p.displayName);
                sb.Append("  HP+").Append(p.hpAdd.ToString("0.##"));
                sb.Append("  SPD+").Append(p.speedAdd.ToString("0.##"));
                sb.Append("  Price:").Append(Mathf.Max(0, p.goldPrice));
                sb.Append(ownedTag);
                sb.AppendLine("</color>");
                idx++;
            }
        }

        sb.AppendLine("\n[1-9] で購入 / Backボタンで戻る");
        sb.AppendLine("\nまたは各パーツの購入ボタンをクリック");

        buyMenuText.text = sb.ToString();
    }

    private void TryPurchaseIndex(int idx)
    {
        if (partsManager == null) return;
        if (idx < 0 || idx >= visibleIds.Count) return;
        
        string partId = visibleIds[idx];
        if (string.IsNullOrEmpty(partId)) return;
        
        // すでに購入済みなら何もしない
        if (Global.purchasedPartIds.Contains(partId))
        {
            RebuildBuyUI();
            return;
        }
        
        // パーツ定義を取得
        var partDef = partsManager.GetDefinition(partId);
        if (partDef == null) return;
        
        // Gold が十分か確認
        int price = Mathf.Max(0, partDef.goldPrice);
        if (Global.gold < price)
        {
            RebuildBuyUI();
            return;
        }
        
        // 購入処理
        Global.gold -= price;
        Global.purchasedPartIds.Add(partId);
        Global.SaveProgress();
        
        RebuildBuyUI();
    }
}
