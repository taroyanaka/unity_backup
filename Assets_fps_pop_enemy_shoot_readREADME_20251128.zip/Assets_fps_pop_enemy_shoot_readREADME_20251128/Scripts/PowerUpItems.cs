using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// パワーアップアイテムの定義データ（ID、表示名、スコア価格、ボーナス）
/// </summary>
[Serializable]
public class PowerUpItemDefinition
{
    [Tooltip("一意のID (例: AtkUp1)")] 
    public string id = "";
    
    [Tooltip("表示名")] 
    public string displayName = "";
    
    [Tooltip("購入価格(Score)")] 
    public int scorePrice = 1;
    
    [Header("Bonuses (加算)")]
    [Tooltip("弾の攻撃力への加算値")] 
    public float atkAdd = 0f;
}

/// <summary>
/// パワーアップアイテム管理 - パワーアップアイテム定義データのみを保持
/// 購入処理は PowerUpMenuManager で行う
/// </summary>
public class PowerUpItemsManager : MonoBehaviour
{
    public static PowerUpItemsManager Instance { get; private set; }

    [Header("Available PowerUp Items")]
    [SerializeField, Tooltip("購入可能なパワーアップアイテム一覧")] 
    private List<PowerUpItemDefinition> availableItems = new List<PowerUpItemDefinition>
    {
        new PowerUpItemDefinition
        {
            id = "AtkUp1",
            displayName = "Atk Up 1",
            scorePrice = 2,
            atkAdd = 1f
        },
        new PowerUpItemDefinition
        {
            id = "AtkUp2",
            displayName = "Atk Up 2",
            scorePrice = 4,
            atkAdd = 2f
        },
        new PowerUpItemDefinition
        {
            id = "AtkUp3",
            displayName = "Atk Up 3",
            scorePrice = 6,
            atkAdd = 3f
        }
    };

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    /// <summary>
    /// すべてのパワーアップアイテム定義を取得
    /// </summary>
    public IReadOnlyList<PowerUpItemDefinition> GetAllItems()
    {
        return availableItems;
    }

    /// <summary>
    /// ID からパワーアップアイテム定義を検索
    /// </summary>
    public PowerUpItemDefinition GetDefinition(string id)
    {
        if (string.IsNullOrEmpty(id)) return null;
        if (availableItems == null) return null;
        
        foreach (var item in availableItems)
        {
            if (item != null && item.id == id)
            {
                return item;
            }
        }
        return null;
    }

    /// <summary>
    /// 購入済みパワーアップアイテムの合計ボーナスを計算
    /// </summary>
    public static float GetTotalBonuses()
    {
        float atk = 0f;
        
        if (Instance == null) return 0f;
        
        var purchasedList = Global.purchasedPowerUpItemIds;
        if (purchasedList == null || purchasedList.Count == 0) 
        {
            return 0f;
        }

        for (int i = 0; i < purchasedList.Count; i++)
        {
            var id = purchasedList[i];
            var def = Instance.GetDefinition(id);
            if (def == null) continue;
            
            atk += Mathf.Max(0f, def.atkAdd);
        }
        
        return atk;
    }
}
