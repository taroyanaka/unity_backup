using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using System.Linq;

public class PowerUpMenuManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("Power_Up パネルの TextMeshPro (UI)")] private TMP_Text powerUpMenuText;
    [SerializeField, Tooltip("Power_Up パネル")] private GameObject powerUpMenuPanel;
    [SerializeField, Tooltip("アイテムリストのコンテナ")] private Transform itemsContainer;
    [SerializeField, Tooltip("購入ボタンのプレハブ")] private GameObject itemButtonPrefab;
    [SerializeField, Tooltip("所持Score表示用テキスト")] private TMP_Text scoreText;
    [SerializeField, Tooltip("購入済みパワーアップアイテム表示用テキスト")] private TMP_Text ownedItemsText;
    [SerializeField, Tooltip("購入可能なアイテム一覧用テキスト")] private TMP_Text availableItemsText;
    [SerializeField, Tooltip("PowerUpItemsManager (未設定なら自動検出)")] private PowerUpItemsManager itemsManager;
    [SerializeField, Tooltip("Backボタン (Power_Up用)")] private Button backButton;

    private bool inPowerUpMenu = false;
    private List<string> visibleIds = new List<string>();
    private List<GameObject> itemButtons = new List<GameObject>();
    private HUDVisibilityManager hudManager;

    private void Awake()
    {
        Debug.Log("[PowerUpMenuManager] Awake called");
        
        // このスクリプトがアタッチされているGameObjectが Power_Up パネルそのもの
        powerUpMenuPanel = gameObject;
        Debug.Log($"[PowerUpMenuManager] powerUpMenuPanel set to: {powerUpMenuPanel.name}");
        
        // 自動参照
        if (itemsManager == null)
        {
            itemsManager = FindFirstObjectByType<PowerUpItemsManager>();
            if (itemsManager == null) itemsManager = FindAnyObjectByType<PowerUpItemsManager>();
            if (itemsManager == null)
            {
                Debug.LogError("[PowerUpMenuManager] PowerUpItemsManager not found! Make sure PowerUpItemsManager component exists in the scene.");
                Debug.LogWarning("[PowerUpMenuManager] Creating PowerUpItemsManager automatically...");
                var itemsManagerGO = new GameObject("PowerUpItemsManager");
                itemsManager = itemsManagerGO.AddComponent<PowerUpItemsManager>();
                Debug.Log("[PowerUpMenuManager] PowerUpItemsManager created successfully");
            }
            else
            {
                Debug.Log($"[PowerUpMenuManager] Found PowerUpItemsManager: {itemsManager.name}");
                var items = itemsManager.GetAllItems();
                Debug.Log($"[PowerUpMenuManager] PowerUpItemsManager has {(items != null ? items.Count : 0)} items available");
            }
        }
        
        if (powerUpMenuText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Power_Up") { powerUpMenuText = t; break; }
            }
        }
        if (scoreText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Score_Text") { scoreText = t; break; }
            }
        }
        if (ownedItemsText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Owned_Items_Text") { ownedItemsText = t; break; }
            }
        }
        if (availableItemsText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Available_Items_Text") { availableItemsText = t; break; }
            }
        }
        if (itemsContainer == null)
        {
            var containerGO = FindInAll("Items_Container");
            if (containerGO != null) itemsContainer = containerGO.transform;
        }
        if (backButton == null)
        {
            var btnGo = FindInAll("PowerUp_Back_Button");
            if (btnGo != null) backButton = btnGo.GetComponent<Button>();
        }

        if (backButton != null) backButton.onClick.AddListener(OnBackClicked);

        hudManager = FindFirstObjectByType<HUDVisibilityManager>();
        if (hudManager == null) hudManager = FindAnyObjectByType<HUDVisibilityManager>();
        
        Debug.Log("[PowerUpMenuManager] Awake complete");
        Debug.Log($"[PowerUpMenuManager] powerUpMenuPanel: {(powerUpMenuPanel != null ? powerUpMenuPanel.name : "NULL")}");
        Debug.Log($"[PowerUpMenuManager] itemsManager: {(itemsManager != null ? itemsManager.name : "NULL")}");
    }

    private void OnDestroy()
    {
        if (backButton != null) backButton.onClick.RemoveListener(OnBackClicked);
    }

    private void Update()
    {
        var keyboard = Keyboard.current;
        if (keyboard == null) return;

        if (inPowerUpMenu)
        {
            // 1〜9キーで購入試行（新Input System）
            var keys = new[] { keyboard.digit1Key, keyboard.digit2Key, keyboard.digit3Key, keyboard.digit4Key,
                               keyboard.digit5Key, keyboard.digit6Key, keyboard.digit7Key, keyboard.digit8Key, keyboard.digit9Key };
            for (int i = 0; i < keys.Length; i++)
            {
                var k = keys[i];
                if (k != null && k.wasPressedThisFrame)
                {
                    TryPurchaseIndex(i);
                    break;
                }
            }
            return;
        }
    }

    // 非アクティブ含めシーン上から名前で探索（Prefab等のProject資産は除外）
    private static GameObject FindInAll(string name)
    {
        var all = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (var go in all)
        {
            if (go == null) continue;
            if (go.name != name) continue;
            if (!go.scene.IsValid()) continue; // Project資産を除く
            if (go.hideFlags != HideFlags.None) continue;
            return go;
        }
        return null;
    }

    public void ShowPowerUpMenu()
    {
        Debug.Log($"[PowerUpMenuManager] ShowPowerUpMenu called - ScoreManager.Instance.GetScore() = {(ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0)}");
        inPowerUpMenu = true;
        RebuildPowerUpUI();
        Time.timeScale = 0f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void OnBackClicked()
    {
        if (inPowerUpMenu)
        {
            HidePowerUpMenu();
        }
    }

    private void HidePowerUpMenu()
    {
        inPowerUpMenu = false;
        if (hudManager != null)
        {
            HUDVisibilityManager.ShowGameplay();
        }
        Time.timeScale = 1f;
    }

    public void RebuildPowerUpUI()
    {
        Debug.Log($"[PowerUpMenuManager] RebuildPowerUpUI called - Current Score = {(ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0)}");
        
        // PowerUpItemsManager から全アイテムを取得
        List<PowerUpItemDefinition> items = null;
        if (itemsManager != null)
        {
            var itemsResult = itemsManager.GetAllItems();
            if (itemsResult != null)
            {
                items = new List<PowerUpItemDefinition>(itemsResult);
            }
        }

        // 所持Score表示を更新
        int currentScore = ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0;
        UpdateScoreDisplay(currentScore);

        // 購入済みアイテム表示を更新
        UpdateOwnedItemsDisplay();

        // 購入可能なアイテム表示を更新
        UpdateAvailableItemsDisplay(items, currentScore);

        // 既存の購入ボタンを削除
        ClearItemButtons();

        // アイテムボタンを生成
        if (items != null && items.Count > 0)
        {
            CreateItemButtons(items);
        }
    }

    private void UpdateScoreDisplay(int currentScore)
    {
        if (scoreText != null)
        {
            scoreText.text = $"Score: {currentScore}";
            Debug.Log($"[PowerUpMenuManager] Updated scoreText with current score = {currentScore}");
        }
        else
        {
            Debug.Log($"[PowerUpMenuManager] scoreText is null, creating it");
            CreateScoreDisplayIfNeeded();
        }
    }

    private void CreateScoreDisplayIfNeeded()
    {
        if (powerUpMenuPanel != null && scoreText == null)
        {
            // Score表示用テキストを動的作成
            var scoreTextGO = new GameObject("Score_Text");
            scoreTextGO.transform.SetParent(powerUpMenuPanel.transform, false);
            
            var rectTransform = scoreTextGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0, 1);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.anchoredPosition = new Vector2(0, -30);
            rectTransform.sizeDelta = new Vector2(0, 50);
            
            var text = scoreTextGO.AddComponent<TextMeshProUGUI>();
            int currentScore = ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0;
            text.text = $"Score: {currentScore}";
            text.fontSize = 36;
            text.color = Color.cyan;
            text.alignment = TextAlignmentOptions.Center;
            text.fontStyle = FontStyles.Bold;
            
            scoreText = text;
        }
    }

    private void UpdateOwnedItemsDisplay()
    {
        if (ownedItemsText == null)
        {
            CreateOwnedItemsDisplayIfNeeded();
        }

        if (ownedItemsText == null) return;

        var sb = new StringBuilder();
        sb.AppendLine("Owned Power-Up Items:");
        
        var ownedList = Global.purchasedPowerUpItemIds;
        if (ownedList == null || ownedList.Count == 0)
        {
            sb.AppendLine("(none)");
        }
        else
        {
            foreach (var oid in ownedList)
            {
                if (string.IsNullOrEmpty(oid)) continue;
                string name = oid;
                float atk = 0f;
                if (itemsManager != null)
                {
                    var def = itemsManager.GetDefinition(oid);
                    if (def != null)
                    {
                        name = string.IsNullOrEmpty(def.displayName) ? def.id : def.displayName;
                        atk = def.atkAdd;
                    }
                }
                sb.Append("• ").Append(name)
                  .Append(" (ATK+").Append(atk.ToString("0.##"))
                  .AppendLine(")");
            }
        }

        // 総合計ボーナス
        var totals = PowerUpItemsManager.GetTotalBonuses();
        sb.AppendLine();
        sb.AppendLine("Total Bonus:");
        sb.Append("ATK+").Append(totals.ToString("0.##"));

        ownedItemsText.text = sb.ToString();
        Debug.Log($"[PowerUpMenuManager] Updated ownedItemsText with {(ownedList != null ? ownedList.Count : 0)} items");
    }

    private void UpdateAvailableItemsDisplay(List<PowerUpItemDefinition> items, int currentScore)
    {
        if (availableItemsText == null)
        {
            CreateAvailableItemsDisplayIfNeeded();
        }

        if (availableItemsText == null) return;

        var sb = new StringBuilder();
        sb.AppendLine("=== Available Items ===");
        
        if (items == null || items.Count == 0)
        {
            sb.AppendLine("(No items available)");
        }
        else
        {
            int index = 1;
            foreach (var item in items)
            {
                if (item == null) continue;
                
                bool canAfford = currentScore >= item.scorePrice;
                string status = canAfford ? "✓" : "✗";
                string costColor = canAfford ? "<color=green>" : "<color=red>";
                
                sb.Append($"{status} {index}. {item.displayName}")
                  .Append($" | {costColor}{item.scorePrice}</color> Score")
                  .Append($" | ATK+{item.atkAdd}")
                  .AppendLine();
                
                index++;
            }
        }

        availableItemsText.text = sb.ToString();
        Debug.Log($"[PowerUpMenuManager] Updated availableItemsText");
    }

    private void CreateOwnedItemsDisplayIfNeeded()
    {
        if (powerUpMenuPanel != null && ownedItemsText == null)
        {
            // 購入済みアイテム表示用テキストを動的作成
            var ownedItemsGO = new GameObject("Owned_Items_Text");
            ownedItemsGO.transform.SetParent(powerUpMenuPanel.transform, false);
            
            var rectTransform = ownedItemsGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0, 0);
            rectTransform.anchorMax = new Vector2(0.5f, 1);
            rectTransform.anchoredPosition = Vector2.zero;
            rectTransform.sizeDelta = Vector2.zero;
            
            var text = ownedItemsGO.AddComponent<TextMeshProUGUI>();
            text.text = "Owned Power-Up Items:\n(none)";
            text.fontSize = 28;
            text.color = Color.white;
            text.alignment = TextAlignmentOptions.TopLeft;
            
            ownedItemsText = text;
        }
    }

    private void CreateAvailableItemsDisplayIfNeeded()
    {
        if (powerUpMenuPanel != null && availableItemsText == null)
        {
            // 購入可能なアイテム表示用テキストを動的作成
            var availableItemsGO = new GameObject("Available_Items_Text");
            availableItemsGO.transform.SetParent(powerUpMenuPanel.transform, false);
            
            var rectTransform = availableItemsGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0.5f, 0);
            rectTransform.anchorMax = new Vector2(1, 1);
            rectTransform.anchoredPosition = Vector2.zero;
            rectTransform.sizeDelta = Vector2.zero;
            
            var text = availableItemsGO.AddComponent<TextMeshProUGUI>();
            text.text = "Available Items:\n(none)";
            text.fontSize = 28;
            text.color = Color.white;
            text.alignment = TextAlignmentOptions.TopLeft;
            
            availableItemsText = text;
        }
    }

    private void ClearItemButtons()
    {
        foreach (var btn in itemButtons)
        {
            if (btn != null) Destroy(btn);
        }
        itemButtons.Clear();
        visibleIds.Clear();
    }

    private void CreateItemButtons(List<PowerUpItemDefinition> items)
    {
        int index = 0;
        foreach (var item in items)
        {
            if (item == null) continue;
            visibleIds.Add(item.id);

            // itemsContainer がない場合はボタン生成をスキップ
            if (itemsContainer == null)
            {
                Debug.Log($"[PowerUpMenuManager] Items container not found, skipping button creation for {item.displayName}");
                index++;
                continue;
            }

            GameObject btnGO = itemButtonPrefab != null
                ? Instantiate(itemButtonPrefab, itemsContainer)
                : CreateSimpleItemButton();

            if (btnGO == null) continue;

            var btn = btnGO.GetComponent<Button>();
            if (btn == null) btn = btnGO.AddComponent<Button>();

            int capturedIdx = index;
            btn.onClick.AddListener(() => TryPurchaseIndex(capturedIdx));

            var btnText = btnGO.GetComponentInChildren<TextMeshProUGUI>();
            if (btnText != null)
            {
                int currentScore = ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0;
                string costStr = item.scorePrice > currentScore ? $"<color=red>{item.scorePrice}</color>" : item.scorePrice.ToString();
                btnText.text = $"{(capturedIdx + 1)}. {item.displayName} (Cost: {costStr})";
            }

            itemButtons.Add(btnGO);
            index++;
        }
    }

    private GameObject CreateSimpleItemButton()
    {
        var btnGO = new GameObject("ItemButton");
        if (itemsContainer != null) btnGO.transform.SetParent(itemsContainer, false);
        
        var btn = btnGO.AddComponent<Button>();
        var image = btnGO.AddComponent<Image>();
        image.color = new Color(0.2f, 0.2f, 0.2f);

        var textGO = new GameObject("Text");
        textGO.transform.SetParent(btnGO.transform, false);
        var text = textGO.AddComponent<TextMeshProUGUI>();
        text.fontSize = 24;
        text.alignment = TextAlignmentOptions.Center;

        var rectTransform = btnGO.GetComponent<RectTransform>();
        if (rectTransform != null)
        {
            rectTransform.sizeDelta = new Vector2(400, 60);
        }

        return btnGO;
    }

    private void TryPurchaseIndex(int index)
    {
        if (index < 0 || index >= visibleIds.Count)
        {
            Debug.Log($"[PowerUpMenuManager] TryPurchaseIndex({index}) - invalid index");
            return;
        }

        string itemId = visibleIds[index];
        Debug.Log($"[PowerUpMenuManager] TryPurchaseIndex({index}) - itemId = {itemId}");

        var def = itemsManager.GetDefinition(itemId);
        if (def == null)
        {
            Debug.LogWarning($"[PowerUpMenuManager] Item definition not found for id: {itemId}");
            return;
        }

        int currentScore = ScoreManager.Instance != null ? ScoreManager.Instance.GetScore() : 0;
        if (currentScore < def.scorePrice)
        {
            Debug.Log($"[PowerUpMenuManager] Not enough score: have {currentScore}, need {def.scorePrice}");
            return;
        }

        // スコアを消費
        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.RemoveScore(def.scorePrice);
            Debug.Log($"[PowerUpMenuManager] Removed {def.scorePrice} score, remaining: {ScoreManager.Instance.GetScore()}");
        }

        // 購入済みリストに追加
        if (!Global.purchasedPowerUpItemIds.Contains(itemId))
        {
            Global.purchasedPowerUpItemIds.Add(itemId);
            Debug.Log($"[PowerUpMenuManager] Added {itemId} to purchasedPowerUpItemIds");
        }
        else
        {
            Debug.Log($"[PowerUpMenuManager] {itemId} already in purchasedPowerUpItemIds");
        }

        // グローバル状態を保存
        Global.SaveProgress();

        // UIを再構築
        RebuildPowerUpUI();
        Debug.Log($"[PowerUpMenuManager] Purchase complete: {def.displayName}");
    }

}
