using UnityEditor;
using UnityEngine;

// 選択中の Terrain のサイズ(X/Z)を一括変更するエディタユーティリティ
public static class TerrainSizeTools
{
	[MenuItem("Tools/Terrain/Scale XZ by 0.01 (1/100)")]
	public static void ScaleXZByOneHundredth()
	{
		var terrains = Selection.GetFiltered<Terrain>(SelectionMode.Editable | SelectionMode.TopLevel);
		if (terrains == null || terrains.Length == 0)
		{
			EditorUtility.DisplayDialog("Terrain Size", "Terrain を選択してください。", "OK");
			return;
		}

		foreach (var t in terrains)
		{
			if (t == null || t.terrainData == null) continue;
			Undo.RecordObject(t.terrainData, "Scale Terrain XZ by 0.01");
			var size = t.terrainData.size;
			size.x *= 0.01f; // 1/100
			size.z *= 0.01f; // 1/100
			t.terrainData.size = size;
			EditorUtility.SetDirty(t.terrainData);
		}
	}

	[MenuItem("Tools/Terrain/Set XZ to 100")]
	public static void SetXZTo100()
	{
		SetXZTo(100f);
	}

	[MenuItem("Tools/Terrain/Set XZ to... ")]
	public static void SetXZToPrompt()
	{
		string input = EditorUtility.DisplayDialogComplex("Set Terrain XZ", "この機能では X/Z サイズを同一値に設定します。\nカスタム値を入力するには 'Custom' を選んでください。", "100", "Cancel", "Custom").ToString();
		// 0: "100", 1: "Cancel", 2: "Custom" (DisplayDialogComplexの戻り値規約)
		int result;
		if (!int.TryParse(input, out result)) result = 1; // Cancel扱い
		switch (result)
		{
			case 0:
				SetXZTo(100f);
				break;
			case 2:
				string s = EditorUtility.DisplayDialog("Input", "XZ のサイズを入力 (float)", "OK") ? "" : ""; // ダミーでキャンセル扱い
				// Unity標準には単純な入力ダイアログが無いため、代替: すぐ 100 を設定するか、下のメニューを使ってください。
				EditorUtility.DisplayDialog("Hint", "任意の値に設定したい場合は、インスペクタで TerrainData Size の X/Z を直接入力してください。", "OK");
				break;
			default:
				break;
		}
	}

	private static void SetXZTo(float value)
	{
		var terrains = Selection.GetFiltered<Terrain>(SelectionMode.Editable | SelectionMode.TopLevel);
		if (terrains == null || terrains.Length == 0)
		{
			EditorUtility.DisplayDialog("Terrain Size", "Terrain を選択してください。", "OK");
			return;
		}

		foreach (var t in terrains)
		{
			if (t == null || t.terrainData == null) continue;
			Undo.RecordObject(t.terrainData, $"Set Terrain XZ to {value}");
			var size = t.terrainData.size;
			size.x = value;
			size.z = value;
			t.terrainData.size = size;
			EditorUtility.SetDirty(t.terrainData);
		}
	}
}
