// Utility to find and remove missing script references in the open scenes or selection
// Place this file under Assets/Editor/
#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class FindMissingScripts
{
    [MenuItem("Tools/Missing Scripts/Find In Open Scenes")]
    public static void FindInOpenScenes()
    {
        int totalGO = 0;
        int totalMissing = 0;

        for (int i = 0; i < SceneManager.sceneCount; i++)
        {
            var scene = SceneManager.GetSceneAt(i);
            if (!scene.isLoaded) continue;

            foreach (var root in scene.GetRootGameObjects())
            {
                FindInGameObject(root, ref totalGO, ref totalMissing);
            }
        }

        if (totalMissing == 0)
            Debug.Log("No missing scripts found in open scenes.");
        else
            Debug.LogWarning($"Found {totalMissing} missing script reference(s) on {totalGO} GameObject(s) in open scenes.");
    }

    [MenuItem("Tools/Missing Scripts/Remove Missing In Open Scenes")]
    public static void RemoveMissingInOpenScenes()
    {
        int removed = 0;

        for (int i = 0; i < SceneManager.sceneCount; i++)
        {
            var scene = SceneManager.GetSceneAt(i);
            if (!scene.isLoaded) continue;

            foreach (var root in scene.GetRootGameObjects())
            {
                removed += RemoveMissingInGameObject(root);
            }
        }

        if (removed == 0)
            Debug.Log("No missing scripts to remove in open scenes.");
        else
            Debug.LogWarning($"Removed {removed} missing script component(s) from open scenes.");
    }

    [MenuItem("Tools/Missing Scripts/Find In Selection")]
    public static void FindInSelection()
    {
        int totalGO = 0;
        int totalMissing = 0;
        foreach (var go in Selection.gameObjects)
        {
            FindInGameObject(go, ref totalGO, ref totalMissing);
        }

        if (totalMissing == 0)
            Debug.Log("No missing scripts found in selection.");
        else
            Debug.LogWarning($"Found {totalMissing} missing script reference(s) on {totalGO} GameObject(s) in selection.");
    }

    [MenuItem("Tools/Missing Scripts/Remove Missing In Selection")]
    public static void RemoveMissingInSelection()
    {
        int removed = 0;
        foreach (var go in Selection.gameObjects)
        {
            removed += RemoveMissingInGameObject(go);
        }

        if (removed == 0)
            Debug.Log("No missing scripts to remove in selection.");
        else
            Debug.LogWarning($"Removed {removed} missing script component(s) from selection.");
    }

    private static void FindInGameObject(GameObject go, ref int totalGO, ref int totalMissing)
    {
        totalGO++;
        var comps = go.GetComponents<Component>();
        for (int i = 0; i < comps.Length; i++)
        {
            if (comps[i] == null)
            {
                totalMissing++;
                string path = GetGameObjectPath(go);
                Debug.LogWarning($"Missing script found on GameObject: {path}", go);
            }
        }

        // recurse children
        foreach (Transform child in go.transform)
        {
            FindInGameObject(child.gameObject, ref totalGO, ref totalMissing);
        }
    }

    private static int RemoveMissingInGameObject(GameObject go)
    {
        int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);
        foreach (Transform child in go.transform)
        {
            removed += RemoveMissingInGameObject(child.gameObject);
        }
        if (removed > 0)
        {
            Undo.RegisterCompleteObjectUndo(go, "Remove Missing Scripts");
            EditorUtility.SetDirty(go);
        }
        return removed;
    }

    private static string GetGameObjectPath(GameObject go)
    {
        var stack = new Stack<string>();
        var current = go.transform;
        while (current != null)
        {
            stack.Push(current.name);
            current = current.parent;
        }
        return string.Join("/", stack);
    }
}
#endif
