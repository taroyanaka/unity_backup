using UnityEngine;
using TMPro;

public class PowerUpManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("プレイヤー参照（未設定ならタグ'Player'で探索）")] private Player player;
    [SerializeField, Tooltip("HUD直下のPower_UpのTextMeshPro")] private TMP_Text powerUpText;

    [Header("Config")] 
    [SerializeField, Tooltip("何点ごとに停止してパワーアップを提示するか（初期値3）")] private int intervalScore = 3;
    [SerializeField, Tooltip("提示する候補（BulletまたはBullet2のプレハブ）")] private GameObject[] bulletCandidates;

    private int nextThreshold;
    private bool pausedForPowerUp;

    private void Awake()
    {
        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null) player = pObj.GetComponent<Player>();
        }
        if (powerUpText == null)
        {
            // HUD/Power_Up という名前想定で探索（非アクティブ含む）
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Power_Up") { powerUpText = t; break; }
            }
        }
        nextThreshold = intervalScore;
        SetText("");
    }

    private void Update()
    {
        if (pausedForPowerUp)
        {
            // 入力待ち（簡易：マウス左クリックで購入、右クリックでスキップ）
            bool buy = Input.GetMouseButtonDown(0);
            bool skip = Input.GetMouseButtonDown(1) || Input.GetKeyDown(KeyCode.Escape);
            if (buy)
            {
                TryOfferAndBuy();
            }
            else if (skip)
            {
                ResumeGame();
            }
            return;
        }

        int score = (ScoreManager.Instance != null) ? ScoreManager.Instance.GetScore() : 0;
        if (intervalScore > 0 && score >= nextThreshold)
        {
            PauseAndOffer();
            nextThreshold += intervalScore; // 次の目標へ
        }
    }

    private void PauseAndOffer()
    {
        pausedForPowerUp = true;
        Time.timeScale = 0f;
        SetText(BuildOfferMessage());
    }

    private void ResumeGame()
    {
        pausedForPowerUp = false;
        SetText("");
        Time.timeScale = 1f;
    }

    private string BuildOfferMessage()
    {
        var cand = GetCurrentCandidate();
        if (cand == null) return "No PowerUp";
        int price = GetPriceOfPrefab(cand);
        string name = cand.name;
        return $"Power-Up: {name}  Price:{price}\n[LeftClick] Buy  [Right/Esc] Skip";
    }

    private GameObject GetCurrentCandidate()
    {
        // 今回は単純に 0 or 1 を提示（存在するもののみ）
        if (bulletCandidates != null)
        {
            for (int i = 0; i < bulletCandidates.Length; i++)
            {
                if (bulletCandidates[i] != null) return bulletCandidates[i];
            }
        }
        // フォールバック: Resources から Bullet/Bullet2 を探すこともできるが、ここでは null
        return null;
    }

    private int GetPriceOfPrefab(GameObject prefab)
    {
        if (prefab == null) return int.MaxValue;
        var b = prefab.GetComponent<Bullet>();
        if (b != null) return Mathf.Max(0, b.Price);
        var b2 = prefab.GetComponent<Bullet2>();
        if (b2 != null) return Mathf.Max(0, b2.Price);
        return 3; // 既定
    }

    private void TryOfferAndBuy()
    {
        var cand = GetCurrentCandidate();
        if (cand == null) { ResumeGame(); return; }
        int price = GetPriceOfPrefab(cand);
        int score = (ScoreManager.Instance != null) ? ScoreManager.Instance.GetScore() : 0;
        if (score < price) { SetText($"Not enough score. Need {price}"); return; }

        // プレイヤーに追加できるか
        if (player != null && player.TryAddBulletPrefab(cand))
        {
            // スコア消費
            if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.SetScore(score - price);
            }
            SetText($"Unlocked: {cand.name}");
            ResumeGame();
        }
        else
        {
            SetText("Cannot add (slots full or duplicate)");
        }
    }

    private void SetText(string s)
    {
        if (powerUpText != null) powerUpText.text = s;
    }
}
