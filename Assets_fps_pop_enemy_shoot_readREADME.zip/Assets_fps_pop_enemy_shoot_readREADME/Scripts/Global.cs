using UnityEngine;
using System.Collections.Generic;
using System;

public class Global : MonoBehaviour
{
    // グローバル設定（static）
    public static float player_hp = 10f;
    public static float bullet_atk = 5f;
    public static float enemy_hp = 10f;
    public static float enemy_atk = 1f;
    public static float enemy_spd = 1f;
    public static int clear_score = 10;
    public static int gold = 0; // 所持ゴールド（取得/消費で増減）
    
    // 購入済みパーツ（IDのリスト）
    public static List<string> purchasedPartIds = new List<string>();
    
    // Enemy2 用
    public static float enemy2_hp = 3f;          // 要望: 初期HP=3
    public static float enemy2_bullet_atk = 1f;  // 要望: 弾のATK=1

    // Player 複数弾スロット上限
    public static int player_max_bullet_slots = 3; // 装備できる弾種の最大数
 
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // ============ Save/Load (single slot, auto-save helpers) ============
    private const string KeyGold = "save_gold";
    private const string KeyParts = "save_parts"; // CSV by ','

    public static void SaveProgress()
    {
        try
        {
            PlayerPrefs.SetInt(KeyGold, Mathf.Max(0, gold));
            string csv = string.Join(',', purchasedPartIds ?? new List<string>());
            PlayerPrefs.SetString(KeyParts, csv);
            PlayerPrefs.Save();
            Debug.Log("Global.SaveProgress: saved.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.SaveProgress: failed: {e.Message}");
        }
    }

    public static void LoadProgress()
    {
        try
        {
            if (PlayerPrefs.HasKey(KeyGold)) gold = Mathf.Max(0, PlayerPrefs.GetInt(KeyGold, 0));
            if (PlayerPrefs.HasKey(KeyParts))
            {
                string csv = PlayerPrefs.GetString(KeyParts, string.Empty);
                purchasedPartIds.Clear();
                if (!string.IsNullOrEmpty(csv))
                {
                    var items = csv.Split(',');
                    for (int i = 0; i < items.Length; i++)
                    {
                        var id = items[i]?.Trim();
                        if (!string.IsNullOrEmpty(id)) purchasedPartIds.Add(id);
                    }
                }
            }
            Debug.Log("Global.LoadProgress: loaded.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.LoadProgress: failed: {e.Message}");
        }
    }

    public static void DeleteSave()
    {
        try
        {
            PlayerPrefs.DeleteKey(KeyGold);
            PlayerPrefs.DeleteKey(KeyParts);
            PlayerPrefs.Save();
            Debug.Log("Global.DeleteSave: deleted.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Global.DeleteSave: failed: {e.Message}");
        }
    }
}
