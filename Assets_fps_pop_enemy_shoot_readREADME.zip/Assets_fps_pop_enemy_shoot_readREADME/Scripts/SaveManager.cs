using System;
using System.Collections.Generic;
using UnityEngine;

public static class SaveManager
{
    private const string KeyGold = "save_gold";
    private const string KeyParts = "save_parts"; // CSV of ids
    private const char Sep = ',';

    public static void Save()
    {
        try
        {
            PlayerPrefs.SetInt(KeyGold, Mathf.Max(0, Global.gold));
            string partsCsv = string.Join(Sep, Global.purchasedPartIds ?? new List<string>());
            PlayerPrefs.SetString(KeyParts, partsCsv);
            PlayerPrefs.Save();
            Debug.Log("SaveManager: Auto-saved.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"SaveManager: Save failed: {e.Message}");
        }
    }

    public static void Load()
    {
        try
        {
            if (PlayerPrefs.HasKey(KeyGold))
            {
                Global.gold = Mathf.Max(0, PlayerPrefs.GetInt(KeyGold, 0));
            }
            if (PlayerPrefs.HasKey(KeyParts))
            {
                string csv = PlayerPrefs.GetString(KeyParts, string.Empty);
                Global.purchasedPartIds.Clear();
                if (!string.IsNullOrEmpty(csv))
                {
                    var items = csv.Split(Sep);
                    for (int i = 0; i < items.Length; i++)
                    {
                        var id = items[i]?.Trim();
                        if (!string.IsNullOrEmpty(id)) Global.purchasedPartIds.Add(id);
                    }
                }
            }
            Debug.Log("SaveManager: Loaded.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"SaveManager: Load failed: {e.Message}");
        }
    }

    public static void DeleteSave()
    {
        try
        {
            PlayerPrefs.DeleteKey(KeyGold);
            PlayerPrefs.DeleteKey(KeyParts);
            PlayerPrefs.Save();
            Debug.Log("SaveManager: Deleted save.");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"SaveManager: Delete failed: {e.Message}");
        }
    }
}
