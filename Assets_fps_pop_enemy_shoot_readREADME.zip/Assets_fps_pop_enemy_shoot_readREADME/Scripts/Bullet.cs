using UnityEngine;

// 弾の簡易挙動：指定された方向に移動し、寿命で破棄。
// Enemy との衝突ダメージ処理は Enemy 側で OnTriggerEnter を実装済み。
public class Bullet : MonoBehaviour
{
	private Vector3 moveDir = Vector3.forward;
	private float speed = 20f;
	private float life;
	private float spawnTime;
	[SerializeField] private float defaultLifetime = 5f; // Prefabごとの既定寿命
	[SerializeField] private float fireRate = 8f; // この弾種の発射レート(発/秒)
	[SerializeField, Tooltip("この弾をアンロックする消費スコア")] private int price = 3;
	public float BaseSpeed => speed;
	public float DefaultLifetime => defaultLifetime;
	public float FireRate => fireRate;
	public int Price => price;

	// Player から生成時に設定される想定
	public void Init(Vector3 direction, float speed, float lifeTime)
	{
		this.moveDir = direction.normalized;
		this.speed = Mathf.Max(0f, speed);
		this.life = Mathf.Max(0.01f, lifeTime);
		this.spawnTime = Time.time;
	}

	private void Update()
	{
		transform.position += moveDir * speed * Time.deltaTime;

		if (Time.time - spawnTime >= life)
		{
			Destroy(gameObject);
		}
	}
}
