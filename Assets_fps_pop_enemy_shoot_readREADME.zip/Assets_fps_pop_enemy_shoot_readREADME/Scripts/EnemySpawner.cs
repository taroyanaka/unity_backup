using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    [SerializeField] private GameObject enemyPrefab; // 生成する敵プレハブ
    [SerializeField] private float intervalSeconds = 3f; // 生成間隔（秒）
    [SerializeField] private Transform spawnPoint; // 指定が無ければ自分（this.transform）
    [SerializeField] private bool spawnImmediately = false; // 有効時、開始直後に1体スポーン

    [Header("Debug / Safety Checks")]
    [SerializeField] private bool debugLogs = true; // ログを出す
    [SerializeField] private float overlapCheckRadius = 0f; // > 0 の時、スポーン位置の重なりを確認
    [SerializeField] private LayerMask overlapMask = ~0; // 重なりチェック対象のレイヤー
    [SerializeField] private bool drawGizmos = true; // ギズモ表示
    [SerializeField] private Color gizmoColor = new Color(0.2f, 0.9f, 0.3f, 0.6f);

    [Header("Auto-Fix Spawned (Optional)")]
    [SerializeField] private bool ensurePhysics = false; // 無い場合 Rigidbody/Collider を付与
    [SerializeField] private bool defaultUseGravity = true; // 付与時の UseGravity 初期値
    [SerializeField] private bool addColliderIfMissing = true; // Collider が無ければ追加
    [SerializeField] private bool ensureRendererMaterial = false; // Renderer にマテリアルが無ければ割り当て
    [SerializeField] private Material defaultMaterial; // 割り当てるデフォルトマテリアル（URP/Lit 等を指定）

    private Coroutine _loop;
    private GameObject _lastSpawned;

    private void OnEnable()
    {
        if (_loop == null)
        {
            if (debugLogs)
            {
                Debug.Log($"EnemySpawner: Enable (interval={intervalSeconds:F2}s, prefab={(enemyPrefab ? enemyPrefab.name : "null")})", this);
            }
            if (spawnImmediately)
            {
                TrySpawn();
            }
            _loop = StartCoroutine(SpawnLoop());
        }
    }

    private void OnDisable()
    {
        if (_loop != null)
        {
            StopCoroutine(_loop);
            _loop = null;
            if (debugLogs)
            {
                Debug.Log("EnemySpawner: Disable - loop stopped", this);
            }
        }
    }

    private IEnumerator SpawnLoop()
    {
        // 3秒ごとにスポーン（最初は3秒待ってから）
        var wait = new WaitForSeconds(Mathf.Max(0.01f, intervalSeconds));
        while (enabled)
        {
            yield return wait;
            TrySpawn();
        }
    }

    private void TrySpawn()
    {
        if (enemyPrefab == null)
        {
            Debug.LogWarning("EnemySpawner: enemyPrefab が未設定です", this);
            return;
        }

        Transform p = spawnPoint != null ? spawnPoint : transform;

        if (overlapCheckRadius > 0f)
        {
            var pos = p.position;
            var hits = Physics.OverlapSphere(pos, overlapCheckRadius, overlapMask, QueryTriggerInteraction.Collide);
            if (debugLogs)
            {
                if (hits != null && hits.Length > 0)
                {
                    var first = hits[0];
                    Debug.Log($"EnemySpawner: Spawn point overlaps {hits.Length} colliders. e.g. '{first.name}' (layer={first.gameObject.layer})", this);
                }
                else
                {
                    Debug.Log("EnemySpawner: No overlaps at spawn point", this);
                }
            }
        }

        if (debugLogs)
        {
            Debug.Log($"EnemySpawner: Spawning '{enemyPrefab.name}' at {p.position} rot={p.rotation.eulerAngles}", this);
        }
        _lastSpawned = Instantiate(enemyPrefab, p.position, p.rotation);
        if (_lastSpawned != null)
        {
            if (ensurePhysics)
            {
                EnsurePhysicsComponents(_lastSpawned);
            }
            if (ensureRendererMaterial)
            {
                EnsureRendererMaterials(_lastSpawned);
            }
        }
        if (debugLogs && _lastSpawned != null)
        {
            var r = _lastSpawned.GetComponentInChildren<Renderer>();
            var c = _lastSpawned.GetComponentInChildren<Collider>();
            var rb = _lastSpawned.GetComponentInChildren<Rigidbody>();
            var enemy = _lastSpawned.GetComponentInChildren<Enemy>();
            Debug.Log($"EnemySpawner: Spawned instance activeSelf={_lastSpawned.activeSelf}, activeInHierarchy={_lastSpawned.activeInHierarchy}, layer={_lastSpawned.layer}, hasRenderer={(r!=null)}, hasCollider={(c!=null)}, hasRigidbody={(rb!=null)}, useGravity={(rb? rb.useGravity : false)}, hasEnemyScript={(enemy!=null)} parent={( _lastSpawned.transform.parent ? _lastSpawned.transform.parent.name : "<none>")}", _lastSpawned);
            if (enemy == null)
            {
                Debug.LogWarning("EnemySpawner: Spawned object does not have Enemy.cs attached. Check that 'enemyPrefab' references the correct Enemy prefab.", _lastSpawned);
            }
        }
    }

    // ゲーム再初期化時用リセット（敵は別途破棄済み想定）
    public void ResetSpawner()
    {
        // コルーチン再起動
        if (_loop != null)
        {
            StopCoroutine(_loop);
            _loop = null;
        }
        _lastSpawned = null;
        if (enabled)
        {
            if (spawnImmediately) TrySpawn();
            _loop = StartCoroutine(SpawnLoop());
        }
    }

    private void EnsurePhysicsComponents(GameObject go)
    {
        // Rigidbody
        var rb = go.GetComponentInChildren<Rigidbody>();
        if (rb == null)
        {
            rb = go.AddComponent<Rigidbody>();
            rb.useGravity = defaultUseGravity;
            rb.isKinematic = false;
            if (debugLogs) Debug.Log("EnemySpawner: Added Rigidbody to spawned instance", go);
        }
        else
        {
            rb.useGravity = defaultUseGravity;
        }

        // Collider（最低限いずれか）
        if (addColliderIfMissing)
        {
            var col = go.GetComponentInChildren<Collider>();
            if (col == null)
            {
                // 汎用的に CapsuleCollider を付ける
                var capsule = go.AddComponent<CapsuleCollider>();
                capsule.center = Vector3.zero;
                capsule.height = 2f;
                capsule.radius = 0.5f;
                capsule.direction = 1; // Y
                if (debugLogs) Debug.Log("EnemySpawner: Added CapsuleCollider to spawned instance", go);
            }
        }
    }

    private void EnsureRendererMaterials(GameObject go)
    {
        var renderers = go.GetComponentsInChildren<Renderer>(true);
        if (renderers == null || renderers.Length == 0)
        {
            if (debugLogs) Debug.LogWarning("EnemySpawner: No Renderer found under spawned instance. Cannot assign materials.", go);
            return;
        }
        if (defaultMaterial == null)
        {
            if (debugLogs) Debug.LogWarning("EnemySpawner: defaultMaterial is not assigned. Please set a Material in the spawner.", this);
            return;
        }
        foreach (var r in renderers)
        {
            // マテリアル未設定または空なら割り当て
            var mats = r.sharedMaterials;
            bool empty = mats == null || mats.Length == 0;
            if (empty)
            {
                r.sharedMaterial = defaultMaterial;
            }
            else
            {
                bool anyNull = false;
                for (int i = 0; i < mats.Length; i++) if (mats[i] == null) { anyNull = true; break; }
                if (anyNull)
                {
                    // null のスロットはデフォルトで埋める
                    for (int i = 0; i < mats.Length; i++) if (mats[i] == null) mats[i] = defaultMaterial;
                    r.sharedMaterials = mats;
                }
            }
        }
        if (debugLogs) Debug.Log("EnemySpawner: Ensured materials on spawned instance", go);
    }

#if UNITY_EDITOR
    private void Reset()
    {
        // プレハブ/オブジェクトに付けたときにタグが無ければ 'spawn' を提案
        if (gameObject.tag == "Untagged")
        {
            // タグが存在すれば自動適用（存在しなければEditor上で手動作成が必要）
            if (UnityEditorInternal.InternalEditorUtility.tags != null)
            {
                foreach (var t in UnityEditorInternal.InternalEditorUtility.tags)
                {
                    if (t == "spawn")
                    {
                        gameObject.tag = "spawn";
                        break;
                    }
                }
            }
        }
    }

    private void OnDrawGizmos()
    {
        if (!drawGizmos) return;
        var p = spawnPoint != null ? spawnPoint : transform;
        Gizmos.color = gizmoColor;
        Gizmos.DrawWireSphere(p.position, Mathf.Max(0.025f, overlapCheckRadius));
        // 向きの可視化
        var forward = p.forward * 0.5f;
        Gizmos.DrawLine(p.position, p.position + forward);
    }

    [ContextMenu("Spawn Once (Debug)")]
    private void ContextSpawnOnce()
    {
        TrySpawn();
    }

    [ContextMenu("Ping Last Spawned")]
    private void ContextPingLast()
    {
        #if UNITY_EDITOR
        if (_lastSpawned != null)
        {
            UnityEditor.Selection.activeObject = _lastSpawned;
            UnityEditor.EditorGUIUtility.PingObject(_lastSpawned);
            Debug.Log($"EnemySpawner: Pinged last spawned '{_lastSpawned.name}'", _lastSpawned);
        }
        else
        {
            Debug.Log("EnemySpawner: No last spawned instance to ping", this);
        }
        #endif
    }
#endif
}
