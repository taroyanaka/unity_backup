using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PartDefinition
{
    [Tooltip("一意のID (例: HpBooster1)")] public string id = "";
    [Tooltip("表示名")] public string displayName = "";
    [Tooltip("購入価格(Gold)")] public int goldPrice = 1;
    [Header("Bonuses (加算)")]
    [Tooltip("初期HPへの加算値")] public float hpAdd = 0f;
    [Tooltip("移動速度への加算値 (m/s)")] public float speedAdd = 0f;
}

public class PartsManager : MonoBehaviour
{
    public static PartsManager Instance { get; private set; }

    [Header("Available Parts")]
    [SerializeField, Tooltip("購入可能なパーツ一覧")] private List<PartDefinition> availableParts = new List<PartDefinition>();

    private Dictionary<string, PartDefinition> dict;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        BuildDict();
    }

    private void BuildDict()
    {
        dict = new Dictionary<string, PartDefinition>(StringComparer.Ordinal);
        if (availableParts == null) return;
        for (int i = 0; i < availableParts.Count; i++)
        {
            var p = availableParts[i];
            if (p == null || string.IsNullOrEmpty(p.id)) continue;
            if (!dict.ContainsKey(p.id)) dict.Add(p.id, p);
        }
    }

    public IReadOnlyList<PartDefinition> GetAllParts()
    {
        return availableParts;
    }

    public bool TryPurchase(string id)
    {
        if (string.IsNullOrEmpty(id)) return false;
        if (dict == null) BuildDict();
        if (!dict.TryGetValue(id, out var def)) return false;
        if (Global.purchasedPartIds.Contains(id)) return false; // 既に購入済み
        int price = Mathf.Max(0, def.goldPrice);
        if (Global.gold < price) return false;
        Global.gold -= price;
        Global.purchasedPartIds.Add(id);
        // パーツ購入直後に自動セーブ
        Global.SaveProgress();
        return true;
    }

    public PartDefinition GetDefinition(string id)
    {
        if (string.IsNullOrEmpty(id)) return null;
        if (dict == null) BuildDict();
        dict.TryGetValue(id, out var def);
        return def;
    }

    public static (float hpAdd, float speedAdd) GetTotalBonuses()
    {
        float hp = 0f;
        float spd = 0f;
        if (Instance == null || Instance.dict == null)
        {
            return (0f, 0f);
        }
        var list = Global.purchasedPartIds;
        if (list == null || list.Count == 0) return (0f, 0f);
        for (int i = 0; i < list.Count; i++)
        {
            var id = list[i];
            if (string.IsNullOrEmpty(id)) continue;
            if (!Instance.dict.TryGetValue(id, out var def) || def == null) continue;
            hp += Mathf.Max(0f, def.hpAdd);
            spd += def.speedAdd; // speedAddは負値も許容
        }
        return (hp, spd);
    }
}
