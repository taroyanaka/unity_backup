using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    [Header("UI")]
    [SerializeField, Tooltip("スコア表示に使う TextMeshPro (UI)")]
    private TMP_Text scoreText;

    [SerializeField, Tooltip("表示フォーマット。{0} にスコアが入ります")]
    private string displayFormat = "Score: {0}";

    [SerializeField, Tooltip("プレイヤーHP表示に使う TextMeshPro (UI)")]
    private TMP_Text playerHpText;

    [SerializeField, Tooltip("HP表示フォーマット。{0} にHP(整数)が入ります")]
    private string hpDisplayFormat = "HP: {0}";

    [Header("State")]
    [SerializeField, Tooltip("現在のスコア（開始値）")] private int score = 0;
    private bool gameStopped;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        // スコア表示の自動検出（未割り当ての場合のみ）
        if (scoreText == null)
        {
            var go = GameObject.Find("Score");
            if (go != null)
            {
                scoreText = go.GetComponent<TMP_Text>();
            }
            if (scoreText == null)
            {
                // シーン内から名前で探す（非アクティブも含む）
                var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
                foreach (var t in texts)
                {
                    if (t != null && t.name == "Score") { scoreText = t; break; }
                }
            }
        }

        // プレイヤーHP表示の自動検出（未割り当ての場合のみ）
        if (playerHpText == null)
        {
            var go = GameObject.Find("Player_Hp");
            if (go != null)
            {
                playerHpText = go.GetComponent<TMP_Text>();
            }
            if (playerHpText == null)
            {
                var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
                foreach (var t in texts)
                {
                    if (t != null && t.name == "Player_Hp") { playerHpText = t; break; }
                }
            }
        }

        UpdateUI();
        UpdateHpUI(force:true);
        CheckClearAndStop();
    }

    public void AddScore(int delta)
    {
        if (delta == 0) return;
        score += delta;
        if (score < 0) score = 0;
        UpdateUI();
        CheckClearAndStop();
    }

    public void SetScore(int value)
    {
        score = Mathf.Max(0, value);
        UpdateUI();
        CheckClearAndStop();
    }

    public int GetScore() => score;

    private void UpdateUI()
    {
        if (scoreText != null)
        {
            scoreText.text = string.Format(displayFormat, score);
        }
    }

    private int _cachedHpInt = int.MinValue;
    private void Update()
    {
        // HPの差分更新（毎フレームだが変更時のみ反映）
        UpdateHpUI();
    }

    private void UpdateHpUI(bool force = false)
    {
        if (playerHpText == null) return;
        int hpInt = Mathf.Max(0, Mathf.CeilToInt(Global.player_hp));
        if (!force && hpInt == _cachedHpInt) return;
        _cachedHpInt = hpInt;
        playerHpText.text = string.Format(hpDisplayFormat, hpInt);
    }

    private void CheckClearAndStop()
    {
        if (gameStopped) return;
        // クリアスコアが未設定の場合はスキップ
        int target = Mathf.Max(0, Global.clear_score);
        if (score >= target && target > 0)
        {
            gameStopped = true;
            Time.timeScale = 0f;
            Debug.Log($"Game Clear: score {score} >= target {target}. Time paused.");
        }
    }

    // GameOver後など再スタート用
    public void ResetGameState()
    {
        gameStopped = false;
        score = 0;
        UpdateUI();
        UpdateHpUI(force:true);
    }
}
