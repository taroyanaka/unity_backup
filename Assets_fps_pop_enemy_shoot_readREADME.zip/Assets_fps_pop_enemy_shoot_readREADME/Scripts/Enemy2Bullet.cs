using UnityEngine;

// Enemy2 が発射する弾の挙動：
// - 進行方向の移動は既存 Bullet.cs に委譲（本スクリプトはダメージ付与のみ）
// - Player に当たると Global.enemy2_bullet_atk 分のダメージを与えて破棄
public class Enemy2Bullet : MonoBehaviour
{
    [SerializeField, Tooltip("衝突時に破壊するか")]
    private bool destroyOnHit = true;

    private void OnTriggerEnter(Collider other)
    {
        if (other != null && other.CompareTag("Player"))
        {
            Global.player_hp -= Mathf.Max(0f, Global.enemy2_bullet_atk);
            if (destroyOnHit)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        var other = collision != null ? collision.gameObject : null;
        if (other != null && other.CompareTag("Player"))
        {
            Global.player_hp -= Mathf.Max(0f, Global.enemy2_bullet_atk);
            if (destroyOnHit)
            {
                Destroy(gameObject);
            }
        }
    }
}
