using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StartBuyMenuManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("HUD直下の Start_Menu パネル(GameObject)")] private GameObject startMenuPanel;
    [SerializeField, Tooltip("Buy_Menu の TextMeshPro (UI)")] private TMP_Text buyMenuText;
    [SerializeField, Tooltip("Startボタン")] private Button startButton;
    [SerializeField, Tooltip("Buyボタン")] private Button buyButton;
    [SerializeField, Tooltip("Backボタン (Buy_Menu用)")] private Button backButton;
    [SerializeField, Tooltip("セーブ削除ボタン (Start_Menu用)")] private Button deleteSaveButton;
    [SerializeField, Tooltip("PlayTimeManager (未設定なら自動検出)")] private PlayTimeManager playTimeManager;
    [SerializeField, Tooltip("PartsManager (未設定なら自動検出)")] private PartsManager partsManager;
    [SerializeField, Tooltip("Playerプレハブ (再スタート時に生成)")] private GameObject playerPrefab;
    [SerializeField, Tooltip("Playerスポーン位置 (未設定なら Start_Menu の位置 or このオブジェクト位置)")] private Transform playerSpawnPoint;

    private bool inBuyMenu = false;
    private List<string> visibleIds = new List<string>();
    private PauseMenuManager pauseMenuManager;

    private void Awake()
    {
        // 自動参照
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null) playTimeManager = FindAnyObjectByType<PlayTimeManager>();
        }
        if (partsManager == null)
        {
            partsManager = FindFirstObjectByType<PartsManager>();
            if (partsManager == null) partsManager = FindAnyObjectByType<PartsManager>();
        }
        if (startMenuPanel == null)
        {
            var go = GameObject.Find("Start_Menu");
            if (go != null) startMenuPanel = go;
        }
        if (buyMenuText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Buy_Menu") { buyMenuText = t; break; }
            }
        }
        // ボタンは手動アサイン推奨。未設定時は名前で探すフォールバック
        if (startButton == null)
        {
            var btnGo = GameObject.Find("Start_Button");
            if (btnGo != null) startButton = btnGo.GetComponent<Button>();
        }
        if (buyButton == null)
        {
            var btnGo = GameObject.Find("Buy_Button");
            if (btnGo != null) buyButton = btnGo.GetComponent<Button>();
        }
        if (backButton == null)
        {
            var btnGo = GameObject.Find("Back_Button");
            if (btnGo != null) backButton = btnGo.GetComponent<Button>();
        }
        if (deleteSaveButton == null)
        {
            var btnGo = GameObject.Find("Delete_Save_Button");
            if (btnGo != null) deleteSaveButton = btnGo.GetComponent<Button>();
        }

        if (startButton != null) startButton.onClick.AddListener(OnStartClicked);
        if (buyButton != null) buyButton.onClick.AddListener(OnBuyClicked);
        if (backButton != null) backButton.onClick.AddListener(OnBackClicked);
        if (deleteSaveButton != null) deleteSaveButton.onClick.AddListener(OnDeleteSaveClicked);

        pauseMenuManager = FindFirstObjectByType<PauseMenuManager>();
        if (pauseMenuManager == null) pauseMenuManager = FindAnyObjectByType<PauseMenuManager>();

        // セーブ読み込み
        Global.LoadProgress();
        // 初期状態：スタートメニューを表示、ゲーム停止（表示時に自動セーブ）
        ShowStartMenu();
    }

    private void OnDestroy()
    {
        if (startButton != null) startButton.onClick.RemoveListener(OnStartClicked);
        if (buyButton != null) buyButton.onClick.RemoveListener(OnBuyClicked);
        if (backButton != null) backButton.onClick.RemoveListener(OnBackClicked);
        if (deleteSaveButton != null) deleteSaveButton.onClick.RemoveListener(OnDeleteSaveClicked);
    }

    private void Update()
    {
        if (!inBuyMenu) return;
        // 1〜9キーで購入試行
        for (int i = 0; i < 9; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
                TryPurchaseIndex(i);
                break;
            }
        }
    }

    private void ShowStartMenu()
    {
        inBuyMenu = false;
        if (startMenuPanel != null) startMenuPanel.SetActive(true);
        if (buyMenuText != null) buyMenuText.gameObject.SetActive(false);
        Time.timeScale = 0f;
        if (playTimeManager != null) playTimeManager.PauseTimer();
        if (pauseMenuManager != null) pauseMenuManager.enabled = false; // ESCポーズは無効化
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        // Start_Menu表示時に自動セーブ
        Global.SaveProgress();
    }

    private void ShowBuyMenu()
    {
        inBuyMenu = true;
        if (startMenuPanel != null) startMenuPanel.SetActive(false);
        if (buyMenuText != null)
        {
            buyMenuText.gameObject.SetActive(true);
            RebuildBuyListText();
        }
        Time.timeScale = 0f;
        if (playTimeManager != null) playTimeManager.PauseTimer();
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void StartGame()
    {
        inBuyMenu = false;
        if (startMenuPanel != null) startMenuPanel.SetActive(false);
        if (buyMenuText != null) buyMenuText.gameObject.SetActive(false);
        Time.timeScale = 1f;
        if (playTimeManager != null) playTimeManager.ResumeTimer();
        if (pauseMenuManager != null) pauseMenuManager.enabled = true; // ゲーム開始後はESC有効
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // 既存Playerが居ない場合は生成
        var existingPlayer = FindFirstObjectByType<Player>();
        if (existingPlayer == null && playerPrefab != null)
        {
            Vector3 pos = playerSpawnPoint ? playerSpawnPoint.position : (startMenuPanel ? startMenuPanel.transform.position : transform.position);
            Quaternion rot = playerSpawnPoint ? playerSpawnPoint.rotation : Quaternion.identity;
            var newPlayerGO = Instantiate(playerPrefab, pos, rot);
            var pl = newPlayerGO.GetComponent<Player>();
            if (pl != null && Camera.main != null)
            {
                pl.AttachCamera(Camera.main.transform);
            }
        }
    }

    private void OnStartClicked()
    {
        StartGame();
    }

    private void OnBuyClicked()
    {
        ShowBuyMenu();
    }

    private void OnBackClicked()
    {
        if (inBuyMenu)
        {
            ShowStartMenu();
        }
    }

    // 外部(GameOver等)からスタートメニューへ戻すための公開API
    public void ResetToStartMenu()
    {
        ShowStartMenu();
        // Playerが残っている場合は削除（再スタート時に再生成）
        var existingPlayer = FindFirstObjectByType<Player>();
        if (existingPlayer != null)
        {
            Destroy(existingPlayer.gameObject);
        }
    }

    private void OnDeleteSaveClicked()
    {
        Global.DeleteSave();
        Global.gold = 0;
        Global.purchasedPartIds.Clear();
        // 表示更新
        if (inBuyMenu)
        {
            RebuildBuyListText();
        }
        else
        {
            // Start_Menu上なら何もしなくてもOK
        }
        // セーブファイル削除後、空状態を自動セーブして整合
        Global.SaveProgress();
    }

    private void RebuildBuyListText()
    {
        if (buyMenuText == null) return;
        visibleIds.Clear();
        var sb = new StringBuilder();
        sb.AppendLine($"Buy Menu  Gold: {Global.gold}");
        sb.AppendLine("===========================");

        if (partsManager == null)
        {
            sb.AppendLine("No Parts");
        }
        else
        {
            var parts = partsManager.GetAllParts();
            int idx = 1;
            foreach (var p in parts)
            {
                if (p == null || string.IsNullOrEmpty(p.id)) continue;
                bool owned = Global.purchasedPartIds.Contains(p.id);
                bool affordable = Global.gold >= Mathf.Max(0, p.goldPrice);
                string color = (owned || !affordable) ? "#888888" : "#FFFFFF"; // 灰 or 白
                string ownedTag = owned ? " (Owned)" : "";
                sb.Append("<color=").Append(color).Append(">");
                sb.Append(idx).Append(". ").Append(p.displayName);
                sb.Append("  HP+").Append(p.hpAdd.ToString("0.##"));
                sb.Append("  SPD+").Append(p.speedAdd.ToString("0.##"));
                sb.Append("  Price:").Append(Mathf.Max(0, p.goldPrice));
                sb.Append(ownedTag);
                sb.AppendLine("</color>");
                visibleIds.Add(p.id);
                idx++;
            }
            if (visibleIds.Count == 0)
            {
                sb.AppendLine("No Parts");
            }
        }

        sb.AppendLine("\n[1-9] で購入 / Backボタンで戻る");

        // 購入済みパーツ一覧セクション
        sb.AppendLine("\nOwned Parts");
        sb.AppendLine("------------");
        var ownedList = Global.purchasedPartIds;
        if (ownedList == null || ownedList.Count == 0)
        {
            sb.AppendLine("(none)");
        }
        else
        {
            int oidx = 1;
            foreach (var oid in ownedList)
            {
                if (string.IsNullOrEmpty(oid)) continue;
                string name = oid;
                float hp = 0f, spd = 0f;
                if (partsManager != null)
                {
                    var def = partsManager.GetDefinition(oid);
                    if (def != null)
                    {
                        name = string.IsNullOrEmpty(def.displayName) ? def.id : def.displayName;
                        hp = def.hpAdd; spd = def.speedAdd;
                    }
                }
                sb.Append(oidx).Append(". ").Append(name)
                  .Append("  HP+").Append(hp.ToString("0.##"))
                  .Append("  SPD+").Append(spd.ToString("0.##"))
                  .AppendLine();
                oidx++;
            }
        }

        // 総合計ボーナス
        var totals = PartsManager.GetTotalBonuses();
        sb.AppendLine("\nTotal Bonus");
        sb.AppendLine("-----------");
        sb.Append("HP+").Append(totals.hpAdd.ToString("0.##"))
          .Append("  SPD+").Append(totals.speedAdd.ToString("0.##"))
          .AppendLine();

        buyMenuText.text = sb.ToString();
    }

    private void TryPurchaseIndex(int idx)
    {
        if (partsManager == null) return;
        if (idx < 0 || idx >= visibleIds.Count) return;
        string id = visibleIds[idx];
        if (string.IsNullOrEmpty(id)) return;
        if (Global.purchasedPartIds.Contains(id)) { RebuildBuyListText(); return; }
        bool ok = partsManager.TryPurchase(id);
        // 再描画（Gold/色更新）
        RebuildBuyListText();
        Debug.Log(ok ? $"Purchased part: {id}" : $"Purchase failed: {id}");
    }
}
