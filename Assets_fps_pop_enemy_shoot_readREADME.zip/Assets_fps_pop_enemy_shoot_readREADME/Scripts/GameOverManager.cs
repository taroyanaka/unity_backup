using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Text;

public class GameOverManager : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField, Tooltip("HUD直下のGame_Over TextMeshPro")] private TMP_Text gameOverText;
    [SerializeField, Tooltip("Menuボタン (GameOver画面用)")] private Button menuButton;
    [SerializeField, Tooltip("PlayTimeManager参照")] private PlayTimeManager playTimeManager;
    [SerializeField, Tooltip("ScoreManager参照")] private ScoreManager scoreManager;
    [SerializeField, Tooltip("StartBuyMenuManager参照")] private StartBuyMenuManager startBuyMenuManager;
    [SerializeField, Tooltip("Player参照")] private Player player;
    [SerializeField, Tooltip("PauseMenuManager参照 (GameOver時に無効化)")] private PauseMenuManager pauseMenuManager;

    private bool shown;

    private void Awake()
    {
        if (gameOverText == null)
        {
            var texts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in texts)
            {
                if (t != null && t.name == "Game_Over") { gameOverText = t; break; }
            }
        }
        if (playTimeManager == null) playTimeManager = FindFirstObjectByType<PlayTimeManager>();
        if (playTimeManager == null) playTimeManager = FindAnyObjectByType<PlayTimeManager>();
        if (scoreManager == null) scoreManager = ScoreManager.Instance ?? FindFirstObjectByType<ScoreManager>();
        if (startBuyMenuManager == null) startBuyMenuManager = FindFirstObjectByType<StartBuyMenuManager>();
        if (startBuyMenuManager == null) startBuyMenuManager = FindAnyObjectByType<StartBuyMenuManager>();
        if (player == null) player = FindFirstObjectByType<Player>();
        if (player == null) player = FindAnyObjectByType<Player>();
        if (pauseMenuManager == null) pauseMenuManager = FindFirstObjectByType<PauseMenuManager>();
        if (pauseMenuManager == null) pauseMenuManager = FindAnyObjectByType<PauseMenuManager>();

        if (menuButton == null)
        {
            var btnGo = GameObject.Find("GameOver_Menu_Button");
            if (btnGo != null) menuButton = btnGo.GetComponent<Button>();
        }
        if (menuButton != null) menuButton.onClick.AddListener(OnMenuClicked);

        if (gameOverText != null) gameOverText.gameObject.SetActive(false);
        shown = false;
    }

    private void OnDestroy()
    {
        if (menuButton != null) menuButton.onClick.RemoveListener(OnMenuClicked);
    }

    private void Update()
    {
        if (shown) return;
        if (Global.player_hp <= 0f)
        {
            ShowGameOver();
        }
    }

    private void ShowGameOver()
    {
        shown = true;
        // ポーズ
        Time.timeScale = 0f;
        if (playTimeManager != null) playTimeManager.PauseTimer();
        if (pauseMenuManager != null) pauseMenuManager.enabled = false;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // 表示テキスト構築
        if (gameOverText != null)
        {
            int gold = Global.gold;
            int score = scoreManager != null ? scoreManager.GetScore() : 0;
            int seconds = playTimeManager != null ? playTimeManager.ElapsedSeconds : 0;
            int mm = seconds / 60; int ss = seconds % 60;
            var sb = new StringBuilder();
            sb.AppendLine("GAME OVER");
            sb.AppendLine($"Gold: {gold}");
            sb.AppendLine($"Score: {score}");
            sb.AppendLine($"PlayTime: {mm:00}:{ss:00}");
            sb.AppendLine("Menuボタンで再スタート");
            gameOverText.text = sb.ToString();
            gameOverText.gameObject.SetActive(true);
        }

        // Game_Over表示時に自動セーブ
        Global.SaveProgress();
    }

    private void OnMenuClicked()
    {
        if (!shown) return;
        // Gold・購入パーツは保持（パーツ永続仕様）
        // スコア/PlayTime/Streak リセット
        if (scoreManager != null) scoreManager.ResetGameState();
        if (playTimeManager != null) playTimeManager.ResetTimer();
        var streak = Streak.Instance ?? FindFirstObjectByType<Streak>();
        if (streak != null) streak.ResetStreak();
        // プレイヤー削除（再スタート時に新規スポーン）
        if (player != null)
        {
            Destroy(player.gameObject);
            player = null;
        }
        // 敵/弾など破棄
        CleanupSceneObjects();
        // スポーナー状態リセット（出現カウンタ等初期化）
        ResetSpawners();
        // GameOver非表示
        if (gameOverText != null) gameOverText.gameObject.SetActive(false);
        shown = false;
        // Startメニューへ復帰
        if (startBuyMenuManager != null) startBuyMenuManager.ResetToStartMenu();
    }

    private void CleanupSceneObjects()
    {
        // 最低限: 敵、弾、コインなどを全破棄
        DestroyAllOfType<Enemy>();
        DestroyAllOfType<Enemy2>();
        DestroyAllOfType<Enemy3>();
        DestroyAllOfType<Boss>();
        DestroyAllOfType<Bullet>();
        DestroyAllOfType<Bullet2>();
        DestroyAllOfType<Bullet3>();
        DestroyAllOfType<Coin>();
    }

    private void ResetSpawners()
    {
        var enemySpawners = FindObjectsByType<EnemySpawner>(FindObjectsSortMode.None);
        foreach (var es in enemySpawners) if (es != null) es.ResetSpawner();
        var bossSpawners = FindObjectsByType<BossSpawner>(FindObjectsSortMode.None);
        foreach (var bs in bossSpawners) if (bs != null) bs.ResetSpawner();
    }

    private void DestroyAllOfType<T>() where T : Component
    {
        var arr = FindObjectsByType<T>(FindObjectsSortMode.None);
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] != null) Destroy(arr[i].gameObject);
        }
    }
}
