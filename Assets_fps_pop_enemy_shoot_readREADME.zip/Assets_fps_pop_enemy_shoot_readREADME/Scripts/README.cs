// =============================================
// README.cs (仕様概要: Scripts配下クラス一覧)
// 本ファイルは参照用のコメントのみを含み、ゲームロジックは持ちません。
// 各 .cs ファイルの目的を 1 行で記述しています。
// =============================================
// Enemy.cs            : 基本的な敵キャラ。プレイヤーへ接近・被弾処理・スコア加算を担当。
// Enemy2.cs           : 徘徊しながら一定間隔で弾を発射する敵の派生。Global の enemy2 設定を参照。
// Enemy3.cs           : 追加バリエーション敵（詳細挙動はクラス内部参照）。
// EnemySpawner.cs     : 敵のスポーン管理。一定条件/間隔で Enemy 系を生成する制御。
// Boss.cs             : Enemy2 ベースの強化版ボス。高HP/高スコア、弾射撃とうろつき行動。
// BossSpawner.cs      : PlayTime 経過に応じて Boss を最大出現数まで生成し、出現時にタイマーを停止可能。
// Coin.cs             : 一定時間で自動消滅し、消滅時に Global.gold を加算するコイン。敵撃破時のドロップ用。
// Player.cs           : プレイヤー操作・HP・弾スロット管理などコア挙動を担当。
// Bullet.cs           : 基本弾挙動。初期化パラメータに応じて移動し寿命で破棄。
// Bullet2.cs          : 追加弾種その1（威力や特性差異はクラス内実装を参照）。
// Bullet3.cs          : 追加弾種その2（さらなる特性差異を持つ弾）。
// Enemy2Bullet.cs     : Enemy2/Boss 生成弾のダメージ処理・プレイヤー当たり判定。
// PowerUpManager.cs   : スコア到達でゲームを一時停止し、弾種パワーアップ購入/スキップを提示。
// PlayTimeManager.cs  : ゲームプレイ時間(mm:ss)を計測。PowerUpやBoss出現時の一時停止に対応。
// PauseMenuManager.cs : ESCキーでポーズメニュー開閉。Time.timeScaleとPlayTimeManagerで一時停止/再開を制御。
// Parts.cs            : パーツ定義/購入/合算管理。Goldで購入し、開始時にPlayerへHP/速度ボーナスを適用。
// ScoreManager.cs     : スコアの取得・加算・消費管理。Singleton で全体参照を提供。
// Streak.cs           : 連続撃破（キルストリーク）管理。連続数によるボーナス等の登録処理。
// Global.cs           : ゲーム全体のバランス調整用静的パラメータ集 (HP/ATK/スロット上限等)。
// StartBuyMenuManager.cs: Start_Menu/Buy_Menu の遷移管理。Start/Buy/Backボタン、購入リスト表示・購入処理。
// GameOverManager.cs  : HP<=0検知しGame_Over表示。Gold/Score/PlayTime表示とMenuボタンでGold以外再初期化。
// =============================================
// メンテナンス指針:
// - 新規スクリプト追加時は同様に 1 行説明をここへ追記。
// - 詳細仕様変更で目的が変わった場合は行の更新を行う。
// - 実行時依存は持たないためビルドへの影響なし。
// =============================================

// =============================================
// 推奨シーン構成（オブジェクト/命名規約）
// - 自動検出に用いているオブジェクト名を中心に記載。
// - 可能な限り以下の命名に合わせるとスクリプトの参照設定が省略可能。
// =============================================
// Root
// - Main Camera
// - Directional Light
// - Spawners/
//     - EnemySpawner (複数可)
//     - BossSpawner  (任意)
// - Systems/
//     - ScoreManager
//     - PlayTimeManager
//     - Streak
//     - PowerUpManager
//     - PauseMenuManager
//     - StartBuyMenuManager
//     - GameOverManager
// - PlayerSpawnPoint (任意: Start時に Player をここへ生成)
// - HUD (Canvas)
//     - Score              [TMP_Text]
//     - Player_Hp          [TMP_Text]
//     - PlayTime           [TMP_Text]
//     - Streak             [TMP_Text]
//     - Power_Up           [TMP_Text]
//     - Menu               [GameObject/TMP等]  ← ポーズメニューの表示用（PauseMenuManagerのmenuPanel）
//         - Resume_Button  [Button]            ← InspectorでResumeを割当（任意名称、例）
//     - Game_Over          [TMP_Text]          ← ゲームオーバー時の表示（GameOverManagerが制御）
//     - Start_Menu         [Panel/GameObject]  ← タイトル/開始メニュー
//         - Start_Button       [Button]
//         - Buy_Button         [Button]
//         - Delete_Save_Button [Button]        ← セーブ削除
//     - Buy_Menu           [TMP_Text]          ← パーツ購入リスト表示用テキスト
//         - Back_Button        [Button]
//
// 補足（自動検出に使う主な名前）:
// - ScoreManager:    "Score", "Player_Hp"
// - PlayTimeManager: "PlayTime"
// - Streak:          "Streak"
// - PowerUpManager:  "Power_Up"
// - PauseMenuManager: menuPanelに "Menu"（未設定時に名前で検索）
// - StartBuyMenuManager:
//     Start_Menu, Buy_Menu, Start_Button, Buy_Button, Back_Button, Delete_Save_Button
// - GameOverManager: "Game_Over", GameOver_Menu_Button（任意: Inspector割当 or 名称で探索）
//
// 備考:
// - StartBuyMenuManager に Player プレハブ/スポーン位置を割り当てると、Start押下で Player を生成。
// - 命名が異なる場合は Inspector から明示アサインすることで利用可能。
// =============================================
