using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(PlayerInput))]
public class Player : MonoBehaviour
{
	[SerializeField] private float speed = 5f;
	[SerializeField] private Transform orientation;
	[SerializeField] private InputActionAsset inputActions;

	[Header("Health")]
	[SerializeField] private float initialPlayerHp = 10f;

	[Header("View / Look")]
	[SerializeField] private Transform cameraPivot;
	[SerializeField] private float mouseSensitivity = 0.15f;
	[SerializeField] private float minPitch = -85f;
	[SerializeField] private float maxPitch = 85f;
	[SerializeField] private bool lockCursor = true;

	[Header("Shooting")]
	[SerializeField] private GameObject[] bulletPrefabs;
	[SerializeField] private Transform muzzle;
	[SerializeField] private bool freezeTilt = true;
	[SerializeField, Tooltip("複数弾の左右間隔。0で重なって発射")]
	private float multiSpawnSpacing = 0.3f;
	[SerializeField, Tooltip("発射ごとにログ出力する")]
	private bool debugFire = false;

	[Header("Respawn (Ungrounded)")]
	[SerializeField] private float ungroundedRespawnDelay = 2f;
	[SerializeField] private float groundCheckExtraDistance = 0.2f;
	[SerializeField] private LayerMask groundMask = ~0;
	[SerializeField] private bool useSphereCastForGround = true;
	[SerializeField] private float groundCheckRadius = 0.25f;
	[SerializeField] private bool debugGroundCheck = false;

	private Vector2 move;
	private PlayerInput playerInput;
	private float[] multiNextFireTimes;
	private bool prevMouseHeld;
	private Vector2 lookDelta;
	private float yaw;
	private float pitch;
	private Vector3 initialPosition;
	private Quaternion initialYawRotation;
	private float initialPitch;
	private float ungroundedTimer;
	private float originalSpeed; // リスタート用に初期速度保持

	private void Awake()
	{
		playerInput = GetComponent<PlayerInput>();
		if (playerInput != null)
		{
			if (playerInput.actions == null && inputActions != null) playerInput.actions = inputActions;
			if (string.IsNullOrEmpty(playerInput.defaultActionMap)) playerInput.defaultActionMap = "Player";
			playerInput.notificationBehavior = PlayerNotifications.SendMessages;
		}
		if (cameraPivot == null && Camera.main != null) cameraPivot = Camera.main.transform;
		if (freezeTilt)
		{
			var rb = GetComponent<Rigidbody>();
			if (rb != null) rb.constraints |= RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
		}
		originalSpeed = speed;
		Global.player_hp = initialPlayerHp;
		if (bulletPrefabs != null && bulletPrefabs.Length > Global.player_max_bullet_slots)
		{
			System.Array.Resize(ref bulletPrefabs, Global.player_max_bullet_slots);
		}
		multiNextFireTimes = (bulletPrefabs != null && bulletPrefabs.Length > 0) ? new float[bulletPrefabs.Length] : new float[0];
	}

	private void OnEnable()
	{
		if (lockCursor)
		{
			Cursor.lockState = CursorLockMode.Locked;
			Cursor.visible = false;
		}
		var yawTarget = orientation ? orientation : transform;
		yaw = yawTarget.rotation.eulerAngles.y;
		if (cameraPivot != null)
		{
			float rawX = cameraPivot.localEulerAngles.x;
			rawX = (rawX > 180f) ? rawX - 360f : rawX;
			pitch = Mathf.Clamp(rawX, minPitch, maxPitch);
		}
	}

	private void Start()
	{
		initialPosition = transform.position;
		initialYawRotation = (orientation ? orientation.rotation : transform.rotation);
		initialPitch = pitch;

		// 購入済みパーツの効果を初期値に反映
		var bonuses = PartsManager.GetTotalBonuses();
		if (bonuses.speedAdd != 0f)
		{
			speed = Mathf.Max(0f, speed + bonuses.speedAdd);
		}
		if (bonuses.hpAdd != 0f)
		{
			Global.player_hp = Mathf.Max(0f, initialPlayerHp + bonuses.hpAdd);
		}
	}

	// GameOver後の初期化 (Gold以外リセット想定。パーツは別でクリアされる前提)
	public void ResetForNewGame()
	{
		// HPリセット
		Global.player_hp = initialPlayerHp;
		// 速度リセット（パーツで増加していた分を除去）
		speed = originalSpeed;
		// 位置・姿勢リセット
		Respawn();
		// 発射状態リセット
		prevMouseHeld = false;
		lookDelta = Vector2.zero;
		for (int i = 0; i < multiNextFireTimes.Length; i++) multiNextFireTimes[i] = 0f;
	}

	public bool TryAddBulletPrefab(GameObject prefab)
	{
		if (prefab == null) return false;
		if (bulletPrefabs == null) bulletPrefabs = new GameObject[0];
		// 既に同一参照がある場合は追加しない
		for (int i = 0; i < bulletPrefabs.Length; i++) if (bulletPrefabs[i] == prefab) return false;
		if (bulletPrefabs.Length >= Global.player_max_bullet_slots) return false;
		int oldLen = bulletPrefabs.Length;
		System.Array.Resize(ref bulletPrefabs, oldLen + 1);
		bulletPrefabs[oldLen] = prefab;
		// 発射タイマー配列も拡張
		var newTimes = new float[bulletPrefabs.Length];
		for (int i = 0; i < multiNextFireTimes.Length && i < newTimes.Length; i++) newTimes[i] = multiNextFireTimes[i];
		multiNextFireTimes = newTimes;
		return true;
	}

	private void OnDisable()
	{
		if (lockCursor)
		{
			Cursor.lockState = CursorLockMode.None;
			Cursor.visible = true;
		}
	}

	public void OnMove(InputValue value) => move = value.Get<Vector2>();
	public void OnLook(InputValue value) => lookDelta += value.Get<Vector2>();
    

	private void Update()
	{
		// Look
		Vector2 delta = lookDelta;
		if (delta.sqrMagnitude < 0.0001f)
		{
			if (Mouse.current != null) delta += Mouse.current.delta.ReadValue();
			else
			{
				delta.x += Input.GetAxisRaw("Mouse X") * 10f;
				delta.y += Input.GetAxisRaw("Mouse Y") * 10f;
			}
		}
		yaw += delta.x * mouseSensitivity;
		pitch = Mathf.Clamp(pitch - delta.y * mouseSensitivity, minPitch, maxPitch);
		var yawTarget2 = orientation ? orientation : transform;
		yawTarget2.rotation = Quaternion.Euler(0f, yaw, 0f);
		if (cameraPivot != null)
		{
			var local = cameraPivot.localEulerAngles;
			float x = pitch;
			if (x < 0f) x += 360f;
			cameraPivot.localEulerAngles = new Vector3(x, local.y, local.z);
		}
		lookDelta = Vector2.zero;

		// Move
		var basis = orientation ? orientation : transform;
		Vector3 fwd = basis.forward; fwd.y = 0f; fwd.Normalize();
		Vector3 right = basis.right; right.y = 0f; right.Normalize();
		Vector3 dir = right * move.x + fwd * move.y;
		if (dir.sqrMagnitude > 1f) dir.Normalize();
		transform.position += dir * speed * Time.deltaTime;

		// Ground / Respawn
		bool grounded = IsGrounded();
		if (grounded) ungroundedTimer = 0f;
		else
		{
			ungroundedTimer += Time.deltaTime;
			if (ungroundedTimer >= ungroundedRespawnDelay)
			{
				Respawn();
				return;
			}
		}

		// Shooting (multi only)
		bool mouseHeld = Mouse.current != null ? Mouse.current.leftButton.isPressed : Input.GetMouseButton(0);
		bool mouseDown = mouseHeld && !prevMouseHeld;
		if (bulletPrefabs != null && bulletPrefabs.Length > 0)
		{
			if (mouseDown)
			{
				for (int i = 0; i < bulletPrefabs.Length; i++) FireBulletMulti(i);
			}
			else if (mouseHeld)
			{
				for (int i = 0; i < bulletPrefabs.Length; i++)
				{
					float rate = GetFireRate(bulletPrefabs[i]);
					float interval = 1f / Mathf.Max(0.01f, rate);
					if (Time.time >= multiNextFireTimes[i])
					{
						FireBulletMulti(i);
						multiNextFireTimes[i] = Time.time + interval;
					}
				}
			}
		}
		prevMouseHeld = mouseHeld;
	}

	private void FireBulletMulti(int index)
	{
		if (bulletPrefabs == null || index < 0 || index >= bulletPrefabs.Length) return;
		var prefab = bulletPrefabs[index];
		if (prefab == null) return;
		var basis = orientation ? orientation : transform;
		int total = bulletPrefabs.Length;
		float half = (total - 1) * 0.5f;
		Vector3 offset = (total > 1) ? basis.right * (index - half) * multiSpawnSpacing : Vector3.zero;
		Vector3 spawnPos = (muzzle ? muzzle.position : basis.position + basis.forward * 0.5f) + offset;
		Quaternion spawnRot = Quaternion.LookRotation(basis.forward, Vector3.up);
		var go = Instantiate(prefab, spawnPos, spawnRot);
		if (debugFire) Debug.Log($"Fire idx={index} prefab={prefab.name} pos={spawnPos}");
		var bulletCols = go.GetComponentsInChildren<Collider>();
		var playerCols = GetComponentsInChildren<Collider>();
		for (int i = 0; i < bulletCols.Length; i++)
		{
			for (int j = 0; j < playerCols.Length; j++)
			{
				if (bulletCols[i] && playerCols[j]) Physics.IgnoreCollision(bulletCols[i], playerCols[j], true);
			}
		}
		// Bullet / Bullet2 / Bullet3 両対応
		Bullet bullet = go.GetComponent<Bullet>();
		Bullet2 bullet2 = null;
		Bullet3 bullet3 = null;
		float speedLocal;
		float lifeLocal;
		if (bullet == null)
		{
			bullet2 = go.GetComponent<Bullet2>();
			if (bullet2 == null)
			{
				bullet3 = go.GetComponent<Bullet3>();
			}
		}
		if (bullet != null)
		{
			speedLocal = bullet.BaseSpeed;
			lifeLocal = bullet.DefaultLifetime;
			bullet.Init(basis.forward, speedLocal, lifeLocal);
		}
		else if (bullet2 != null)
		{
			speedLocal = bullet2.BaseSpeed;
			lifeLocal = bullet2.DefaultLifetime;
			bullet2.Init(basis.forward, speedLocal, lifeLocal);
		}
		else if (bullet3 != null)
		{
			speedLocal = bullet3.BaseSpeed;
			lifeLocal = bullet3.DefaultLifetime;
			bullet3.Init(basis.forward, speedLocal, lifeLocal);
		}
		else
		{
			bullet = go.AddComponent<Bullet>();
			speedLocal = bullet.BaseSpeed;
			lifeLocal = bullet.DefaultLifetime;
			bullet.Init(basis.forward, speedLocal, lifeLocal);
		}
		var rb = go.GetComponent<Rigidbody>();
		if (rb != null) rb.AddForce(basis.forward * speedLocal, ForceMode.VelocityChange);
		float rate = GetFireRate(prefab);
		float interval = 1f / Mathf.Max(0.01f, rate);
		multiNextFireTimes[index] = Time.time + interval;
	}

	private float GetFireRate(GameObject prefab)
	{
		if (prefab == null) return 8f; // フォールバック
		var b = prefab.GetComponent<Bullet>();
		if (b != null) return Mathf.Max(0.01f, b.FireRate);
		var b2 = prefab.GetComponent<Bullet2>();
		if (b2 != null) return Mathf.Max(0.01f, b2.FireRate);
		var b3 = prefab.GetComponent<Bullet3>();
		if (b3 != null) return Mathf.Max(0.01f, b3.FireRate);
		return 8f; // 何も持っていなければ既定値
	}

	private bool IsGrounded()
	{
		var cols = GetComponentsInChildren<Collider>();
		Bounds? optBounds = null;
		for (int i = 0; i < cols.Length; i++)
		{
			var c = cols[i];
			if (c == null || !c.enabled || c.isTrigger) continue;
			if (optBounds == null) optBounds = c.bounds; else { var b = optBounds.Value; b.Encapsulate(c.bounds); optBounds = b; }
		}
		Bounds bnds = optBounds ?? new Bounds(transform.position + Vector3.up * 1f, new Vector3(0.5f, 2f, 0.5f));
		Vector3 origin = bnds.center;
		float rayLength = bnds.extents.y + Mathf.Max(0f, groundCheckExtraDistance);
		bool hit = useSphereCastForGround
			? Physics.SphereCast(origin, Mathf.Max(0.01f, groundCheckRadius), Vector3.down, out _, rayLength, groundMask, QueryTriggerInteraction.Ignore)
			: Physics.Raycast(origin, Vector3.down, rayLength, groundMask, QueryTriggerInteraction.Ignore);
		if (debugGroundCheck)
		{
			Color col = hit ? Color.green : Color.red;
			Debug.DrawLine(origin, origin + Vector3.down * rayLength, col, 0f, false);
			if (useSphereCastForGround)
			{
				Debug.DrawLine(origin + Vector3.right * groundCheckRadius, origin + Vector3.down * rayLength + Vector3.right * groundCheckRadius, col, 0f, false);
				Debug.DrawLine(origin - Vector3.right * groundCheckRadius, origin + Vector3.down * rayLength - Vector3.right * groundCheckRadius, col, 0f, false);
			}
		}
		return hit;
	}

	private void OnDrawGizmosSelected()
	{
		if (!debugGroundCheck) return;
		var cols = GetComponentsInChildren<Collider>();
		Bounds? optBounds = null;
		for (int i = 0; i < cols.Length; i++)
		{
			var c = cols[i];
			if (c == null || !c.enabled || c.isTrigger) continue;
			if (optBounds == null) optBounds = c.bounds; else { var b = optBounds.Value; b.Encapsulate(c.bounds); optBounds = b; }
		}
		Bounds bnds = optBounds ?? new Bounds(transform.position + Vector3.up * 1f, new Vector3(0.5f, 2f, 0.5f));
		Vector3 origin = bnds.center;
		float rayLength = bnds.extents.y + Mathf.Max(0f, groundCheckExtraDistance);
		Gizmos.color = Color.yellow;
		Gizmos.DrawLine(origin, origin + Vector3.down * rayLength);
		if (useSphereCastForGround) Gizmos.DrawWireSphere(origin + Vector3.down * (rayLength * 0.5f), groundCheckRadius);
	}

	private void Respawn()
	{
		transform.position = initialPosition;
		yaw = initialYawRotation.eulerAngles.y;
		var target = orientation ? orientation : transform;
		target.rotation = Quaternion.Euler(0f, yaw, 0f);
		pitch = initialPitch;
		if (cameraPivot != null)
		{
			var local = cameraPivot.localEulerAngles;
			float x = pitch;
			if (x < 0f) x += 360f;
			cameraPivot.localEulerAngles = new Vector3(x, local.y, local.z);
		}
		var rb = GetComponent<Rigidbody>();
		if (rb != null)
		{
			rb.linearVelocity = Vector3.zero;
			rb.angularVelocity = Vector3.zero;
		}
		ungroundedTimer = 0f;
	}

	// カメラ再アタッチ用公開API（再スポーン時等）
	public void AttachCamera(Transform camTransform)
	{
		if (camTransform == null) return;
		cameraPivot = camTransform;
		// 現在のピッチを再設定
		float rawX = cameraPivot.localEulerAngles.x;
		rawX = (rawX > 180f) ? rawX - 360f : rawX;
		pitch = Mathf.Clamp(rawX, minPitch, maxPitch);
	}
}

