using UnityEngine;
using Random = UnityEngine.Random;

public class Enemy2 : MonoBehaviour
{
    [Header("Stats")]
    [SerializeField, Tooltip("この敵の現在HP（AwakeでGlobalから初期化）")]
    private float enemy2_hp;

    [SerializeField, Tooltip("この敵の弾の攻撃力（参考。実際の適用はEnemy2Bullet側でGlobalを参照）")]
    private float enemy2_bullet_atk;

    [Header("Shooting")]
    [SerializeField, Tooltip("発射する弾プレハブ（既存のBullet.prefabを推奨）")]
    private GameObject bulletPrefab;

    [SerializeField, Tooltip("発射位置（未指定なら自分の位置）")]
    private Transform muzzle;

    [SerializeField, Tooltip("発射間隔（秒）")]
    private float fireInterval = 1.5f;

    [SerializeField, Tooltip("弾速 (m/s) : 'ゆっくり' を想定し小さめに")]
    private float bulletSpeed = 8f;

    [SerializeField, Tooltip("弾の寿命 (秒)")]
    private float bulletLifetime = 6f;

    [Header("Wander")]
    [SerializeField, Tooltip("うろつき移動の速度 (m/s)")]
    private float moveSpeed = 2.2f;

    [SerializeField, Tooltip("スポーン地点を中心としたうろつき半径 (m)")]
    private float wanderRadius = 10f;

    [SerializeField, Tooltip("目標地点に到達とみなす閾値 (m)")]
    private float waypointTolerance = 0.4f;

    [SerializeField, Tooltip("新しい目標地点を選ぶ間隔(秒)の最小/最大")] 
    private Vector2 wanderPickIntervalRange = new Vector2(2f, 4f);

    [SerializeField, Tooltip("地面の当たり判定用レイヤー(未指定ならDefault)")]
    private LayerMask groundMask = Physics.DefaultRaycastLayers;

    [Header("Debug")] 
    [SerializeField, Tooltip("ターゲットが見つからない場合のログ")] private bool debugLogs = false;

    private Transform player;
    private float nextFireTime;
    private bool isDead;

    [Header("Coin Drop")] 
    [SerializeField, Tooltip("ドロップするCoinプレハブ")] private GameObject coinPrefab;
    [SerializeField, Tooltip("撃破時に落とすコイン数")] private int coinDropCount = 2;
    [SerializeField, Tooltip("コイン寿命(秒)")] private float coinLifeSeconds = 5f;
    [SerializeField, Tooltip("1コインのゴールド価値")] private int coinGoldValue = 1;

    [SerializeField, Tooltip("この敵を倒した際に取得するスコア値")]
    private int scoreValue = 2;

    // Wander 内部状態
    private Vector3 spawnPos;
    private Vector3 currentTarget;
    private float nextPickTime;
    private bool hasTarget;

    private void Awake()
    {
        // Global から初期化
        enemy2_hp = Global.enemy2_hp;
        enemy2_bullet_atk = Global.enemy2_bullet_atk;

        // Player 参照キャッシュ
        var pObj = GameObject.FindWithTag("Player");
        if (pObj != null) player = pObj.transform;

        nextFireTime = Time.time + fireInterval; // 少し待ってから発射開始

        // Wander 初期化
        spawnPos = transform.position;
        ScheduleNextPick(0.2f);
    }

    private void Update()
    {
        if (isDead) return;

        // Player 再取得（シーン遷移やリスポーン対策）
        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null) player = pObj.transform;
        }

        // うろつき移動
        HandleWander();

        // 一定間隔で射撃
        if (Time.time >= nextFireTime)
        {
            TryShootAtPlayer();
            nextFireTime = Time.time + Mathf.Max(0.05f, fireInterval);
        }
    }

    private void HandleWander()
    {
        // 目標地点の更新
        if (!hasTarget || Time.time >= nextPickTime || ReachedCurrentTarget())
        {
            PickNewWanderTarget();
        }

        // 目標地点へ移動（XZ 平面）
        if (hasTarget)
        {
            var pos = transform.position;
            Vector3 to = currentTarget - pos;
            to.y = 0f;
            float dist = to.magnitude;
            if (dist > 0.001f)
            {
                Vector3 step = to.normalized * moveSpeed * Time.deltaTime;
                if (step.magnitude > dist) step = to.normalized * dist; // 行き過ぎ防止
                Vector3 newPos = new Vector3(pos.x + step.x, pos.y, pos.z + step.z);

                // 足元の地面に合わせて高さを補正（可能なら）
                if (Physics.Raycast(newPos + Vector3.up * 3f, Vector3.down, out RaycastHit hit, 10f, groundMask))
                {
                    newPos.y = hit.point.y;
                }

                transform.position = newPos;
            }
        }
    }

    private bool ReachedCurrentTarget()
    {
        Vector3 a = transform.position; a.y = 0f;
        Vector3 b = currentTarget; b.y = 0f;
        return Vector3.Distance(a, b) <= waypointTolerance;
    }

    private void PickNewWanderTarget()
    {
        // スポーン地点中心の円内でランダム
        Vector2 rnd = Random.insideUnitCircle * wanderRadius;
        Vector3 candidate = new Vector3(spawnPos.x + rnd.x, transform.position.y, spawnPos.z + rnd.y);

        // 地面高さ取得（可能なら）
        if (Physics.Raycast(candidate + Vector3.up * 10f, Vector3.down, out RaycastHit hit, 30f, groundMask))
        {
            candidate.y = hit.point.y;
        }

        currentTarget = candidate;
        hasTarget = true;
        // 次のピック時刻
        float delay = Random.Range(wanderPickIntervalRange.x, wanderPickIntervalRange.y);
        ScheduleNextPick(delay);
    }

    private void ScheduleNextPick(float delay)
    {
        nextPickTime = Time.time + Mathf.Max(0.05f, delay);
    }

    private void TryShootAtPlayer()
    {
        if (bulletPrefab == null)
        {
            if (debugLogs) Debug.LogWarning("Enemy2: bulletPrefab が未設定です", this);
            return;
        }
        if (player == null)
        {
            if (debugLogs) Debug.Log("Enemy2: Player が見つからないため射撃できません", this);
            return;
        }

        Vector3 origin = muzzle ? muzzle.position : transform.position;
        Vector3 dir = (player.position - origin);
        dir.y = 0f; // 2D平面狙い（上下は無視）。必要なら外す
        if (dir.sqrMagnitude <= 0.0001f) dir = transform.forward;
        dir.Normalize();

        Quaternion rot = Quaternion.LookRotation(dir, Vector3.up);
        var go = Instantiate(bulletPrefab, origin, rot);

        // 弾にタグ "enemy_bullet" を付けて、味方(Enemy)側の被弾判定と区別
        go.tag = "enemy_bullet";

        // 自身のColliderと弾のColliderの衝突を無視
        var bulletCols = go.GetComponentsInChildren<Collider>();
        var selfCols = GetComponentsInChildren<Collider>();
        for (int i = 0; i < bulletCols.Length; i++)
        {
            for (int j = 0; j < selfCols.Length; j++)
            {
                if (bulletCols[i] && selfCols[j]) Physics.IgnoreCollision(bulletCols[i], selfCols[j], true);
            }
        }

        // 移動処理は Bullet.cs に委譲（付いてなければ動的に付与）
        var mover = go.GetComponent<Bullet>();
        if (mover == null) mover = go.AddComponent<Bullet>();
        mover.Init(dir, bulletSpeed, bulletLifetime);

        // プレイヤーに当たった際のダメージ処理
        var dmg = go.GetComponent<Enemy2Bullet>();
        if (dmg == null) dmg = go.AddComponent<Enemy2Bullet>();
    }

    public void TakeDamage(float damage)
    {
        if (isDead) return;
        enemy2_hp -= damage;
        if (enemy2_hp <= 0f)
        {
            isDead = true;
            if (global::Streak.Instance != null)
            {
                global::Streak.Instance.RegisterKill(scoreValue);
            }
            else if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.AddScore(scoreValue);
            }
            DropCoins();
            Destroy(gameObject);
        }
    }

    // プレイヤーの弾（tag:"bullet"）でダメージ
    private void OnTriggerEnter(Collider other)
    {
        if (other != null && other.CompareTag("bullet"))
        {
            TakeDamage(Global.bullet_atk);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        var other = collision.gameObject;
        if (other != null && other.CompareTag("bullet"))
        {
            TakeDamage(Global.bullet_atk);
        }
    }

    private void DropCoins()
    {
        if (coinPrefab == null || coinDropCount <= 0) return;
        Coin.SpawnBurst(coinPrefab, transform.position, coinDropCount, coinLifeSeconds, coinGoldValue);
    }
}
