using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PauseMenuManager : MonoBehaviour
{
    [Header("References")]
    [SerializeField, Tooltip("HUD直下のMenuのGameObject (TextMeshProを含むオブジェクト)")] 
    private GameObject menuPanel;
    
    [SerializeField, Tooltip("Resume ボタン")] 
    private Button resumeButton;
    
    [SerializeField, Tooltip("PlayTimeManager参照 (未設定なら自動検索)")] 
    private PlayTimeManager playTimeManager;

    private bool isPaused = false;

    private void Awake()
    {
        // PlayTimeManagerの自動検索
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null)
            {
                playTimeManager = FindAnyObjectByType<PlayTimeManager>();
            }
        }

        // Menuパネルの自動検索（未設定の場合）
        if (menuPanel == null)
        {
            var allTexts = Resources.FindObjectsOfTypeAll<TMP_Text>();
            foreach (var t in allTexts)
            {
                if (t != null && t.name == "Menu")
                {
                    menuPanel = t.gameObject;
                    break;
                }
            }
        }

        // Resumeボタンのイベント設定
        if (resumeButton != null)
        {
            resumeButton.onClick.AddListener(ResumeGame);
        }

        // 初期状態：メニューを非表示
        if (menuPanel != null)
        {
            menuPanel.SetActive(false);
        }
    }

    private void Update()
    {
        // ESCキーの検出
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                ResumeGame();
            }
            else
            {
                PauseGame();
            }
        }
    }

    private void PauseGame()
    {
        isPaused = true;
        
        // メニューを表示
        if (menuPanel != null)
        {
            menuPanel.SetActive(true);
        }
        
        // ゲームを一時停止
        Time.timeScale = 0f;
        
        // PlayTimeを一時停止
        if (playTimeManager != null)
        {
            playTimeManager.PauseTimer();
        }
        
        // カーソルを表示
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        
        Debug.Log("Game Paused");
    }

    public void ResumeGame()
    {
        isPaused = false;
        
        // メニューを非表示
        if (menuPanel != null)
        {
            menuPanel.SetActive(false);
        }
        
        // ゲームを再開
        Time.timeScale = 1f;
        
        // PlayTimeを再開
        if (playTimeManager != null)
        {
            playTimeManager.ResumeTimer();
        }
        
        // カーソルをロック
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        Debug.Log("Game Resumed");
    }

    private void OnDestroy()
    {
        // ボタンイベントのクリーンアップ
        if (resumeButton != null)
        {
            resumeButton.onClick.RemoveListener(ResumeGame);
        }
    }
}
