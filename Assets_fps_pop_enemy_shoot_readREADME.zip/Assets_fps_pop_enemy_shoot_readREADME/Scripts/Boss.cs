using UnityEngine;
using Random = UnityEngine.Random;

// Enemy2.cs と同様の挙動を Boss 用に複製
public class Boss : MonoBehaviour
{
    [Header("Stats")]
    [SerializeField, Tooltip("Boss 現在HP（Awakeで初期化）")] private float boss_hp = 30f; // デフォルト HP を高めに
    [SerializeField, Tooltip("Boss 弾の攻撃力（参考値）")] private float boss_bullet_atk = 3f;

    [Header("Shooting")]
    [SerializeField, Tooltip("発射する弾プレハブ（Bullet 推奨）")] private GameObject bulletPrefab;
    [SerializeField, Tooltip("発射位置（未指定なら自分の位置）")] private Transform muzzle;
    [SerializeField, Tooltip("発射間隔（秒）")] private float fireInterval = 1.2f;
    [SerializeField, Tooltip("弾速 (m/s)")] private float bulletSpeed = 10f;
    [SerializeField, Tooltip("弾の寿命 (秒)")] private float bulletLifetime = 8f;

    [Header("Wander")]
    [SerializeField, Tooltip("うろつき移動の速度 (m/s)")] private float moveSpeed = 2.5f;
    [SerializeField, Tooltip("スポーン地点を中心としたうろつき半径 (m)")] private float wanderRadius = 12f;
    [SerializeField, Tooltip("目標地点到達判定の閾値 (m)")] private float waypointTolerance = 0.5f;
    [SerializeField, Tooltip("新しい目標地点を選ぶ間隔(秒) 最小/最大")] private Vector2 wanderPickIntervalRange = new Vector2(2f, 4f);
    [SerializeField, Tooltip("地面レイヤー(未指定ならDefault)")] private LayerMask groundMask = Physics.DefaultRaycastLayers;

    [Header("Debug")] [SerializeField, Tooltip("ターゲット未取得ログ出力")] private bool debugLogs = false;

    private Transform player;
    private float nextFireTime;
    private bool isDead;

    [SerializeField, Tooltip("撃破時付与スコア")] private int scoreValue = 20;

    [Header("Coin Drop")] 
    [SerializeField, Tooltip("ドロップするCoinプレハブ")] private GameObject coinPrefab;
    [SerializeField, Tooltip("撃破時に落とすコイン数")] private int coinDropCount = 5;
    [SerializeField, Tooltip("コイン寿命(秒)")] private float coinLifeSeconds = 6f;
    [SerializeField, Tooltip("1コインのゴールド価値")] private int coinGoldValue = 1;

    private Vector3 spawnPos;
    private Vector3 currentTarget;
    private float nextPickTime;
    private bool hasTarget;

    private void Awake()
    {
        // Enemy2 と同様に Global の既存値で初期化したい場合は以下を利用（専用値未定のため仮に利用）
        boss_hp = Mathf.Max(boss_hp, Global.enemy2_hp * 5f); // Inspector > Serialized 優先。未設定なら Enemy2 の 5倍程度。
        boss_bullet_atk = Mathf.Max(boss_bullet_atk, Global.enemy2_bullet_atk * 3f);

        var pObj = GameObject.FindWithTag("Player");
        if (pObj != null) player = pObj.transform;

        nextFireTime = Time.time + fireInterval;
        spawnPos = transform.position;
        ScheduleNextPick(0.2f);
    }

    private void Update()
    {
        if (isDead) return;

        if (player == null)
        {
            var pObj = GameObject.FindWithTag("Player");
            if (pObj != null) player = pObj.transform;
        }

        HandleWander();

        if (Time.time >= nextFireTime)
        {
            TryShootAtPlayer();
            nextFireTime = Time.time + Mathf.Max(0.05f, fireInterval);
        }
    }

    private void HandleWander()
    {
        if (!hasTarget || Time.time >= nextPickTime || ReachedCurrentTarget())
        {
            PickNewWanderTarget();
        }

        if (hasTarget)
        {
            var pos = transform.position;
            Vector3 to = currentTarget - pos; to.y = 0f;
            float dist = to.magnitude;
            if (dist > 0.001f)
            {
                Vector3 step = to.normalized * moveSpeed * Time.deltaTime;
                if (step.magnitude > dist) step = to.normalized * dist;
                Vector3 newPos = new Vector3(pos.x + step.x, pos.y, pos.z + step.z);
                if (Physics.Raycast(newPos + Vector3.up * 3f, Vector3.down, out RaycastHit hit, 10f, groundMask))
                {
                    newPos.y = hit.point.y;
                }
                transform.position = newPos;
            }
        }
    }

    private bool ReachedCurrentTarget()
    {
        Vector3 a = transform.position; a.y = 0f;
        Vector3 b = currentTarget; b.y = 0f;
        return Vector3.Distance(a, b) <= waypointTolerance;
    }

    private void PickNewWanderTarget()
    {
        Vector2 rnd = Random.insideUnitCircle * wanderRadius;
        Vector3 candidate = new Vector3(spawnPos.x + rnd.x, transform.position.y, spawnPos.z + rnd.y);
        if (Physics.Raycast(candidate + Vector3.up * 10f, Vector3.down, out RaycastHit hit, 30f, groundMask))
        {
            candidate.y = hit.point.y;
        }
        currentTarget = candidate;
        hasTarget = true;
        float delay = Random.Range(wanderPickIntervalRange.x, wanderPickIntervalRange.y);
        ScheduleNextPick(delay);
    }

    private void ScheduleNextPick(float delay)
    {
        nextPickTime = Time.time + Mathf.Max(0.05f, delay);
    }

    private void TryShootAtPlayer()
    {
        if (bulletPrefab == null)
        {
            if (debugLogs) Debug.LogWarning("Boss: bulletPrefab 未設定", this);
            return;
        }
        if (player == null)
        {
            if (debugLogs) Debug.Log("Boss: Player 未取得", this);
            return;
        }

        Vector3 origin = muzzle ? muzzle.position : transform.position;
        Vector3 dir = (player.position - origin); dir.y = 0f;
        if (dir.sqrMagnitude <= 0.0001f) dir = transform.forward; dir.Normalize();
        Quaternion rot = Quaternion.LookRotation(dir, Vector3.up);
        var go = Instantiate(bulletPrefab, origin, rot);
        go.tag = "enemy_bullet";

        var bulletCols = go.GetComponentsInChildren<Collider>();
        var selfCols = GetComponentsInChildren<Collider>();
        for (int i = 0; i < bulletCols.Length; i++)
        {
            for (int j = 0; j < selfCols.Length; j++)
            {
                if (bulletCols[i] && selfCols[j]) Physics.IgnoreCollision(bulletCols[i], selfCols[j], true);
            }
        }

        var mover = go.GetComponent<Bullet>();
        if (mover == null) mover = go.AddComponent<Bullet>();
        mover.Init(dir, bulletSpeed, bulletLifetime);

        var dmg = go.GetComponent<Enemy2Bullet>();
        if (dmg == null) dmg = go.AddComponent<Enemy2Bullet>();
    }

    public void TakeDamage(float damage)
    {
        if (isDead) return;
        boss_hp -= damage;
        if (boss_hp <= 0f)
        {
            isDead = true;
            if (global::Streak.Instance != null)
            {
                global::Streak.Instance.RegisterKill(scoreValue);
            }
            else if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.AddScore(scoreValue);
            }
            DropCoins();
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other != null && other.CompareTag("bullet"))
        {
            TakeDamage(Global.bullet_atk);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        var other = collision.gameObject;
        if (other != null && other.CompareTag("bullet"))
        {
            TakeDamage(Global.bullet_atk);
        }
    }

    private void DropCoins()
    {
        if (coinPrefab == null || coinDropCount <= 0) return;
        Coin.SpawnBurst(coinPrefab, transform.position, coinDropCount, coinLifeSeconds, coinGoldValue, 1.0f);
    }
}
