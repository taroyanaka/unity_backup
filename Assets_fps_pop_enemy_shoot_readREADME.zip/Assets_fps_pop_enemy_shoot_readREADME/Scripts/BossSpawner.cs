using UnityEngine;

public class BossSpawner : MonoBehaviour
{
    [Header("Config")]
    [SerializeField, Tooltip("出現させる Boss プレハブ (Boss.cs を付与)")] private GameObject bossPrefab;
    [SerializeField, Tooltip("Boss を生成する位置 (未指定なら自分の位置)")] private Transform spawnPoint;
    [SerializeField, Tooltip("最初の Boss 出現秒数 (mm:ss の合計秒)")] private int firstSpawnSeconds = 120;
    [SerializeField, Tooltip("2体目以降の出現間隔(秒)。0以下なら1体のみ出現") ] private int spawnIntervalSeconds = 90;
    [SerializeField, Tooltip("最大出現数")] private int maxSpawnCount = 1;
    [SerializeField, Tooltip("Boss 出現時にタイマー停止するか（各出現ごと）")] private bool pausePlayTimeOnSpawn = true;

    [Header("Refs")] 
    [SerializeField, Tooltip("PlayTimeManager 参照 (未設定なら自動検索)")] private PlayTimeManager playTimeManager;

    private int spawnedCount;
    private int nextSpawnTime; // 次にスポーンする目標秒数

    private void Awake()
    {
        if (playTimeManager == null)
        {
            playTimeManager = FindFirstObjectByType<PlayTimeManager>();
            if (playTimeManager == null)
            {
                playTimeManager = FindAnyObjectByType<PlayTimeManager>();
            }
        }
        spawnedCount = 0;
        nextSpawnTime = firstSpawnSeconds;
    }

    private void Update()
    {
        if (playTimeManager == null) return;
        if (spawnedCount >= maxSpawnCount) return; // 目標数に達したので停止

        if (playTimeManager.ElapsedSeconds >= nextSpawnTime)
        {
            SpawnBoss();
        }
    }

    private void SpawnBoss()
    {
        if (bossPrefab == null)
        {
            Debug.LogWarning("BossSpawner: bossPrefab 未設定です", this);
            return;
        }
        Vector3 pos = spawnPoint ? spawnPoint.position : transform.position;
        Quaternion rot = spawnPoint ? spawnPoint.rotation : Quaternion.identity;
        Instantiate(bossPrefab, pos, rot);
        spawnedCount++;
        if (pausePlayTimeOnSpawn && playTimeManager != null)
        {
            playTimeManager.PauseTimer();
        }
        Debug.Log($"BossSpawner: Boss #{spawnedCount} spawned at playtime={playTimeManager.ElapsedSeconds}s");

        // 次回スポーン時間計算
        if (spawnedCount < maxSpawnCount && spawnIntervalSeconds > 0)
        {
            nextSpawnTime += spawnIntervalSeconds;
        }
        else
        {
            // 追加スポーンなしにするため極端に大きな値へ (安全策)
            nextSpawnTime = int.MaxValue;
        }
    }

    // ゲーム再初期化時用リセット
    public void ResetSpawner()
    {
        spawnedCount = 0;
        nextSpawnTime = firstSpawnSeconds;
    }
}
