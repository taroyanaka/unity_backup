using System.Collections;
using UnityEngine;

public class Coin : MonoBehaviour
{
    [Header("Coin Settings")]
    [SerializeField, Tooltip("このコインが加算するゴールド量")] private int goldValue = 1;
    [SerializeField, Tooltip("コインが存在する寿命(秒)。経過後に自動で消滅しゴールド加算")] private float lifeSeconds = 5f;
    [SerializeField, Tooltip("消滅直前に点滅するか")] private bool blinkBeforeExpire = true;
    [SerializeField, Tooltip("点滅の長さ(秒)")] private float blinkDuration = 0.8f;
    [SerializeField, Tooltip("初速の散らばり強度 (Rigidbody がある場合のみ)")] private float scatterImpulse = 1.5f;

    private Renderer[] cachedRenderers;

    private void OnEnable()
    {
        cachedRenderers = GetComponentsInChildren<Renderer>(true);
        // 生成直後の軽い散らし
        var rb = GetComponent<Rigidbody>();
        if (rb != null && scatterImpulse > 0f)
        {
            Vector3 rnd = new Vector3(Random.Range(-1f, 1f), Random.Range(0.2f, 1.2f), Random.Range(-1f, 1f)).normalized;
            rb.AddForce(rnd * scatterImpulse, ForceMode.Impulse);
        }
        StartCoroutine(LifeRoutine());
    }

    private IEnumerator LifeRoutine()
    {
        float endTime = Time.time + Mathf.Max(0.01f, lifeSeconds);
        bool startedBlink = false;
        while (Time.time < endTime)
        {
            if (blinkBeforeExpire && !startedBlink)
            {
                float remain = endTime - Time.time;
                if (remain <= blinkDuration)
                {
                    startedBlink = true;
                }
            }

            if (startedBlink)
            {
                float phase = Mathf.PingPong(Time.time * 12f, 1f);
                bool visible = phase > 0.5f;
                SetVisible(visible);
            }

            yield return null;
        }

        // 消滅時にゴールド加算
        if (goldValue > 0)
        {
            Global.gold += goldValue;
        }

        Destroy(gameObject);
    }

    private void SetVisible(bool visible)
    {
        if (cachedRenderers == null) return;
        for (int i = 0; i < cachedRenderers.Length; i++)
        {
            if (cachedRenderers[i] != null) cachedRenderers[i].enabled = visible;
        }
    }

    public void Init(int value, float lifeSecondsOverride)
    {
        goldValue = Mathf.Max(0, value);
        lifeSeconds = Mathf.Max(0.01f, lifeSecondsOverride);
    }

    public static void SpawnBurst(GameObject coinPrefab, Vector3 center, int count, float lifeSeconds = 5f, int value = 1, float radius = 0.6f)
    {
        if (coinPrefab == null || count <= 0) return;
        for (int i = 0; i < count; i++)
        {
            Vector2 r = Random.insideUnitCircle * radius;
            Vector3 pos = new Vector3(center.x + r.x, center.y + 0.2f, center.z + r.y);
            var go = Object.Instantiate(coinPrefab, pos, Quaternion.identity);
            var coin = go.GetComponent<Coin>();
            if (coin != null)
            {
                coin.Init(value, lifeSeconds);
            }
        }
    }
}
