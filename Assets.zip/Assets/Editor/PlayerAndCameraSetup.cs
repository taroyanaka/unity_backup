

#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;


public class PlayerAndCameraSetup
{
    [MenuItem("Tools/Create Player With Camera")]
    public static void CreatePlayerWithCamera()
    {
        // プレイヤー作成
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Cube);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = new Vector3(0, 1, 0);
        if (player.GetComponent<Rigidbody>() == null)
            player.AddComponent<Rigidbody>();
        // WASD移動・ジャンプ用スクリプトを自動追加
        if (player.GetComponent<SimplePlayerMover>() == null)
        {
            player.AddComponent<SimplePlayerMover>();
        }
        // カメラ作成
        // GameObject camObj = new GameObject("PlayerCamera");
        // Camera cam = camObj.AddComponent<Camera>();
        // camObj.transform.SetParent(player.transform);
        // camObj.transform.localPosition = new Vector3(0, 2, -5);
        // camObj.transform.localRotation = Quaternion.Euler(10, 0, 0);
        // cam.tag = "MainCamera";

        // Debug.Log("プレイヤーとカメラを作成しました");
    }
}

#endif
