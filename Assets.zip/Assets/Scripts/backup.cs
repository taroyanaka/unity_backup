        // if (bulletPrefab != null && bulletSpawnPoint != null)
        // {
        //     //log
        //     Debug.Log("はっしゃー");
        //     GameObject bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        //     //bulletにタグ設定、collider設定してistriggerをtrueに、マテリアルで色設定、rigidbody追加,
        //     bullet.layer = gameObject.layer;
        //     //bulletタグを設定
        //     bullet.tag = "Bullet";
        //     //bulletにColliderがあればisTriggerをtrueに、colliderがなければSphereColliderを追加してisTriggerをtrueに
        //     var col = bullet.GetComponent<Collider>();
        //     if (col == null) col = bullet.AddComponent<SphereCollider>();
        //     col.isTrigger = true;
        //     // 子オブジェクトのRendererにマテリアル設定（青色）
        //     var renderer = bullet.GetComponentInChildren<Renderer>();
        //     if (renderer != null)
        //     {
        //         var mat = new Material(Shader.Find("Standard"));
        //         mat.color = Color.blue;
        //         renderer.material = mat;
        //     }
        //     //rbを取得
        //     Rigidbody rb = bullet.GetComponent<Rigidbody>();
        //     if (rb != null)
        //     {
        //         rb.useGravity = true;
        //         rb.AddForce(bulletSpawnPoint.forward * 20f, ForceMode.Impulse);
        //     }
        // }