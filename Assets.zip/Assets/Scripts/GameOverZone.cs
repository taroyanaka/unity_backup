using UnityEngine;

public class GameOverZone : MonoBehaviour
{
    private Vector3 spawnPoint = new Vector3(0, 1, 0);

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            //log
            Debug.Log("98");
            // gameoverzoneに触れたらHPを1減らすenemyの処理を呼び出す
            GameManager gm = FindFirstObjectByType<GameManager>();
            if (gm != null)
            {
                //log
                Debug.Log("76GameOverZone reducing player HP");
                // gamehud.DamagePlayer(1)を呼び出す
                GameHUD hud = FindFirstObjectByType<GameHUD>();
                if (hud != null)
                {
                    //log
                    Debug.Log("32GameOverZone updating HUD HP display");
                    hud.DamagePlayer(1);
                }
            }
        }
    }
}
