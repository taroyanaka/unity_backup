using UnityEngine;

public class GameClearZone : MonoBehaviour
{
	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Player"))
		{
			GameManager gm = FindFirstObjectByType<GameManager>();
			if (gm != null)
			{
				// ゲームクリア処理を呼び出す
				var gameClearMethod = gm.GetType().GetMethod("GameClear", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
				if (gameClearMethod != null)
				{
					gameClearMethod.Invoke(gm, null);
				}
			}
		}
	}
}