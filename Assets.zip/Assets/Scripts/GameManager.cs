using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class GameManager : MonoBehaviour
{
    // 3秒ごとにポップ用タイマー
    private float popTimer = 0f;
    //CLEAR_SCORE
    private const int CLEAR_SCORE = 30;
    private bool isGameOver = false;

    [Range(0f, 1f)]
    public float capsuleRespawnProbability = 0.2f; // カプセル出現確率（0〜1）
    // 弾発射レート（秒）
    private float fireRate = 1.0f;
    private float fireTimer = 0f;

    // PowerUp効果を適用
    public void SetFireRateMultiplier(float multiplier)
    {
        fireRate = fireRate / multiplier;
        // 必要に応じて発射間隔や弾発射処理に反映する
    }
    // コレクタブルのリスポーン回数設定
    public int maxRespawnCount = 30;
    private int currentRespawnCount = 0;
    public float Zone_South = 0f;

    public static GameManager Instance { get; private set; }

    public float ElapsedTime { get; private set; }

    public GameObject collectiblePrefab;
    public GameObject enemyPrefab;
    public GameObject bulletPrefab; // Bulletプレハブ参照
    public int numberOfCollectiblesToSpawn = 3;

    private List<GameObject> activeCollectibles = new List<GameObject>();
    private Collider groundCollider;

// southゾーン判定用フラグ
    private bool isPlayerInSouthZone = false;
// 外部から呼び出す用
    public void SetPlayerInSouthZone(bool inZone)
    {
        isPlayerInSouthZone = inZone;
    }


    private void Awake()
    {
        //log
        Debug.Log("0");
        if (Instance == null)
        {
            Debug.Log("1");
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Debug.Log("1_1");
            Destroy(gameObject);
        }

        // Load the collectible prefab from the Resources folder
        if (collectiblePrefab == null)
        {
            Debug.Log("2_1");
            collectiblePrefab = Resources.Load<GameObject>("Collectible1");
            if (collectiblePrefab == null)
            {
                Debug.Log("2_2");
                Debug.LogError("Failed to load Collectible1 prefab from Resources folder.");
            }
        }
    }

    void Start()
    {
        Debug.Log("3");
        // Find the ground to determine spawn area
        GameObject ground = GameObject.FindWithTag("Ground");
        if (ground != null)
        {
            Debug.Log("3_1");
            groundCollider = ground.GetComponent<Collider>();
        }
        else
        {
            Debug.Log("3_2");
            Debug.LogError("Ground object with tag 'Ground' not found. Collectibles cannot be spawned.");
            return;
        }

        // Find initial collectibles in the scene
        activeCollectibles = GameObject.FindGameObjectsWithTag("Collectible").ToList();

        // If no collectibles are in the scene, spawn them.
        if (activeCollectibles.Count == 0)
        {
            Debug.Log("3_3");
            SpawnCollectibles();
            SpawnEnemiesFromNorth();
        }
        else
        {
        Debug.Log("30_30");
            SpawnEnemiesFromNorth();
        }
    }

    void SpawnEnemiesFromNorth()
    {
        //enemyPrefabがZone_Northの上に3秒ごとに1体スポーン
        if (enemyPrefab == null)
        {
            enemyPrefab = Resources.Load<GameObject>("Enemy");
            if (enemyPrefab == null)
            {
                Debug.LogError("Failed to load Enemy prefab from Resources folder.");
                return;
            }
        }

        GameObject zoneNorth = GameObject.Find("Zone_North");
        if (zoneNorth == null)
        {
            Debug.LogError("Zone_North object not found.");
            return;
        }

        // スポーン位置をZone_Northの上に設定
        Vector3 spawnPosition = zoneNorth.transform.position + new Vector3(0, 1.0f, 0);

        // エネミーを1体スポーン
        GameObject enemy = Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
        enemy.tag = "Enemy";

    }

    void Update()
    {
        // 3秒ごとにコレクタブルとエネミーを新しくポップ
        popTimer += Time.deltaTime;
        if (popTimer >= 3f)
        {
            popTimer = 0f;
            SpawnCollectibles();
            SpawnEnemiesFromNorth();
        }
        
        //Debug.Log("4");
        ElapsedTime += Time.deltaTime;


        //1秒につきzone_Southのzのtransform値が1増加
        GameObject zoneSouth = GameObject.Find("Zone_South");
        if (zoneSouth != null)
        {
            //transformのscalez値を取得
            Vector3 scale = zoneSouth.transform.localScale;
            scale.z += Time.deltaTime * 1f; // 1秒につき1増加
            zoneSouth.transform.localScale = scale;
            Zone_South = scale.z;
        }

        // 左クリック押してる間でBullet発射（発射間隔制御）
        if (!isGameOver)
        {
            fireTimer += Time.deltaTime;
            if (Input.GetMouseButton(0))
            {
                if (fireTimer >= fireRate)
                {
                    //Debug.Log("左クリックが押されています！");
                    FireBullet();
                    fireTimer = 0f;
                }
            }
        }
    }
    // ←ここでUpdateメソッドを正しく閉じる

    void FireBullet()
    {
        if (bulletPrefab == null)
        {
            //Debug.Log("5");
            bulletPrefab = Resources.Load<GameObject>("Bullet");
            if (bulletPrefab == null)
            {
                //Debug.Log("5_1");
                Debug.LogError("Failed to load Bullet prefab from Resources folder.");
                return;
            }
        }

        // カメラの前方にBulletを発射
        Camera cam = Camera.main;
        if (cam == null)
        {
            //Debug.Log("5_2");
            Debug.LogError("Main Camera not found.");
            return;
        }
        Vector3 spawnPos = cam.transform.position + cam.transform.forward * 2.0f;
        GameObject bullet = Instantiate(bulletPrefab, spawnPos, cam.transform.rotation);
    bullet.tag = "Bullet"; // 追加
        // Rigidbodyがあれば前方に力を加える
        Rigidbody rb = bullet.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.AddForce(cam.transform.forward * 500f); // 適宜調整
        }
        // 10秒後に弾を消滅させる
        Destroy(bullet, 3f);
    }

    public void OnCollectibleCollected(GameObject collectible)
    {
        if (collectible != null && activeCollectibles.Contains(collectible))
        {
            activeCollectibles.Remove(collectible);
        }

        // スコア更新
    GameHUD hud = FindFirstObjectByType<GameHUD>();
        //log
Debug.Log("ABC");
        if (hud != null)
        {
Debug.Log("DEF");
            int newScore = hud.UpdateScore(1);
            if (newScore >= CLEAR_SCORE)
            {
                GameClear();
            }
        }

        // 残りのコレクタブル数をログ表示
        Debug.Log($"残りのコレクタブル数: {activeCollectibles.Count}");

        // Check if all collectibles have been collected
        if (activeCollectibles.Count == 0)
        {
            if (currentRespawnCount < maxRespawnCount)
            {
                Debug.Log($"All collectibles collected! Respawning... ({currentRespawnCount + 1}/{maxRespawnCount})");
                currentRespawnCount++;
                SpawnCollectibles();
            }
            else
            {
                Debug.Log("Max respawn count reached. No more respawns.");
            }
        }
    }

    void SpawnCollectibles()
    {

        if (collectiblePrefab == null)
        {
            Debug.LogError("Collectible Prefab is not assigned in the GameManager.");
            return;
        }

        if (groundCollider == null)
        {
            Debug.LogError("Ground collider not found. Cannot determine spawn area.");
            return;
        }

        // Clear any remaining (just in case)
        foreach (var c in activeCollectibles)
        {
            if (c != null)
            {
                Destroy(c);
            }
        }
        activeCollectibles.Clear();

        Bounds bounds = groundCollider.bounds;

        GameObject player = GameObject.FindWithTag("Player");
        float playerZ = player != null ? player.transform.position.z : bounds.center.z;
        float minZ = playerZ;
        float maxZ = playerZ + 10f;
        // コレクタブルのスポーン位置リスト
        List<Vector3> collectiblePositions = new List<Vector3>();
        for (int i = 0; i < numberOfCollectiblesToSpawn; i++)
        {
            float randomX = Random.Range(bounds.min.x, bounds.max.x);
            float randomZ = Random.Range(minZ, maxZ);
            Vector3 spawnPosition = new Vector3(randomX, bounds.max.y + 1.0f, randomZ);
            GameObject newCollectible = Instantiate(collectiblePrefab, spawnPosition, Quaternion.identity);
            newCollectible.tag = "Collectible";
            activeCollectibles.Add(newCollectible);
            collectiblePositions.Add(spawnPosition);
        }
        // コレクタブル3つにつき1つだけカプセルをスポーン
        SpawnCapsulePowerUp(collectiblePositions);
    }

    // カプセル（PowerUp）スポーン処理を関数化
    void SpawnCapsulePowerUp(List<Vector3> collectiblePositions)
    {
        if (collectiblePositions == null || collectiblePositions.Count == 0) return;
        int capsuleIndex = Random.Range(0, collectiblePositions.Count);
        Vector3 basePos = collectiblePositions[capsuleIndex];
        // コレクタブルと重ならないように少しずらす
        Vector3 capsuleOffset = new Vector3(1.5f, 1.0f, 0); // x方向に1.5離す
        Vector3 capsulePos = basePos + capsuleOffset;
        // 他のコレクタブルと重複しないかチェック
        bool overlap = false;
        foreach (var pos in collectiblePositions)
        {
            if (Vector3.Distance(pos, capsulePos) < 1.0f)
            {
                overlap = true;
                break;
            }
        }
        //Enemyとも重複しないようにチェック
        var enemies = GameObject.FindGameObjectsWithTag("Enemy");
        foreach (var enemy in enemies)
        {
            if (Vector3.Distance(enemy.transform.position, capsulePos) < 1.0f)
            {
                overlap = true;
                break;
            }
        }
        if (!overlap)
        {
            GameObject capsule = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            capsule.transform.position = capsulePos;
            capsule.name = "CapsulePowerUp";
            capsule.tag = "PowerUp";
            // isTriggerをON
            Collider col = capsule.GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
            // マテリアル適用（85FF00色を直接設定）
            var renderer = capsule.GetComponent<Renderer>();
            if (renderer != null)
            {
                Material mat = new Material(renderer.sharedMaterial);
                Color powerUpColor;
                if (ColorUtility.TryParseHtmlString("#85FF00", out powerUpColor))
                {
                    mat.color = powerUpColor;
                }
                renderer.material = mat;
            }
            capsule.AddComponent<Rigidbody>().useGravity = false;
            capsule.AddComponent<CapsulePowerUp>();
        }
    }

    void GameClear()
    {
        isGameOver = true;
        GameHUD hud = FindFirstObjectByType<GameHUD>();
        if (hud != null)
        {
            hud.ShowGameClear();
        }
    }

    public void RetryGame()
    {

    }
}
