using UnityEngine;
using UnityEngine.InputSystem;

public class SimplePlayerMover : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    public float rotationSpeed = 120f; // ←追加: 回転速度（Inspectorで調整可）
    private Rigidbody rb;
    private bool isGrounded = true;

    private Vector3 inputMove = Vector3.zero;

    private GameObject bulletPrefab; // 通常弾
    public GameObject straightBulletPrefab; // 直進弾
    public GameObject explosiveBulletPrefab; // 爆発弾
    public Transform bulletSpawnPoint;

    // 発射間隔制御用
    public float fireInterval = 0.2f;
    private float fireTimer = 0f;

    void Awake()
    {
    // 通常弾プレハブ
    // bulletPrefab = new GameObject("BulletTemplate");
    // var bulletSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
    // bulletSphere.transform.SetParent(bulletPrefab.transform);
    // bulletSphere.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
    // bulletPrefab.SetActive(false);


    // 直進弾プレハブ
    straightBulletPrefab = new GameObject("StraightBulletTemplate");
    straightBulletPrefab.AddComponent<StraightBullet>();
    var straightSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
    straightSphere.transform.SetParent(straightBulletPrefab.transform);
    straightSphere.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
    straightSphere.GetComponent<Renderer>().material.color = Color.cyan;
    straightBulletPrefab.SetActive(false);

    // 爆発弾プレハブはResourcesからロード
    explosiveBulletPrefab = Resources.Load<GameObject>("ExplosiveBullet");


    }

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // Find the bullet spawn point
        bulletSpawnPoint = transform.Find("BulletSpawnPoint");
        if (bulletSpawnPoint == null)
        {
            // If not found, create one further in front of the player
            GameObject spawnPointObject = new GameObject("BulletSpawnPoint");
            spawnPointObject.transform.SetParent(transform);
            spawnPointObject.transform.localPosition = new Vector3(0, 0.5f, 2.0f); // zを2.0fに変更
            bulletSpawnPoint = spawnPointObject.transform;
        }
    // プレイヤーの上方10の位置に強い光源を生成
    GameObject lightObj = new GameObject("PlayerLight");
    lightObj.transform.position = transform.position + new Vector3(0, 10, 0);
    Light lightComp = lightObj.AddComponent<Light>();
    lightComp.type = LightType.Directional;
    lightComp.intensity = 2.5f; // 強めの光
    lightComp.color = Color.white;
    }

    void Update()
    {
        fireTimer += Time.deltaTime;
        // Input System対応
        float moveZ = 0f;
        float rotate = 0f;
        if (Keyboard.current != null)
        {
            if (Keyboard.current.wKey.isPressed) moveZ += 1f;
            if (Keyboard.current.sKey.isPressed) moveZ -= 1f;
            if (Keyboard.current.aKey.isPressed) rotate -= 1f;
            if (Keyboard.current.dKey.isPressed) rotate += 1f;
        }
    // 前後移動のみ（wで前進、sで後退）
    inputMove = transform.forward * moveZ;
    inputMove = inputMove.normalized;

        // 回転
        if (rotate != 0f)
        {
            transform.Rotate(Vector3.up, rotate * rotationSpeed * Time.deltaTime);
        }

        if (Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }

        // 左クリック押しっぱなしで3種同時発射（クールダウン付き）
        if (Mouse.current != null && Mouse.current.leftButton.isPressed)
        {
            if (fireTimer >= fireInterval)
            {
                ShootAllBullets();
                fireTimer = 0f;
            }
        }

        // カメラ追従
        if (Camera.main != null)
        {
            Vector3 cameraOffset = new Vector3(0, 2, -5);
            Camera.main.transform.position = transform.position + cameraOffset;
            Camera.main.transform.LookAt(transform.position + Vector3.up * 1.0f);
        }
    }

    void Shoot()
    {
        bulletPrefab = Resources.Load<GameObject>("Bullet");
        GameObject bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        bullet.tag = "Bullet"; // 追加
        // Rigidbodyがあれば前方に力を加える
        Rigidbody rb = bullet.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.AddForce(bulletSpawnPoint.forward * 20f, ForceMode.Impulse);
        }
        Destroy(bullet, 3f);
    }

    void ShootAllBullets()
    {
        // 通常弾
        Shoot();

        // 直進弾
        // if (straightBulletPrefab != null && bulletSpawnPoint != null)
        // {
        //     GameObject straight = Instantiate(straightBulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        //     straight.layer = gameObject.layer;
        //     straight.SetActive(true);
        //     var sb = straight.GetComponent<StraightBullet>();
        //     if (sb != null)
        //     {
        //         sb.Fire(bulletSpawnPoint.forward);
        //     }
        // }

        // 爆発弾
        if (explosiveBulletPrefab != null && bulletSpawnPoint != null)
        {
            GameObject explosive = Instantiate(explosiveBulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);

            Debug.Log("1はっしゃ");
            var explosiveCol = explosive.GetComponent<Collider>();
            var playerCol = GetComponent<Collider>();
            if (explosiveCol != null && playerCol != null)
            {
                            Debug.Log("2はっしゃ");
                Physics.IgnoreCollision(explosiveCol, playerCol);
            }
            Debug.Log(explosive);
            var eb = explosive.GetComponent<ExplosiveBullet>();
            if (eb != null)
            {
                            Debug.Log("3はっしゃ");
                eb.Fire(bulletSpawnPoint.forward + bulletSpawnPoint.up * 0.2f);
            }
        }

    }

    void FixedUpdate()
    {
        // 物理演算に合わせて移動
        Vector3 velocity = rb.linearVelocity;
        Vector3 move = inputMove * moveSpeed;
        rb.linearVelocity = new Vector3(move.x, velocity.y, move.z);
    }

    void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }
}
