    using UnityEngine;

    public class StraightBullet : MonoBehaviour
    {
        public float speed = 20f;
        private Vector3 direction;

        void Awake()
        {
            // ColliderがあればisTriggerをtrueに
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        public void Fire(Vector3 dir)
        {
            //log
            Debug.Log("12Bullet fired");
            direction = dir.normalized;
            tag = "Bullet"; // バレット判定
            //rigibodyをつける
            Rigidbody rb = gameObject.AddComponent<Rigidbody>();
            rb.isKinematic = false; // 物理演算を有効化
            rb.useGravity = false; // 重力は無効化
            rb.AddForce(direction * speed, ForceMode.Impulse); // AddForceで発射
                // 子オブジェクトのRendererにマテリアル設定（例: シアン）
                var renderer = GetComponentInChildren<Renderer>();
                if (renderer != null)
                {
                    var mat = new Material(Shader.Find("Standard"));
                    mat.color = Color.cyan;
                    renderer.material = mat;
                }
            Destroy(gameObject, 3f); // 3秒後に自動消滅
        }

        void Update()
        {
            
            transform.position += direction * speed * Time.deltaTime;
        }

        void OnTriggerEnter(Collider other)
        {
            // プレイヤーには当たらない
            if (other.CompareTag("Player")) return;
            Destroy(gameObject);
        }
    }
