//ExplosiveBullet.cs
//仕様は放物線で発射されて広範囲に爆発する弾。 重力の影響を受ける放物線で発射されてgroundに接触したら1秒間出現する直径2の赤色の爆発が現れる。コレクタブルとエネミーに当たり判定がある
//ExplosiveBullet.prefabがResourcesフォルダにある。それを使ってください
using UnityEngine;
using System.Collections;

public class ExplosiveBullet : MonoBehaviour
{
    public float explosionRadius = 1f;
    public float explosionDuration = 0.5f;
    public LayerMask hitLayers;
    public GameObject explosionPrefab;

    private Rigidbody rb;
    private bool hasExploded = false;

// 発射方向を受け取ってRigidbodyに力を加えるメソッドを追加
    public void Fire(Vector3 direction)
    {
        //log
        Debug.Log("4はっしゃ");
        if (rb == null) rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.AddForce(direction.normalized * 20f, ForceMode.Impulse);
        }
    }

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (explosionPrefab == null)
        {
            explosionPrefab = Resources.Load<GameObject>("Explode"); // 爆発エフェクト用Prefabをロード
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (!hasExploded && collision.gameObject.CompareTag("Ground"))
        {
            hasExploded = true;
            StartCoroutine(Explode());
        }
    }

    IEnumerator Explode()
    {
        // Instantiate explosion effect
        GameObject explosion = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        // Set explosion scale (diameter 2)
        explosion.transform.localScale = new Vector3(2f, 2f, 2f);
        // 色はPrefab側で設定しておくことを推奨

        // Detect objects in range
        Collider[] hits = Physics.OverlapSphere(transform.position, explosionRadius, hitLayers);
        foreach (Collider hit in hits)
        {
            if (hit.CompareTag("Enemy") || hit.CompareTag("Collectible"))
            {
                // Implement your logic for hitting enemies or collectibles
                // Example: Destroy(hit.gameObject);
            }
        }

        // Wait for explosion duration
        yield return new WaitForSeconds(explosionDuration);

        Destroy(explosion);
        Destroy(gameObject);
    }
}